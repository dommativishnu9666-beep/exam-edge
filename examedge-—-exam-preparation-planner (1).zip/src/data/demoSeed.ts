import type {
  PriorityLevel,
  RevisionStatus,
  SubjectColor,
  TopicStatus,
} from '../types/examedge.ts';

export function shiftDateISO(offsetDays: number): string {
  const now = new Date();
  const target = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + offsetDays
  );
  const y = target.getFullYear();
  const m = String(target.getMonth() + 1).padStart(2, '0');
  const d = String(target.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export interface SeedSubjectSpec {
  name: string;
  code: string;
  color: SubjectColor;
  icon: string;
  examOffsetDays: number;
  priority: PriorityLevel;
  topics: Array<{
    unitNumber: number;
    unitName: string;
    topicTitle: string;
    priority: PriorityLevel;
    estimatedHours: number;
    status: TopicStatus;
    notes: string;
  }>;
}

export const SAMPLE_SUBJECTS_SEED: SeedSubjectSpec[] = [
  {
    name: 'Mathematics',
    code: 'MA101',
    color: 'indigo',
    icon: 'sigma',
    examOffsetDays: 12,
    priority: 'High',
    topics: [
      {
        unitNumber: 1,
        unitName: 'Linear Algebra',
        topicTitle: 'Matrices, Rank & Eigenvalues / Cayley-Hamilton Theorem',
        priority: 'High',
        estimatedHours: 4,
        status: 'Completed',
        notes: 'Reviewed diagonalization problems and characteristic polynomials.',
      },
      {
        unitNumber: 2,
        unitName: 'Differential Calculus',
        topicTitle: 'Partial Derivatives, Jacobians & Maxima-Minima',
        priority: 'High',
        estimatedHours: 5,
        status: 'Completed',
        notes: 'Lagrange multipliers sheet saved in short notes.',
      },
      {
        unitNumber: 3,
        unitName: 'Integral Calculus',
        topicTitle: 'Multiple Integrals, Change of Order & Beta-Gamma Functions',
        priority: 'High',
        estimatedHours: 5,
        status: 'In Progress',
        notes: 'Finish triple integral spherical coordinate transformations.',
      },
      {
        unitNumber: 4,
        unitName: 'Vector Calculus',
        topicTitle: "Green's, Stokes' & Gauss Divergence Theorems",
        priority: 'Medium',
        estimatedHours: 4,
        status: 'In Progress',
        notes: 'Work through 5 surface integral boundary examples.',
      },
      {
        unitNumber: 5,
        unitName: 'Transforms & ODEs',
        topicTitle: 'Laplace Transforms & Second-Order Differential Equations',
        priority: 'Low',
        estimatedHours: 3,
        status: 'Not Started',
        notes: 'Practice convolution theorem applications.',
      },
    ],
  },
  {
    name: 'Engineering Physics',
    code: 'PH102',
    color: 'blue',
    icon: 'atom',
    examOffsetDays: 16,
    priority: 'High',
    topics: [
      {
        unitNumber: 1,
        unitName: 'Wave Optics',
        topicTitle: "Thin Film Interference, Newton's Rings & Diffraction Grating",
        priority: 'High',
        estimatedHours: 4,
        status: 'Completed',
        notes: 'Derived fringe width and resolving power formulas.',
      },
      {
        unitNumber: 2,
        unitName: 'Quantum Mechanics',
        topicTitle: "Schrödinger Wave Equation & Particle in a 1D Potential Box",
        priority: 'High',
        estimatedHours: 5,
        status: 'In Progress',
        notes: 'Revise normalization constants and tunneling probability.',
      },
      {
        unitNumber: 3,
        unitName: 'Semiconductor Physics',
        topicTitle: 'Fermi-Dirac Statistics, Hall Effect & P-N Junction Carrier Drift',
        priority: 'Medium',
        estimatedHours: 4,
        status: 'Not Started',
        notes: 'Focus on Hall coefficient sign conventions.',
      },
      {
        unitNumber: 4,
        unitName: 'Lasers & Fiber Optics',
        topicTitle: 'Population Inversion, Ruby/He-Ne Laser & Numerical Aperture',
        priority: 'Low',
        estimatedHours: 3,
        status: 'Completed',
        notes: 'Step-index vs graded-index dispersion notes finalized.',
      },
    ],
  },
  {
    name: 'Programming in C',
    code: 'CS103',
    color: 'purple',
    icon: 'code',
    examOffsetDays: 9,
    priority: 'High',
    topics: [
      {
        unitNumber: 1,
        unitName: 'Control Flow & Functions',
        topicTitle: 'Loops, Storage Classes & Recursive Algorithms',
        priority: 'Medium',
        estimatedHours: 3,
        status: 'Completed',
        notes: 'Traced stack frames for Tower of Hanoi and quicksort.',
      },
      {
        unitNumber: 2,
        unitName: 'Arrays & Strings',
        topicTitle: '2D Matrix Operations & String Manipulation Library Functions',
        priority: 'Medium',
        estimatedHours: 3,
        status: 'Completed',
        notes: 'Implemented custom strlen, strcpy, and matrix transpose.',
      },
      {
        unitNumber: 3,
        unitName: 'Pointers & Memory',
        topicTitle: 'Pointer Arithmetic, Function Pointers & malloc/calloc/free',
        priority: 'High',
        estimatedHours: 5,
        status: 'In Progress',
        notes: 'Double-check dangling pointer and memory leak scenarios.',
      },
      {
        unitNumber: 4,
        unitName: 'Structures & File I/O',
        topicTitle: 'Nested Structs, Unions, Bitfields & Binary File Streams',
        priority: 'High',
        estimatedHours: 4,
        status: 'Not Started',
        notes: 'Practice fseek, ftell, and fread record updates.',
      },
    ],
  },
  {
    name: 'Basic Electrical Engineering',
    code: 'EE104',
    color: 'cyan',
    icon: 'zap',
    examOffsetDays: 20,
    priority: 'Medium',
    topics: [
      {
        unitNumber: 1,
        unitName: 'DC Circuit Analysis',
        topicTitle: 'KVL/KCL, Thevenin, Norton & Superposition Theorems',
        priority: 'High',
        estimatedHours: 4,
        status: 'Completed',
        notes: 'Solved dependent source Thevenin equivalent problems.',
      },
      {
        unitNumber: 2,
        unitName: 'AC Circuits',
        topicTitle: 'Phasor Algebra, RLC Series Resonance & Three-Phase Power',
        priority: 'High',
        estimatedHours: 5,
        status: 'In Progress',
        notes: 'Verify star-delta line vs phase voltage relations.',
      },
      {
        unitNumber: 3,
        unitName: 'Transformers',
        topicTitle: 'Equivalent Circuit, OC/SC Tests & All-Day Efficiency',
        priority: 'Medium',
        estimatedHours: 4,
        status: 'Not Started',
        notes: 'Plot phasor diagram for lagging power factor load.',
      },
      {
        unitNumber: 4,
        unitName: 'Electrical Machines',
        topicTitle: 'DC Motor Torque Equation & 3-Phase Induction Motor Slip',
        priority: 'Low',
        estimatedHours: 3,
        status: 'Not Started',
        notes: 'Compare squirrel cage vs slip-ring rotor starting torque.',
      },
    ],
  },
  {
    name: 'Engineering Chemistry',
    code: 'CH105',
    color: 'emerald',
    icon: 'flask',
    examOffsetDays: 24,
    priority: 'Medium',
    topics: [
      {
        unitNumber: 1,
        unitName: 'Electrochemistry',
        topicTitle: 'Nernst Equation, Reference Electrodes & Lithium-Ion Cells',
        priority: 'High',
        estimatedHours: 4,
        status: 'Completed',
        notes: 'Worked through EMF numericals with pH dependence.',
      },
      {
        unitNumber: 2,
        unitName: 'Water & Corrosion',
        topicTitle: 'EDTA Hardness Titration, Galvanic Corrosion & Cathodic Protection',
        priority: 'Medium',
        estimatedHours: 3,
        status: 'Completed',
        notes: 'Balanced temporary vs permanent hardness equations.',
      },
      {
        unitNumber: 3,
        unitName: 'Polymer Science',
        topicTitle: 'Addition vs Condensation Polymerization & Conducting Polymers',
        priority: 'Low',
        estimatedHours: 3,
        status: 'Not Started',
        notes: 'Memorize Nylon-6,6 and Kevlar monomer structures.',
      },
      {
        unitNumber: 4,
        unitName: 'Spectroscopy',
        topicTitle: 'UV-Visible Beer-Lambert Law & IR Functional Group Vibrations',
        priority: 'Medium',
        estimatedHours: 3,
        status: 'In Progress',
        notes: 'Review carbonyl stretching wavenumber table.',
      },
    ],
  },
];

export interface SeedRevisionSpec {
  subjectCode: string;
  topicTitle: string;
  offsetDays: number;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  priority: PriorityLevel;
  status: RevisionStatus;
  notes: string;
}

export const SAMPLE_REVISIONS_SEED: SeedRevisionSpec[] = [
  {
    subjectCode: 'MA101',
    topicTitle: 'Multiple Integrals, Change of Order & Beta-Gamma Functions',
    offsetDays: 0,
    startTime: '09:00',
    endTime: '10:30',
    durationMinutes: 90,
    priority: 'High',
    status: 'Pending',
    notes: 'Solve 6 past-exam region-of-integration sketch problems.',
  },
  {
    subjectCode: 'CS103',
    topicTitle: 'Pointer Arithmetic, Function Pointers & malloc/calloc/free',
    offsetDays: 0,
    startTime: '16:00',
    endTime: '17:30',
    durationMinutes: 90,
    priority: 'High',
    status: 'Pending',
    notes: 'Trace dynamic 2D array allocation and linked list insertion.',
  },
  {
    subjectCode: 'PH102',
    topicTitle: 'Schrödinger Wave Equation & Particle in a 1D Potential Box',
    offsetDays: 1,
    startTime: '10:00',
    endTime: '11:30',
    durationMinutes: 90,
    priority: 'High',
    status: 'Pending',
    notes: 'Derive time-independent eigenfunctions from boundary conditions.',
  },
  {
    subjectCode: 'EE104',
    topicTitle: 'Phasor Algebra, RLC Series Resonance & Three-Phase Power',
    offsetDays: 2,
    startTime: '14:00',
    endTime: '15:15',
    durationMinutes: 75,
    priority: 'Medium',
    status: 'Pending',
    notes: 'Two-wattmeter power measurement derivation & numericals.',
  },
  {
    subjectCode: 'CH105',
    topicTitle: 'UV-Visible Beer-Lambert Law & IR Functional Group Vibrations',
    offsetDays: 3,
    startTime: '11:00',
    endTime: '12:00',
    durationMinutes: 60,
    priority: 'Medium',
    status: 'Pending',
    notes: 'Practice molar absorptivity calculation sets.',
  },
  {
    subjectCode: 'MA101',
    topicTitle: 'Matrices, Rank & Eigenvalues / Cayley-Hamilton Theorem',
    offsetDays: -1,
    startTime: '09:00',
    endTime: '10:30',
    durationMinutes: 90,
    priority: 'High',
    status: 'Completed',
    notes: 'Completed all 8 inverse-via-Cayley-Hamilton exercises.',
  },
  {
    subjectCode: 'CS103',
    topicTitle: 'Loops, Storage Classes & Recursive Algorithms',
    offsetDays: -2,
    startTime: '17:00',
    endTime: '18:00',
    durationMinutes: 60,
    priority: 'Medium',
    status: 'Completed',
    notes: 'Verified static vs extern linkage edge cases.',
  },
  {
    subjectCode: 'PH102',
    topicTitle: "Thin Film Interference, Newton's Rings & Diffraction Grating",
    offsetDays: -3,
    startTime: '15:00',
    endTime: '16:30',
    durationMinutes: 90,
    priority: 'High',
    status: 'Completed',
    notes: 'Finished refractive index determination numericals.',
  },
  {
    subjectCode: 'EE104',
    topicTitle: 'DC Circuit Analysis — Thevenin & Norton Theorems',
    offsetDays: -4,
    startTime: '19:00',
    endTime: '20:00',
    durationMinutes: 60,
    priority: 'Low',
    status: 'Missed',
    notes: 'Reschedule dependent-source check for weekend slot.',
  },
];

export const SAMPLE_STUDY_LOGS_SEED = [
  { offsetDays: -6, minutes: 150, actionType: 'study_logged', description: 'Completed Mathematics Unit 1 & 2 practice sets' },
  { offsetDays: -5, minutes: 180, actionType: 'topic_completed', description: 'Completed Control Flow & Recursive Algorithms in C' },
  { offsetDays: -4, minutes: 120, actionType: 'study_logged', description: 'Worked through DC Circuit Nodal & Mesh problems' },
  { offsetDays: -3, minutes: 210, actionType: 'revision_completed', description: 'Finished Wave Optics interference revision block' },
  { offsetDays: -2, minutes: 165, actionType: 'revision_completed', description: 'Completed C Recursion & Storage Class drills' },
  { offsetDays: -1, minutes: 240, actionType: 'revision_completed', description: 'Completed Eigenvalues & Cayley-Hamilton revision session' },
  { offsetDays: 0, minutes: 90, actionType: 'topic_completed', description: 'Updated Nernst Equation & Electrochemistry notes' },
];
