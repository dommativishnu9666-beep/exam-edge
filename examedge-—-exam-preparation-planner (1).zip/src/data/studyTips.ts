import type { StudyTip } from '../types/examedge.ts';

export const TIP_CATEGORIES = [
  'All',
  'Time Management',
  'Effective Note Making',
  'Memory Improvement',
  'Exam Preparation',
  'Concentration & Focus',
  'Revision Techniques',
] as const;

export const STUDY_TIPS: StudyTip[] = [
  {
    id: 'pomodoro-technique',
    title: 'Use the Pomodoro Technique',
    category: 'Concentration & Focus',
    readTime: '3 min read',
    summary:
      'Study in structured 25-minute deep-focus intervals followed by 5-minute restorative breaks to prevent cognitive fatigue.',
    steps: [
      'Pick one specific syllabus topic before starting the timer.',
      'Silence notifications and work uninterrupted for 25 minutes.',
      'Take a 5-minute break away from screens to reset attention.',
      'After 4 intervals, take a longer 20-minute recovery break.',
    ],
    deepDive:
      'Attention decays steeply after 30 minutes of continuous problem solving without a mental checkpoint. By bounding effort into 25-minute sprints, your brain treats each block as a finite, low-friction challenge—making it far easier to begin complex derivations in Mathematics or Physics.',
    imageUrl: '/src/assets/images/tip_pomodoro_focus_1795155880771.jpg',
    accentColor: 'indigo',
  },
  {
    id: 'active-recall',
    title: 'Follow Active Recall',
    category: 'Memory Improvement',
    readTime: '4 min read',
    summary:
      'Test yourself on key theorems, formulas, and code patterns from memory before checking your textbook or lecture notes.',
    steps: [
      'Close your notebook after finishing a unit and write down everything you remember.',
      'Compare your recall sheet against the syllabus to expose knowledge gaps.',
      'Convert weak definitions into question-answer flashcards.',
      'Explain difficult concepts aloud in simple language without looking at references.',
    ],
    deepDive:
      'Passive rereading creates an illusion of fluency because recognized text feels familiar. Active retrieval forces neural pathways to reconstruct the concept from scratch, doubling long-term retention during high-pressure university exams.',
    imageUrl: '/src/assets/images/tip_active_recall_1795155880846.jpg',
    accentColor: 'blue',
  },
  {
    id: 'revise-regularly',
    title: 'Revise Regularly With Spaced Intervals',
    category: 'Revision Techniques',
    readTime: '4 min read',
    summary:
      'Review previously studied topics at expanding intervals (Day 1, Day 3, Day 7, Day 21) to lock knowledge into long-term memory.',
    steps: [
      'Schedule a 20-minute review session within 24 hours of learning a topic.',
      'Add follow-up sessions in your Revision Calendar 3 and 7 days later.',
      'Focus only on missed problems during later passes to save hours.',
      'Run a full mixed-topic mock check 2 weeks before the exam date.',
    ],
    deepDive:
      'Hermann Ebbinghaus demonstrated that memory drops sharply in the first 48 hours unless reinforced. Scheduling spaced sessions right before the forgetting curve dips ensures you enter exam week reviewing, not relearning from zero.',
    imageUrl: '/src/assets/images/tip_spaced_revision_1795155880939.jpg',
    accentColor: 'purple',
  },
  {
    id: 'create-short-notes',
    title: 'Create Short Formula & Concept Sheets',
    category: 'Effective Note Making',
    readTime: '3 min read',
    summary:
      'Distill each syllabus unit into a single organized reference page of formulas, boundary conditions, and canonical examples.',
    steps: [
      'Use one page per unit so visual spatial memory helps you locate formulas.',
      'Separate definitions, equations, and common exam traps into clean columns.',
      'Highlight assumptions (e.g., ideal transformer, continuous differentiability).',
      'Update your summary sheet whenever a practice test reveals a subtle edge case.',
    ],
    deepDive:
      'The act of compressing a 40-page chapter onto one structured sheet forces synthesis. During the final 48 hours before an exam, these condensed sheets let you sweep an entire semester syllabus in under two hours.',
    accentColor: 'cyan',
  },
  {
    id: 'prioritize-difficult-topics',
    title: 'Prioritize Difficult & High-Weightage Topics',
    category: 'Exam Preparation',
    readTime: '4 min read',
    summary:
      'Tackle high-priority, conceptually demanding units during your peak morning energy hours rather than leaving them for late nights.',
    steps: [
      'Tag syllabus units by exam weightage and personal confidence level.',
      'Assign High Priority topics to your earliest 90-minute study block.',
      'Break intimidating chapters into 2-hour micro-topics with clear deliverables.',
      'Pair every heavy theory block with 3 solved past-paper numerical problems.',
    ],
    deepDive:
      'Students often procrastinate by polishing easy topics they already understand. Attacking high-weightage bottlenecks first maximizes score gains per hour invested and dramatically lowers pre-exam anxiety.',
    accentColor: 'amber',
  },
  {
    id: 'consistent-schedule',
    title: 'Maintain a Consistent Daily Study Rhythm',
    category: 'Time Management',
    readTime: '3 min read',
    summary:
      'Build a realistic daily study target you can sustain every week instead of relying on unsustainable 12-hour cramming marathons.',
    steps: [
      'Set a realistic daily target (3 to 5 focused hours alongside lectures).',
      'Anchor study blocks to consistent daily cues like morning coffee or post-lunch.',
      'Reserve Sunday evenings for planning the next week in your Revision Calendar.',
      'Track completed hours daily to spot dips early and adjust workload.',
    ],
    deepDive:
      'Consistency compounds quietly: 4 focused hours a day for 30 days equals 120 hours of calm mastery—far outperforming a panicked 72-hour exam-week sprint plagued by sleep deprivation and careless calculation errors.',
    accentColor: 'emerald',
  },
  {
    id: 'feynman-technique',
    title: 'Teach Concepts Using the Feynman Method',
    category: 'Effective Note Making',
    readTime: '3 min read',
    summary:
      'Write an explanation of a complex topic as if teaching a first-year student—every hesitation reveals exactly what to review.',
    steps: [
      'Write the topic title at the top of a blank sheet.',
      'Explain the mechanism or proof using plain language and simple analogies.',
      'Notice where your explanation stalls or hides behind jargon.',
      'Return to the textbook strictly for those stalled segments, then rewrite.',
    ],
    deepDive:
      'If you cannot explain pointers in C or phasor diagrams clearly without technical crutches, you only memorized surface phrasing. Plain-language articulation cements conceptual intuition.',
    accentColor: 'indigo',
  },
  {
    id: 'interleaved-practice',
    title: 'Interleave Subjects Across Revision Blocks',
    category: 'Revision Techniques',
    readTime: '4 min read',
    summary:
      'Mix two complementary subjects in a day—such as Mathematics followed by Programming in C—to sharpen problem-selection skills.',
    steps: [
      'Alternate analytical problem sets with conceptual reading or coding labs.',
      'Avoid studying the exact same topic type for more than 2 hours straight.',
      'Use mixed-unit quizzes to practice identifying which theorem applies.',
    ],
    deepDive:
      'Blocked practice makes problem sets predictable because you already know which chapter formula to apply. Interleaving forces your brain to diagnose the problem type first—mirroring real exam conditions.',
    accentColor: 'purple',
  },
  {
    id: 'exam-simulation',
    title: 'Run Timed Past-Paper Simulations',
    category: 'Exam Preparation',
    readTime: '5 min read',
    summary:
      'Practice under real exam time limits and mark your own script strictly to calibrate pacing and eliminate silly errors.',
    steps: [
      'Set a countdown timer matching your university exam duration.',
      'Solve without notes, formula sheets, or phone access.',
      'Audit lost marks by category: conceptual gap, formula slip, or time crunch.',
      'Schedule targeted revision blocks for the top two error categories.',
    ],
    deepDive:
      'Knowledge alone does not guarantee top scores if pacing collapses on Section B. Timed rehearsals train your internal clock and inoculate you against exam-hall stress.',
    accentColor: 'rose',
  },
];
