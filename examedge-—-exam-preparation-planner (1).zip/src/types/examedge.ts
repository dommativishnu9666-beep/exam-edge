export type SubjectColor = 'indigo' | 'blue' | 'purple' | 'cyan' | 'emerald' | 'amber' | 'rose';
export type PriorityLevel = 'High' | 'Medium' | 'Low';
export type TopicStatus = 'Not Started' | 'In Progress' | 'Completed';
export type RevisionStatus = 'Pending' | 'Completed' | 'Missed';
export type ThemeMode = 'light' | 'dark';

export type AppPage =
  | 'landing'
  | 'dashboard'
  | 'subjects'
  | 'syllabus'
  | 'calendar'
  | 'tips'
  | 'analytics'
  | 'settings'
  | 'help';

export interface UserProfile {
  id: number;
  uid: string;
  email: string;
  fullName: string;
  studentId: string;
  course: string;
  semester: string;
  dailyTargetHours: number;
  theme: ThemeMode;
  notificationsEnabled: boolean;
  avatarUrl: string;
}

export interface Subject {
  id: number;
  userId: number;
  name: string;
  code: string;
  color: SubjectColor;
  icon: string;
  examDate: string;
  priority: PriorityLevel;
}

export interface SyllabusTopic {
  id: number;
  userId: number;
  subjectId: number;
  unitNumber: number;
  unitName: string;
  topicTitle: string;
  priority: PriorityLevel;
  estimatedHours: number;
  status: TopicStatus;
  notes: string;
  completedAt: string | null;
}

export interface RevisionSession {
  id: number;
  userId: number;
  subjectId: number;
  topicId: number | null;
  topicTitle: string;
  sessionDate: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  priority: PriorityLevel;
  status: RevisionStatus;
  notes: string;
}

export interface StudyLog {
  id: number;
  userId: number;
  logDate: string;
  minutes: number;
  actionType: string;
  description: string;
  createdAt: string;
}

export interface StudyTip {
  id: string;
  title: string;
  category:
    | 'Time Management'
    | 'Effective Note Making'
    | 'Memory Improvement'
    | 'Exam Preparation'
    | 'Concentration & Focus'
    | 'Revision Techniques';
  readTime: string;
  summary: string;
  steps: string[];
  deepDive: string;
  imageUrl?: string;
  accentColor: SubjectColor;
}

export interface PlannerState {
  profile: UserProfile;
  subjects: Subject[];
  topics: SyllabusTopic[];
  revisions: RevisionSession[];
  studyLogs: StudyLog[];
  favoriteTipIds: string[];
}

export const SUBJECT_PALETTE: Record<
  SubjectColor,
  {
    label: string;
    gradient: string;
    solidBg: string;
    softBg: string;
    text: string;
    border: string;
    hex: string;
  }
> = {
  indigo: {
    label: 'Indigo',
    gradient: 'from-indigo-600 to-violet-600',
    solidBg: 'bg-indigo-600',
    softBg: 'bg-indigo-50 dark:bg-indigo-950/60',
    text: 'text-indigo-700 dark:text-indigo-300',
    border: 'border-indigo-200 dark:border-indigo-800',
    hex: '#4338CA',
  },
  blue: {
    label: 'Bright Blue',
    gradient: 'from-blue-600 to-cyan-500',
    solidBg: 'bg-blue-600',
    softBg: 'bg-blue-50 dark:bg-blue-950/60',
    text: 'text-blue-700 dark:text-blue-300',
    border: 'border-blue-200 dark:border-blue-800',
    hex: '#2563EB',
  },
  purple: {
    label: 'Electric Purple',
    gradient: 'from-violet-600 to-fuchsia-600',
    solidBg: 'bg-violet-600',
    softBg: 'bg-violet-50 dark:bg-violet-950/60',
    text: 'text-violet-700 dark:text-violet-300',
    border: 'border-violet-200 dark:border-violet-800',
    hex: '#7C3AED',
  },
  cyan: {
    label: 'Cyan',
    gradient: 'from-cyan-600 to-teal-500',
    solidBg: 'bg-cyan-600',
    softBg: 'bg-cyan-50 dark:bg-cyan-950/60',
    text: 'text-cyan-700 dark:text-cyan-300',
    border: 'border-cyan-200 dark:border-cyan-800',
    hex: '#06B6D4',
  },
  emerald: {
    label: 'Mint Emerald',
    gradient: 'from-emerald-600 to-teal-500',
    solidBg: 'bg-emerald-600',
    softBg: 'bg-emerald-50 dark:bg-emerald-950/60',
    text: 'text-emerald-700 dark:text-emerald-300',
    border: 'border-emerald-200 dark:border-emerald-800',
    hex: '#10B981',
  },
  amber: {
    label: 'Warm Amber',
    gradient: 'from-amber-500 to-orange-500',
    solidBg: 'bg-amber-500',
    softBg: 'bg-amber-50 dark:bg-amber-950/60',
    text: 'text-amber-700 dark:text-amber-300',
    border: 'border-amber-200 dark:border-amber-800',
    hex: '#D97706',
  },
  rose: {
    label: 'Coral Rose',
    gradient: 'from-rose-600 to-pink-500',
    solidBg: 'bg-rose-600',
    softBg: 'bg-rose-50 dark:bg-rose-950/60',
    text: 'text-rose-700 dark:text-rose-300',
    border: 'border-rose-200 dark:border-rose-800',
    hex: '#E11D48',
  },
};

export function calculateDurationMinutes(start: string, end: string): number {
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  if (
    Number.isNaN(sh) ||
    Number.isNaN(sm) ||
    Number.isNaN(eh) ||
    Number.isNaN(em)
  ) {
    return 60;
  }
  const startTotal = sh * 60 + sm;
  const endTotal = eh * 60 + em;
  const diff = endTotal - startTotal;
  return diff > 0 ? diff : 60;
}

export function formatDurationLabel(minutes: number): string {
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hrs === 0) return `${mins}m`;
  if (mins === 0) return `${hrs}h`;
  return `${hrs}h ${mins}m`;
}

export function formatDayName(dateStr: string): string {
  const parts = dateStr.split('-').map(Number);
  if (parts.length !== 3) return '';
  const date = new Date(parts[0], parts[1] - 1, parts[2]);
  return date.toLocaleDateString('en-US', { weekday: 'short' });
}

export function formatShortDate(dateStr: string): string {
  const parts = dateStr.split('-').map(Number);
  if (parts.length !== 3) return dateStr;
  const date = new Date(parts[0], parts[1] - 1, parts[2]);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}
