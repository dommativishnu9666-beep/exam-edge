import {
  bulkImportSubjectsAndTopicsTx,
  commitAutoScheduleTx,
  getPlannerStateForUser,
} from '../db/plannerRepo.ts';
import { appConfig } from '../config/env.ts';
import {
  exportRevisionsToCsv,
  exportStudyLogsToCsv,
  exportSubjectsToCsv,
  exportTopicsToCsv,
  parseAndValidateSubjectsTopicsCsv,
} from '../utils/csv.ts';
import {
  generateAutoRevisionSchedule,
  type AutoScheduleRequest,
} from '../utils/scheduler.ts';
import { HttpError } from '../middleware/errorHandler.ts';

export async function runAutoScheduleService(
  userId: number,
  input: AutoScheduleRequest & { commit: boolean }
) {
  const state = await getPlannerStateForUser(userId);
  const proposals = generateAutoRevisionSchedule(
    state.subjects as unknown as Parameters<typeof generateAutoRevisionSchedule>[0],
    state.topics as unknown as Parameters<typeof generateAutoRevisionSchedule>[1],
    state.revisions as unknown as Parameters<typeof generateAutoRevisionSchedule>[2],
    input
  );

  if (!input.commit || proposals.length === 0) {
    return {
      committed: false,
      count: proposals.length,
      proposals,
    };
  }

  const inserted = await commitAutoScheduleTx(userId, proposals);
  return {
    committed: true,
    count: inserted.length,
    proposals,
    createdRevisions: inserted,
  };
}

export async function processCsvImportService(
  userId: number,
  payload: {
    fileName: string;
    csvContent: string;
    skipDuplicates: boolean;
    dryRun: boolean;
  }
) {
  const byteLength = Buffer.byteLength(payload.csvContent, 'utf8');
  if (byteLength > appConfig.csv.maxBytes) {
    throw new HttpError(
      413,
      `CSV file exceeds maximum size of ${Math.round(appConfig.csv.maxBytes / 1024)} KB.`,
      'CSV_TOO_LARGE'
    );
  }

  const state = await getPlannerStateForUser(userId);
  const validation = parseAndValidateSubjectsTopicsCsv(
    payload.csvContent,
    state.subjects,
    state.topics,
    appConfig.csv.maxRows
  );

  if (payload.dryRun) {
    return {
      dryRun: true,
      ...validation,
      imported: { subjectsCreated: 0, topicsCreated: 0 },
    };
  }

  if (validation.errors.length > 0 && validation.validRows.length === 0) {
    throw new HttpError(
      400,
      'CSV contains validation errors and no valid rows could be imported.',
      'CSV_VALIDATION_FAILED',
      validation
    );
  }

  if (!payload.skipDuplicates && validation.duplicates.length > 0) {
    throw new HttpError(
      409,
      'Duplicate records detected in CSV upload.',
      'CSV_DUPLICATES_DETECTED',
      validation
    );
  }

  const imported = await bulkImportSubjectsAndTopicsTx(
    userId,
    validation.validRows
  );

  return {
    dryRun: false,
    ...validation,
    imported,
  };
}

export async function exportPlannerCsvService(
  userId: number,
  entity: 'subjects' | 'topics' | 'revisions' | 'logs'
) {
  const state = await getPlannerStateForUser(userId);
  const subjects = state.subjects as unknown as Parameters<
    typeof exportSubjectsToCsv
  >[0];
  const topics = state.topics as unknown as Parameters<
    typeof exportSubjectsToCsv
  >[1];
  const revisions = state.revisions as unknown as Parameters<
    typeof exportRevisionsToCsv
  >[1];
  const logs = state.studyLogs as unknown as Parameters<
    typeof exportStudyLogsToCsv
  >[0];

  switch (entity) {
    case 'subjects':
      return {
        filename: 'examedge-subjects.csv',
        csv: exportSubjectsToCsv(subjects, topics),
      };
    case 'topics':
      return {
        filename: 'examedge-syllabus-topics.csv',
        csv: exportTopicsToCsv(subjects, topics),
      };
    case 'revisions':
      return {
        filename: 'examedge-revisions.csv',
        csv: exportRevisionsToCsv(subjects, revisions),
      };
    case 'logs':
      return {
        filename: 'examedge-study-logs.csv',
        csv: exportStudyLogsToCsv(logs),
      };
  }
}
