import { auth } from '../lib/firebase.ts';

export async function getAuthToken(): Promise<string> {
  if (!auth.currentUser) {
    throw new Error('Authentication required');
  }
  return await auth.currentUser.getIdToken();
}

export async function apiFetch<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = await getAuthToken();
  const res = await fetch(path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(options.headers ?? {}),
    },
  });

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    throw new Error(errBody.error || `Request failed (${res.status})`);
  }

  return (await res.json()) as T;
}

export async function downloadAuthenticatedCsv(
  path: string,
  fallbackFilename: string
): Promise<void> {
  const token = await getAuthToken();
  const res = await fetch(path, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    throw new Error(errBody.error || `CSV export failed (${res.status})`);
  }

  const blob = await res.blob();
  triggerBrowserDownload(blob, fallbackFilename);
}

export function triggerBrowserDownload(contentOrBlob: string | Blob, filename: string) {
  const blob =
    typeof contentOrBlob === 'string'
      ? new Blob([contentOrBlob], { type: 'text/csv;charset=utf-8;' })
      : contentOrBlob;
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
