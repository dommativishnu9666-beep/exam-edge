import type {
  PriorityLevel,
  RevisionSession,
  RevisionStatus,
  Subject,
  SyllabusTopic,
  TopicStatus,
} from '../types/examedge.ts';

export interface CsvTopicImportRow {
  subjectCode: string;
  subjectName?: string;
  unitNumber: number;
  unitName: string;
  topicTitle: string;
  priority: PriorityLevel;
  estimatedHours: number;
  status: TopicStatus;
  notes: string;
}

export interface CsvRevisionImportRow {
  subjectCode: string;
  subjectName?: string;
  topicTitle: string;
  sessionDate: string;
  startTime: string;
  endTime: string;
  priority: PriorityLevel;
  status: RevisionStatus;
  notes: string;
}

export interface CsvParseResult<T> {
  rows: T[];
  errors: string[];
  totalDataRows: number;
}

/**
 * RFC-4180 compliant CSV parser supporting quoted fields, embedded commas,
 * escaped quotes (""), CRLF/LF line endings, and UTF-8 BOM removal.
 */
export function parseCsvMatrix(rawText: string): string[][] {
  const cleanText = rawText.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < cleanText.length; i++) {
    const ch = cleanText[i];
    const next = cleanText[i + 1];

    if (inQuotes) {
      if (ch === '"' && next === '"') {
        currentField += '"';
        i++;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        currentField += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      currentRow.push(currentField.trim());
      currentField = '';
    } else if (ch === '\r' && next === '\n') {
      currentRow.push(currentField.trim());
      if (currentRow.some((cell) => cell.length > 0)) {
        rows.push(currentRow);
      }
      currentRow = [];
      currentField = '';
      i++;
    } else if (ch === '\n' || ch === '\r') {
      currentRow.push(currentField.trim());
      if (currentRow.some((cell) => cell.length > 0)) {
        rows.push(currentRow);
      }
      currentRow = [];
      currentField = '';
    } else {
      currentField += ch;
    }
  }

  if (currentField.length > 0 || currentRow.length > 0) {
    currentRow.push(currentField.trim());
    if (currentRow.some((cell) => cell.length > 0)) {
      rows.push(currentRow);
    }
  }

  return rows;
}

function normalizeHeader(h: string): string {
  return h.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function normalizePriority(val: string): PriorityLevel {
  const v = val.trim().toLowerCase();
  if (v === 'high') return 'High';
  if (v === 'low') return 'Low';
  return 'Medium';
}

function normalizeTopicStatus(val: string): TopicStatus {
  const v = val.trim().toLowerCase();
  if (v === 'completed' || v === 'done') return 'Completed';
  if (v === 'in progress' || v === 'inprogress' || v === 'active') {
    return 'In Progress';
  }
  return 'Not Started';
}

function normalizeRevisionStatus(val: string): RevisionStatus {
  const v = val.trim().toLowerCase();
  if (v === 'completed' || v === 'done') return 'Completed';
  if (v === 'missed') return 'Missed';
  return 'Pending';
}

function isISODate(val: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(val)) return false;
  const [y, m, d] = val.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

function normalizeTime24(val: string): string | null {
  const trimmed = val.trim();
  const match = trimmed.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const hh = Number(match[1]);
  const mm = Number(match[2]);
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

export function parseTopicsCsv(
  rawText: string,
  fallbackSubject?: Subject | null
): CsvParseResult<CsvTopicImportRow> {
  const matrix = parseCsvMatrix(rawText);
  if (matrix.length < 2) {
    return {
      rows: [],
      errors: [
        'CSV must include a header row and at least one syllabus topic row.',
      ],
      totalDataRows: 0,
    };
  }

  const headers = matrix[0].map(normalizeHeader);
  const findCol = (aliases: string[]) =>
    headers.findIndex((h) => aliases.includes(h));

  const colSubjectCode = findCol(['subjectcode', 'code', 'coursecode']);
  const colSubjectName = findCol(['subjectname', 'subject', 'coursename']);
  const colUnitNo = findCol(['unitno', 'unitnumber', 'unit']);
  const colUnitName = findCol(['unitname', 'modulename', 'chapter']);
  const colTopic = findCol([
    'topictitle',
    'topic',
    'topics',
    'topicscovered',
    'title',
  ]);
  const colPriority = findCol(['priority']);
  const colHours = findCol(['estimatedhours', 'esthours', 'hours']);
  const colStatus = findCol(['status']);
  const colNotes = findCol(['notes', 'note', 'studyNotes']);

  if (colTopic === -1 || colUnitName === -1) {
    return {
      rows: [],
      errors: [
        'Missing required columns: "Unit Name" and "Topic Title" (or "Topics").',
      ],
      totalDataRows: matrix.length - 1,
    };
  }

  const rows: CsvTopicImportRow[] = [];
  const errors: string[] = [];
  const dataRows = matrix.slice(1);

  for (let i = 0; i < dataRows.length; i++) {
    const cells = dataRows[i];
    const lineNum = i + 2;
    const rawCode =
      colSubjectCode >= 0
        ? cells[colSubjectCode] ?? ''
        : fallbackSubject?.code ?? '';
    const subjectCode = rawCode.trim().toUpperCase();
    const subjectName =
      colSubjectName >= 0
        ? (cells[colSubjectName] ?? '').trim()
        : fallbackSubject?.name;
    const unitName = (cells[colUnitName] ?? '').trim();
    const topicTitle = (cells[colTopic] ?? '').trim();
    const unitRaw = colUnitNo >= 0 ? Number(cells[colUnitNo]) : i + 1;
    const hoursRaw = colHours >= 0 ? Number(cells[colHours]) : 2;

    if (!subjectCode) {
      errors.push(`Row ${lineNum}: Missing Subject Code.`);
      continue;
    }
    if (!unitName) {
      errors.push(`Row ${lineNum}: Unit Name cannot be empty.`);
      continue;
    }
    if (!topicTitle) {
      errors.push(`Row ${lineNum}: Topic Title cannot be empty.`);
      continue;
    }

    rows.push({
      subjectCode: subjectCode.slice(0, 20),
      subjectName: subjectName ? subjectName.slice(0, 120) : undefined,
      unitNumber:
        Number.isInteger(unitRaw) && unitRaw >= 1 && unitRaw <= 50
          ? unitRaw
          : i + 1,
      unitName: unitName.slice(0, 120),
      topicTitle: topicTitle.slice(0, 240),
      priority:
        colPriority >= 0 ? normalizePriority(cells[colPriority] ?? '') : 'Medium',
      estimatedHours:
        Number.isFinite(hoursRaw) && hoursRaw >= 1 && hoursRaw <= 60
          ? Math.round(hoursRaw)
          : 2,
      status:
        colStatus >= 0
          ? normalizeTopicStatus(cells[colStatus] ?? '')
          : 'Not Started',
      notes: colNotes >= 0 ? (cells[colNotes] ?? '').slice(0, 1000) : '',
    });
  }

  return { rows, errors, totalDataRows: dataRows.length };
}

export function parseRevisionsCsv(
  rawText: string,
  fallbackSubject?: Subject | null
): CsvParseResult<CsvRevisionImportRow> {
  const matrix = parseCsvMatrix(rawText);
  if (matrix.length < 2) {
    return {
      rows: [],
      errors: [
        'CSV must include a header row and at least one revision session row.',
      ],
      totalDataRows: 0,
    };
  }

  const headers = matrix[0].map(normalizeHeader);
  const findCol = (aliases: string[]) =>
    headers.findIndex((h) => aliases.includes(h));

  const colSubjectCode = findCol(['subjectcode', 'code', 'coursecode']);
  const colSubjectName = findCol(['subjectname', 'subject', 'coursename']);
  const colTopic = findCol(['topictitle', 'topic', 'title']);
  const colDate = findCol(['sessiondate', 'date']);
  const colStart = findCol(['starttime', 'start']);
  const colEnd = findCol(['endtime', 'end']);
  const colPriority = findCol(['priority']);
  const colStatus = findCol(['status']);
  const colNotes = findCol(['notes', 'note']);

  if (colTopic === -1 || colDate === -1 || colStart === -1 || colEnd === -1) {
    return {
      rows: [],
      errors: [
        'Missing required columns: "Topic Title", "Date" (YYYY-MM-DD), "Start Time", and "End Time".',
      ],
      totalDataRows: matrix.length - 1,
    };
  }

  const rows: CsvRevisionImportRow[] = [];
  const errors: string[] = [];
  const dataRows = matrix.slice(1);

  for (let i = 0; i < dataRows.length; i++) {
    const cells = dataRows[i];
    const lineNum = i + 2;
    const rawCode =
      colSubjectCode >= 0
        ? cells[colSubjectCode] ?? ''
        : fallbackSubject?.code ?? '';
    const subjectCode = rawCode.trim().toUpperCase();
    const subjectName =
      colSubjectName >= 0
        ? (cells[colSubjectName] ?? '').trim()
        : fallbackSubject?.name;
    const topicTitle = (cells[colTopic] ?? '').trim();
    const sessionDate = (cells[colDate] ?? '').trim();
    const startTime = normalizeTime24(cells[colStart] ?? '');
    const endTime = normalizeTime24(cells[colEnd] ?? '');

    if (!subjectCode) {
      errors.push(`Row ${lineNum}: Missing Subject Code.`);
      continue;
    }
    if (!topicTitle) {
      errors.push(`Row ${lineNum}: Missing Topic Title.`);
      continue;
    }
    if (!isISODate(sessionDate)) {
      errors.push(
        `Row ${lineNum}: Date "${sessionDate}" must use YYYY-MM-DD format.`
      );
      continue;
    }
    if (!startTime || !endTime || endTime <= startTime) {
      errors.push(
        `Row ${lineNum}: Start/End time must be valid HH:MM with End Time later than Start Time.`
      );
      continue;
    }

    rows.push({
      subjectCode: subjectCode.slice(0, 20),
      subjectName: subjectName ? subjectName.slice(0, 120) : undefined,
      topicTitle: topicTitle.slice(0, 240),
      sessionDate,
      startTime,
      endTime,
      priority:
        colPriority >= 0 ? normalizePriority(cells[colPriority] ?? '') : 'Medium',
      status:
        colStatus >= 0
          ? normalizeRevisionStatus(cells[colStatus] ?? '')
          : 'Pending',
      notes: colNotes >= 0 ? (cells[colNotes] ?? '').slice(0, 1000) : '',
    });
  }

  return { rows, errors, totalDataRows: dataRows.length };
}

function escapeCsvCell(value: string | number | null | undefined): string {
  const raw = value === null || value === undefined ? '' : String(value);
  // Protect against CSV formula injection in spreadsheet tools
  const safe = /^[=+\-@\t\r]/.test(raw) ? `'${raw}` : raw;
  if (/[",\r\n]/.test(safe)) {
    return `"${safe.replace(/"/g, '""')}"`;
  }
  return safe;
}

export function buildTopicsCsv(
  topics: SyllabusTopic[],
  subjects: Subject[]
): string {
  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const header = [
    'Subject Code',
    'Subject Name',
    'Unit No',
    'Unit Name',
    'Topic Title',
    'Priority',
    'Estimated Hours',
    'Status',
    'Notes',
  ];
  const lines = [
    header.map(escapeCsvCell).join(','),
    ...topics.map((t) => {
      const subj = subjectMap.get(t.subjectId);
      return [
        subj?.code ?? '',
        subj?.name ?? '',
        t.unitNumber,
        t.unitName,
        t.topicTitle,
        t.priority,
        t.estimatedHours,
        t.status,
        t.notes,
      ]
        .map(escapeCsvCell)
        .join(',');
    }),
  ];
  return lines.join('\r\n');
}

export function buildRevisionsCsv(
  revisions: RevisionSession[],
  subjects: Subject[]
): string {
  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const header = [
    'Subject Code',
    'Subject Name',
    'Topic Title',
    'Date',
    'Start Time',
    'End Time',
    'Duration Minutes',
    'Priority',
    'Status',
    'Notes',
  ];
  const lines = [
    header.map(escapeCsvCell).join(','),
    ...revisions.map((r) => {
      const subj = subjectMap.get(r.subjectId);
      return [
        subj?.code ?? '',
        subj?.name ?? '',
        r.topicTitle,
        r.sessionDate,
        r.startTime,
        r.endTime,
        r.durationMinutes,
        r.priority,
        r.status,
        r.notes,
      ]
        .map(escapeCsvCell)
        .join(',');
    }),
  ];
  return lines.join('\r\n');
}

export function downloadCsvFile(filename: string, csvContent: string) {
  const blob = new Blob([`\uFEFF${csvContent}`], {
    type: 'text/csv;charset=utf-8;',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export const TOPICS_CSV_TEMPLATE = [
  'Subject Code,Subject Name,Unit No,Unit Name,Topic Title,Priority,Estimated Hours,Status,Notes',
  'CS201,Data Structures & Algorithms,6,Dynamic Programming,0/1 Knapsack & Longest Common Subsequence,High,4,Not Started,Solve 10 classic DP problems',
  'MA204,Engineering Mathematics,6,Numerical Methods,Newton-Raphson & Runge-Kutta Method,Medium,3,In Progress,Practice step-by-step error tables',
].join('\r\n');

export function buildRevisionsCsvTemplate(todayISO: string): string {
  return [
    'Subject Code,Subject Name,Topic Title,Date,Start Time,End Time,Priority,Status,Notes',
    `CS201,Data Structures & Algorithms,Graph Traversals & Shortest Paths,${todayISO},18:00,19:30,High,Pending,Review Dijkstra and Bellman-Ford`,
    `MA204,Engineering Mathematics,Fourier Series Practice,${todayISO},20:00,21:00,Medium,Pending,Solve past paper integrals`,
  ].join('\r\n');
}
