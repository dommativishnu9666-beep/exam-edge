import type {
  PriorityLevel,
  RevisionSession,
  Subject,
  SyllabusTopic,
} from '../types/examedge.ts';

export interface AutoScheduleRequest {
  startDate: string;
  endDate: string;
  sessionsPerDay: number;
  durationMinutes: number;
  preferredWindow: 'morning' | 'afternoon' | 'evening';
  subjectId?: number | null;
}

export interface ProposedRevisionSlot {
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  topicId: number;
  topicTitle: string;
  sessionDate: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  priority: PriorityLevel;
  notes: string;
}

function parseMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

function formatMinutes(total: number): string {
  const clamped = Math.min(23 * 60 + 59, Math.max(0, total));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function addDaysISO(iso: string, offset: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(y, m - 1, d + offset);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

function diffDays(fromISO: string, toISO: string): number {
  const [fy, fm, fd] = fromISO.split('-').map(Number);
  const [ty, tm, td] = toISO.split('-').map(Number);
  const fromDt = new Date(fy, fm - 1, fd).getTime();
  const toDt = new Date(ty, tm - 1, td).getTime();
  return Math.round((toDt - fromDt) / (1000 * 60 * 60 * 24));
}

const WINDOW_BASE_MINUTES: Record<
  AutoScheduleRequest['preferredWindow'],
  number
> = {
  morning: 8 * 60 + 30, // 08:30
  afternoon: 14 * 60, // 14:00
  evening: 18 * 60 + 30, // 18:30
};

export function generateAutoRevisionSchedule(
  subjectsList: Subject[],
  topicsList: SyllabusTopic[],
  existingRevisions: RevisionSession[],
  options: AutoScheduleRequest
): ProposedRevisionSlot[] {
  const subjectById = new Map(subjectsList.map((s) => [s.id, s]));

  // Select candidate topics: uncompleted topics, optionally filtered by subject
  const candidateTopics = topicsList.filter((t) => {
    if (t.status === 'Completed') return false;
    if (options.subjectId && t.subjectId !== options.subjectId) return false;
    return subjectById.has(t.subjectId);
  });

  if (candidateTopics.length === 0) return [];

  // Score each topic by exam urgency + topic priority + in-progress momentum
  const scoredTopics = candidateTopics
    .map((topic) => {
      const subj = subjectById.get(topic.subjectId)!;
      const daysUntilExam = Math.max(
        1,
        diffDays(options.startDate, subj.examDate)
      );
      const urgencyScore = Math.max(0, 45 - daysUntilExam) * 1.5;
      const priorityScore =
        topic.priority === 'High' ? 30 : topic.priority === 'Medium' ? 18 : 8;
      const momentumBonus = topic.status === 'In Progress' ? 10 : 0;
      const hoursWeight = Math.min(10, topic.estimatedHours);
      return {
        topic,
        subj,
        score: urgencyScore + priorityScore + momentumBonus + hoursWeight,
      };
    })
    .sort((a, b) => b.score - a.score);

  const totalDays = Math.min(
    60,
    Math.max(1, diffDays(options.startDate, options.endDate) + 1)
  );

  // Build occupied intervals per date from Pending revisions so we never double-book
  const occupiedByDate = new Map<
    string,
    Array<{ start: number; end: number }>
  >();
  for (const rev of existingRevisions) {
    if (rev.status === 'Missed') continue;
    const arr = occupiedByDate.get(rev.sessionDate) ?? [];
    arr.push({
      start: parseMinutes(rev.startTime),
      end: parseMinutes(rev.endTime),
    });
    occupiedByDate.set(rev.sessionDate, arr);
  }

  // Skip topics that already have an upcoming Pending revision inside the date window
  const alreadyScheduledTopicIds = new Set<number>();
  for (const rev of existingRevisions) {
    if (
      rev.status === 'Pending' &&
      rev.topicId &&
      rev.sessionDate >= options.startDate &&
      rev.sessionDate <= options.endDate
    ) {
      alreadyScheduledTopicIds.add(rev.topicId);
    }
  }

  const queue = scoredTopics.filter(
    (item) => !alreadyScheduledTopicIds.has(item.topic.id)
  );
  if (queue.length === 0) {
    // Allow repeating top-priority topics if all uncompleted topics already have 1 session
    queue.push(...scoredTopics);
  }

  const proposals: ProposedRevisionSlot[] = [];
  let topicCursor = 0;

  for (let dayIdx = 0; dayIdx < totalDays && topicCursor < queue.length; dayIdx++) {
    const dateISO = addDaysISO(options.startDate, dayIdx);
    const dayOccupied = occupiedByDate.get(dateISO) ?? [];

    let candidateStart = WINDOW_BASE_MINUTES[options.preferredWindow];
    let scheduledToday = 0;

    while (
      scheduledToday < options.sessionsPerDay &&
      topicCursor < queue.length &&
      candidateStart + options.durationMinutes <= 22 * 60 + 30
    ) {
      const candidateEnd = candidateStart + options.durationMinutes;
      const overlaps = dayOccupied.some(
        (slot) => candidateStart < slot.end && candidateEnd > slot.start
      );

      if (overlaps) {
        candidateStart += 30;
        continue;
      }

      const { topic, subj } = queue[topicCursor++];
      proposals.push({
        subjectId: subj.id,
        subjectCode: subj.code,
        subjectName: subj.name,
        topicId: topic.id,
        topicTitle: topic.topicTitle,
        sessionDate: dateISO,
        startTime: formatMinutes(candidateStart),
        endTime: formatMinutes(candidateEnd),
        durationMinutes: options.durationMinutes,
        priority: topic.priority,
        notes: `Auto-scheduled for ${subj.code} (Exam ${subj.examDate})`,
      });

      dayOccupied.push({ start: candidateStart, end: candidateEnd });
      occupiedByDate.set(dateISO, dayOccupied);
      scheduledToday++;
      candidateStart = candidateEnd + 15; // 15-minute break between consecutive blocks
    }
  }

  return proposals;
}
