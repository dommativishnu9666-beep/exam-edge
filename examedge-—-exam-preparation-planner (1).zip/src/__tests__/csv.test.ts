import { describe, expect, it } from 'vitest';
import {
  buildSampleImportTemplateCsv,
  exportRevisionsToCsv,
  exportStudyLogsToCsv,
  exportSubjectsToCsv,
  exportTopicsToCsv,
  parseAndValidateSubjectsTopicsCsv,
  parseCsvMatrix,
  sanitizeCsvCellForExport,
  sanitizeImportedText,
} from '../utils/csv.ts';
import type {
  RevisionSession,
  StudyLog,
  Subject,
  SyllabusTopic,
} from '../types/examedge.ts';

describe('CSV Utilities & Security', () => {
  it('parses RFC-4180 quoted fields, escaped quotes, and embedded newlines', () => {
    const raw = [
      'subject_code,subject_name,notes',
      '"CS201","Data Structures, Algorithms","Line 1\n""Quoted"" line 2"',
      'MA102,Linear Algebra,Simple note',
    ].join('\r\n');

    const matrix = parseCsvMatrix(raw);
    expect(matrix).toHaveLength(3);
    expect(matrix[1]).toEqual([
      'CS201',
      'Data Structures, Algorithms',
      'Line 1\n"Quoted" line 2',
    ]);
    expect(matrix[2]).toEqual(['MA102', 'Linear Algebra', 'Simple note']);
  });

  it('neutralizes CSV formula injection payloads on export and strips triggers on import', () => {
    expect(sanitizeCsvCellForExport('=CMD|"/C calc"!A0')).toBe(
      '"\'=CMD|""/C calc""!A0"'
    );
    expect(sanitizeCsvCellForExport('+1+1')).toBe("'+1+1");
    expect(sanitizeCsvCellForExport('-2*3')).toBe("'-2*3");
    expect(sanitizeCsvCellForExport('@SUM(A1:A2)')).toBe("'@SUM(A1:A2)");

    expect(sanitizeImportedText('=HYPERLINK("http://evil")')).toBe(
      'HYPERLINK("http://evil")'
    );
    expect(sanitizeImportedText('  +malicious\x07text  ')).toBe('malicioustext');
  });

  it('reports missing required CSV headers cleanly', () => {
    const raw = 'subject_code,topic_title\nCS101,Intro';
    const result = parseAndValidateSubjectsTopicsCsv(raw, [], []);
    expect(result.validRows).toHaveLength(0);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]?.field).toBe('header');
    expect(result.errors[0]?.message).toContain('subject_name');
  });

  it('performs row-by-row validation and detects in-file and existing database duplicates', () => {
    const raw = [
      'subject_code,subject_name,subject_color,exam_date,unit_number,unit_name,topic_title,priority,estimated_hours,status,notes',
      'CS201,Data Structures,indigo,2026-06-15,1,Trees,Binary Search Trees,High,3,Not Started,Valid new topic',
      'CS201,Data Structures,indigo,2026-06-15,1,Trees,Binary Search Trees,High,3,Not Started,In-file duplicate',
      'MA101,Calculus,blue,2026-06-20,1,Limits,Epsilon-Delta Limits,Medium,2,In Progress,Exists in DB',
      'X,Bad Row,indigo,15-06-2026,0,,A,High,0,Not Started,Multiple field errors',
    ].join('\n');

    const result = parseAndValidateSubjectsTopicsCsv(
      raw,
      [{ id: 10, code: 'MA101' }],
      [{ subjectId: 10, unitNumber: 1, topicTitle: 'Epsilon-Delta Limits' }]
    );

    expect(result.totalRows).toBe(4);
    expect(result.validRows).toHaveLength(1);
    expect(result.validRows[0]?.topic_title).toBe('Binary Search Trees');

    expect(result.duplicates).toHaveLength(2);
    expect(result.duplicates[0]?.row).toBe(3);
    expect(result.duplicates[0]?.reason).toContain('Duplicate entry inside uploaded CSV');
    expect(result.duplicates[1]?.row).toBe(4);
    expect(result.duplicates[1]?.reason).toContain('Already exists');

    const row5Errors = result.errors.filter((e) => e.row === 5);
    expect(row5Errors.length).toBeGreaterThanOrEqual(4);
  });

  it('exports subjects, topics, revisions, study logs, and sample template safely', () => {
    const subjects: Subject[] = [
      {
        id: 1,
        name: '=Malicious Subject',
        code: 'CS101',
        color: 'indigo',
        icon: 'book',
        examDate: '2026-06-01',
        priority: 'High',
      },
    ];
    const topics: SyllabusTopic[] = [
      {
        id: 100,
        subjectId: 1,
        unitNumber: 1,
        unitName: 'Foundations',
        topicTitle: 'Asymptotic Notation',
        priority: 'High',
        estimatedHours: 2,
        status: 'Completed',
        notes: 'Big-O & Theta',
      },
    ];
    const revisions: RevisionSession[] = [
      {
        id: 200,
        subjectId: 1,
        topicId: 100,
        topicTitle: 'Asymptotic Notation',
        sessionDate: '2026-05-10',
        startTime: '09:00',
        endTime: '10:00',
        durationMinutes: 60,
        priority: 'High',
        status: 'Pending',
        notes: 'Practice recurrences',
      },
    ];
    const logs: StudyLog[] = [
      {
        id: 300,
        logDate: '2026-05-09',
        minutes: 45,
        actionType: 'topic_completed',
        description: 'Completed Asymptotic Notation',
      },
    ];

    const subCsv = exportSubjectsToCsv(subjects, topics);
    expect(subCsv).toContain("'=Malicious Subject");
    expect(subCsv).toContain('100%');

    const topCsv = exportTopicsToCsv(subjects, topics);
    expect(topCsv).toContain('Asymptotic Notation');

    const revCsv = exportRevisionsToCsv(subjects, revisions);
    expect(revCsv).toContain('09:00,10:00,60');

    const logCsv = exportStudyLogsToCsv(logs);
    expect(logCsv).toContain('topic_completed');

    const template = buildSampleImportTemplateCsv('2026-06-15');
    expect(template).toContain('CS201');
  });
});
