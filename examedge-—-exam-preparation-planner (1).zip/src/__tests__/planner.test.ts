import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildRevisionsCsv,
  buildTopicsCsv,
  parseCsvMatrix,
  parseRevisionsCsv,
  parseTopicsCsv,
} from '../utils/csv.ts';
import {
  isValidISODate,
  isValidTime24,
  validateRevisionPatch,
  validateSubjectPatch,
  validateTopicPatch,
} from '../validation/schemas.ts';

test('parseCsvMatrix handles quoted commas, escaped quotes, CRLF, and BOM', () => {
  const input =
    '\uFEFFCode,Topic,Notes\r\nCS201,"Trees, Graphs & Heaps","Use ""BFS"" first"\r\nMA204,Calculus,Review integrals\n';
  const matrix = parseCsvMatrix(input);
  assert.equal(matrix.length, 3);
  assert.deepEqual(matrix[1], [
    'CS201',
    'Trees, Graphs & Heaps',
    'Use "BFS" first',
  ]);
});

test('parseTopicsCsv validates required fields and normalizes rows', () => {
  const csv = [
    'Subject Code,Subject Name,Unit No,Unit Name,Topic Title,Priority,Estimated Hours,Status,Notes',
    'cs201,Algorithms,2,Trees,AVL Rotations,high,4,in progress,Practice rotations',
    ',Missing Code,3,Graphs,DFS,Medium,2,Not Started,',
  ].join('\n');

  const res = parseTopicsCsv(csv);
  assert.equal(res.rows.length, 1);
  assert.equal(res.errors.length, 1);
  assert.equal(res.rows[0].subjectCode, 'CS201');
  assert.equal(res.rows[0].priority, 'High');
  assert.equal(res.rows[0].status, 'In Progress');
});

test('parseRevisionsCsv rejects invalid dates and endTime <= startTime', () => {
  const csv = [
    'Subject Code,Topic Title,Date,Start Time,End Time,Priority,Status,Notes',
    'CS201,Dynamic Programming,2026-11-25,14:00,15:30,High,Pending,Solve DP',
    'CS201,Bad Time,2026-11-25,16:00,15:00,Medium,Pending,Invalid range',
    'CS201,Bad Date,2026-02-30,09:00,10:00,Low,Pending,Invalid leap date',
  ].join('\n');

  const res = parseRevisionsCsv(csv);
  assert.equal(res.rows.length, 1);
  assert.equal(res.errors.length, 2);
});

test('CSV export neutralizes spreadsheet formula injection prefixes', () => {
  const subjects = [
    {
      id: 1,
      userId: 1,
      name: 'Algorithms',
      code: 'CS201',
      color: 'indigo' as const,
      icon: 'code',
      examDate: '2026-12-01',
      priority: 'High' as const,
    },
  ];
  const topics = [
    {
      id: 10,
      userId: 1,
      subjectId: 1,
      unitNumber: 1,
      unitName: 'Basics',
      topicTitle: '=CMD|calc',
      priority: 'High' as const,
      estimatedHours: 2,
      status: 'Not Started' as const,
      notes: '+dangerous',
      completedAt: null,
    },
  ];
  const revisions = [
    {
      id: 20,
      userId: 1,
      subjectId: 1,
      topicId: null,
      topicTitle: '@formula',
      sessionDate: '2026-11-25',
      startTime: '09:00',
      endTime: '10:00',
      durationMinutes: 60,
      priority: 'Medium' as const,
      status: 'Pending' as const,
      notes: '-inject',
    },
  ];

  const topicsCsv = buildTopicsCsv(topics, subjects);
  assert.ok(topicsCsv.includes("'=CMD|calc"));
  assert.ok(topicsCsv.includes("'+dangerous"));

  const revCsv = buildRevisionsCsv(revisions, subjects);
  assert.ok(revCsv.includes("'@formula"));
  assert.ok(revCsv.includes("'-inject"));
});

test('server validation schemas enforce dates, times, and allowed enums', () => {
  assert.equal(isValidISODate('2026-11-20'), true);
  assert.equal(isValidISODate('2026-02-30'), false);
  assert.equal(isValidTime24('09:30'), true);
  assert.equal(isValidTime24('24:00'), false);

  const validSub = validateSubjectPatch(
    {
      name: 'Operating Systems',
      code: 'cs301',
      color: 'cyan',
      icon: 'code',
      examDate: '2026-12-10',
      priority: 'High',
    },
    true
  );
  assert.ok('data' in validSub && validSub.data);
  assert.equal(validSub.data.code, 'CS301');

  const badRev = validateRevisionPatch(
    {
      subjectId: 1,
      topicTitle: 'Paging',
      sessionDate: '2026-12-01',
      startTime: '14:00',
      endTime: '13:00',
    },
    true
  );
  assert.ok('error' in badRev);

  const goodTopic = validateTopicPatch(
    {
      subjectId: 1,
      unitNumber: 3,
      unitName: 'Memory',
      topicTitle: 'Virtual Memory',
      priority: 'High',
      estimatedHours: 4,
      status: 'In Progress',
      notes: 'Page tables',
    },
    true
  );
  assert.ok('data' in goodTopic);
});
