import { describe, expect, it } from 'vitest';
import {
  autoScheduleSchema,
  createRevisionSchema,
  createSubjectSchema,
  csvImportPayloadSchema,
  paginatedTopicsQuerySchema,
} from '../validation/schemas.ts';

describe('Zod Request & Payload Validation Schemas', () => {
  it('normalizes subject codes to uppercase and rejects invalid exam dates', () => {
    const valid = createSubjectSchema.parse({
      name: 'Computer Networks',
      code: 'cs401',
      color: 'cyan',
      examDate: '2026-06-18',
      priority: 'High',
    });
    expect(valid.code).toBe('CS401');

    const invalid = createSubjectSchema.safeParse({
      name: 'Computer Networks',
      code: 'cs401',
      examDate: '18/06/2026',
    });
    expect(invalid.success).toBe(false);
  });

  it('enforces endTime > startTime on revision sessions', () => {
    const invalid = createRevisionSchema.safeParse({
      subjectId: 1,
      topicTitle: 'TCP Congestion Control',
      sessionDate: '2026-05-20',
      startTime: '14:00',
      endTime: '13:30',
    });
    expect(invalid.success).toBe(false);

    const valid = createRevisionSchema.safeParse({
      subjectId: 1,
      topicTitle: 'TCP Congestion Control',
      sessionDate: '2026-05-20',
      startTime: '14:00',
      endTime: '15:00',
    });
    expect(valid.success).toBe(true);
  });

  it('enforces .csv extension and 1 MB size cap on CSV import payloads', () => {
    const badExt = csvImportPayloadSchema.safeParse({
      fileName: 'syllabus.xlsx',
      csvContent: 'a,b\n1,2',
    });
    expect(badExt.success).toBe(false);

    const oversized = csvImportPayloadSchema.safeParse({
      fileName: 'syllabus.csv',
      csvContent: 'x'.repeat(1024 * 1024 + 10),
    });
    expect(oversized.success).toBe(false);

    const valid = csvImportPayloadSchema.safeParse({
      fileName: 'Syllabus.CSV',
      csvContent: 'subject_code,subject_name\nCS101,Intro',
      dryRun: true,
    });
    expect(valid.success).toBe(true);
  });

  it('validates auto-schedule date range and paginated topic query defaults', () => {
    const badRange = autoScheduleSchema.safeParse({
      startDate: '2026-05-20',
      endDate: '2026-05-10',
    });
    expect(badRange.success).toBe(false);

    const defaults = paginatedTopicsQuerySchema.parse({});
    expect(defaults.page).toBe(1);
    expect(defaults.pageSize).toBe(10);
    expect(defaults.sortBy).toBe('unitNumber');
    expect(defaults.sortDir).toBe('asc');
  });
});
