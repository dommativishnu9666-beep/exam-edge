import { describe, expect, it } from 'vitest';
import { generateAutoRevisionSchedule } from '../utils/scheduler.ts';
import type {
  RevisionSession,
  Subject,
  SyllabusTopic,
} from '../types/examedge.ts';

const sampleSubjects: Subject[] = [
  {
    id: 1,
    name: 'Operating Systems',
    code: 'CS301',
    color: 'indigo',
    icon: 'cpu',
    examDate: '2026-05-25', // Urgent exam
    priority: 'High',
  },
  {
    id: 2,
    name: 'Discrete Mathematics',
    code: 'MA201',
    color: 'blue',
    icon: 'calculator',
    examDate: '2026-06-20', // Later exam
    priority: 'Medium',
  },
];

const sampleTopics: SyllabusTopic[] = [
  {
    id: 11,
    subjectId: 1,
    unitNumber: 1,
    unitName: 'Processes',
    topicTitle: 'CPU Scheduling Algorithms',
    priority: 'High',
    estimatedHours: 4,
    status: 'In Progress',
    notes: '',
  },
  {
    id: 12,
    subjectId: 1,
    unitNumber: 2,
    unitName: 'Memory',
    topicTitle: 'Page Replacement Policies',
    priority: 'Medium',
    estimatedHours: 3,
    status: 'Completed', // Should be skipped
    notes: '',
  },
  {
    id: 21,
    subjectId: 2,
    unitNumber: 1,
    unitName: 'Graph Theory',
    topicTitle: 'Planar Graphs & Coloring',
    priority: 'Low',
    estimatedHours: 2,
    status: 'Not Started',
    notes: '',
  },
];

describe('Automatic Revision Scheduler', () => {
  it('prioritizes urgent exams and uncompleted topics while skipping completed topics', () => {
    const proposals = generateAutoRevisionSchedule(
      sampleSubjects,
      sampleTopics,
      [],
      {
        startDate: '2026-05-10',
        endDate: '2026-05-12',
        sessionsPerDay: 2,
        durationMinutes: 60,
        preferredWindow: 'morning',
      }
    );

    expect(proposals).toHaveLength(2);
    expect(proposals[0]?.topicId).toBe(11);
    expect(proposals[1]?.topicId).toBe(21);
    expect(proposals.some((p) => p.topicId === 12)).toBe(false);
    expect(proposals[0]?.startTime).toBe('08:30');
    expect(proposals[0]?.endTime).toBe('09:30');
    // 15 minute break between consecutive slots
    expect(proposals[1]?.startTime).toBe('09:45');
    expect(proposals[1]?.endTime).toBe('10:45');
  });

  it('avoids overlapping existing Pending or Completed revision blocks', () => {
    const existing: RevisionSession[] = [
      {
        id: 500,
        subjectId: 2,
        topicId: 999,
        topicTitle: 'Existing Morning Block',
        sessionDate: '2026-05-10',
        startTime: '08:30',
        endTime: '09:30',
        durationMinutes: 60,
        priority: 'High',
        status: 'Pending',
        notes: '',
      },
    ];

    const proposals = generateAutoRevisionSchedule(
      sampleSubjects,
      sampleTopics,
      existing,
      {
        startDate: '2026-05-10',
        endDate: '2026-05-10',
        sessionsPerDay: 1,
        durationMinutes: 60,
        preferredWindow: 'morning',
      }
    );

    expect(proposals).toHaveLength(1);
    // Shifted in 30-min increments until conflict-free (09:30-10:30)
    expect(proposals[0]?.startTime).toBe('09:30');
    expect(proposals[0]?.endTime).toBe('10:30');
  });

  it('filters proposals by selected subjectId', () => {
    const proposals = generateAutoRevisionSchedule(
      sampleSubjects,
      sampleTopics,
      [],
      {
        startDate: '2026-05-10',
        endDate: '2026-05-12',
        sessionsPerDay: 2,
        durationMinutes: 45,
        preferredWindow: 'evening',
        subjectId: 2,
      }
    );

    expect(proposals).toHaveLength(1);
    expect(proposals[0]?.subjectId).toBe(2);
    expect(proposals[0]?.startTime).toBe('18:30');
    expect(proposals[0]?.endTime).toBe('19:15');
  });
});
