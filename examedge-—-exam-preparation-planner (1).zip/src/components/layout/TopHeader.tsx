import { useState } from 'react';
import {
  Bell,
  CalendarPlus,
  Check,
  Clock,
  Menu,
  Moon,
  Sun,
} from 'lucide-react';
import { usePlanner } from '../../context/PlannerContext.tsx';
import { formatShortDate, type AppPage } from '../../types/examedge.ts';
import { shiftDateISO } from '../../data/demoSeed.ts';

interface TopHeaderProps {
  currentPage: AppPage;
  selectedSubjectName?: string;
  onOpenMobileDrawer: () => void;
  onQuickAddRevision: () => void;
  onNavigate: (page: AppPage) => void;
}

const PAGE_LABELS: Record<AppPage, string> = {
  landing: 'Home',
  dashboard: 'Dashboard',
  subjects: 'My Subjects',
  syllabus: 'Syllabus Tracker',
  calendar: 'Revision Calendar',
  tips: 'Study Tips',
  analytics: 'Progress Analytics',
  settings: 'Settings & Profile',
  help: 'Help & Support',
};

export function TopHeader({
  currentPage,
  selectedSubjectName,
  onOpenMobileDrawer,
  onQuickAddRevision,
  onNavigate,
}: TopHeaderProps) {
  const { planner, isDemoMode, setTheme, signInWithGoogle, updateRevision } =
    usePlanner();
  const [notifOpen, setNotifOpen] = useState(false);

  const today = shiftDateISO(0);
  const tomorrow = shiftDateISO(1);
  const upcomingReminders = planner.revisions.filter(
    (r) =>
      r.status === 'Pending' &&
      (r.sessionDate === today || r.sessionDate === tomorrow)
  );

  const isDark = planner.profile.theme === 'dark';

  return (
    <header className="sticky top-0 z-30 h-16 px-4 sm:px-6 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileDrawer}
          aria-label="Open navigation menu"
          className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        <nav
          aria-label="Breadcrumb"
          className="flex items-center gap-2 text-sm min-w-0"
        >
          <span className="text-slate-500 dark:text-slate-400 hidden sm:inline whitespace-nowrap">
            ExamEdge
          </span>
          <span
            aria-hidden="true"
            className="text-slate-400 dark:text-slate-600 hidden sm:inline"
          >
            /
          </span>
          <span className="font-semibold text-slate-900 dark:text-white truncate">
            {PAGE_LABELS[currentPage]}
          </span>
          {selectedSubjectName && currentPage === 'syllabus' && (
            <>
              <span
                aria-hidden="true"
                className="text-slate-400 dark:text-slate-600"
              >
                /
              </span>
              <span className="text-indigo-600 dark:text-indigo-400 font-medium truncate">
                {selectedSubjectName}
              </span>
            </>
          )}
        </nav>

        {isDemoMode && (
          <button
            type="button"
            onClick={() => signInWithGoogle()}
            className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Sample Preview · Sign in to save to PostgreSQL
          </button>
        )}
      </div>

      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <button
          type="button"
          onClick={() => setTheme(isDark ? 'light' : 'dark')}
          aria-label={isDark ? 'Switch to light theme' : 'Switch to dark theme'}
          className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        <div className="relative">
          <button
            type="button"
            onClick={() => setNotifOpen((prev) => !prev)}
            aria-label="Revision reminders"
            className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            {upcomingReminders.length > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-md bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                {upcomingReminders.length}
              </span>
            )}
          </button>

          {notifOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setNotifOpen(false)}
              />
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl z-50 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
                  <span className="text-sm font-bold text-slate-900 dark:text-white">
                    Upcoming Revision Reminders
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setNotifOpen(false);
                      onNavigate('calendar');
                    }}
                    className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                  >
                    View Calendar
                  </button>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                  {upcomingReminders.length === 0 ? (
                    <div className="p-5 text-center text-sm text-slate-500 dark:text-slate-400">
                      All revisions for today and tomorrow are completed.
                    </div>
                  ) : (
                    upcomingReminders.map((rev) => {
                      const subj = planner.subjects.find(
                        (s) => s.id === rev.subjectId
                      );
                      return (
                        <div
                          key={rev.id}
                          className="p-3.5 flex items-start justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        >
                          <div className="min-w-0">
                            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                              {subj?.name ?? 'Subject'} ·{' '}
                              {rev.sessionDate === today
                                ? 'Today'
                                : formatShortDate(rev.sessionDate)}
                            </p>
                            <p className="text-sm font-semibold text-slate-900 dark:text-white truncate mt-0.5">
                              {rev.topicTitle}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-1 font-mono tabular-nums">
                              <Clock className="w-3 h-3" />
                              {rev.startTime} – {rev.endTime}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              updateRevision(rev.id, { status: 'Completed' })
                            }
                            title="Mark completed"
                            className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-300 cursor-pointer shrink-0"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        <button
          type="button"
          onClick={onQuickAddRevision}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-xs transition-all cursor-pointer whitespace-nowrap shrink-0"
        >
          <CalendarPlus className="w-4 h-4 shrink-0" />
          <span>Add Revision</span>
        </button>
      </div>
    </header>
  );
}
