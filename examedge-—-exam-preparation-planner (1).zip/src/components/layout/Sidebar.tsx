import {
  BarChart3,
  BookOpen,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
  HelpCircle,
  LayoutDashboard,
  Lightbulb,
  ListChecks,
  LogIn,
  LogOut,
  Settings,
  X,
} from 'lucide-react';
import { useState } from 'react';
import type { AppPage } from '../../types/examedge.ts';
import { usePlanner } from '../../context/PlannerContext.tsx';

interface SidebarProps {
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{
  id: AppPage;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'subjects', label: 'My Subjects', icon: BookOpen },
  { id: 'syllabus', label: 'Syllabus Tracker', icon: ListChecks },
  { id: 'calendar', label: 'Revision Calendar', icon: CalendarDays },
  { id: 'tips', label: 'Study Tips', icon: Lightbulb },
  { id: 'analytics', label: 'Progress Analytics', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'help', label: 'Help & Support', icon: HelpCircle },
];

export function Sidebar({
  currentPage,
  onNavigate,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const { planner, isDemoMode, signInWithGoogle, logout } = usePlanner();
  const [imgError, setImgError] = useState(false);

  const initials = planner.profile.fullName
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const renderNavContent = (isMobile: boolean) => (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800">
      <div className="flex items-center justify-between px-4 h-16 border-b border-slate-200 dark:border-slate-800 shrink-0">
        <button
          type="button"
          onClick={() => {
            onNavigate('landing');
            if (isMobile) onCloseMobile();
          }}
          className="flex items-center gap-2.5 text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 rounded-lg"
        >
          <span className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white shrink-0 shadow-xs">
            <GraduationCap className="w-5 h-5" />
          </span>
          {(!collapsed || isMobile) && (
            <span className="font-display font-bold text-lg tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
              ExamEdge
            </span>
          )}
        </button>

        {isMobile ? (
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation drawer"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        ) : (
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </button>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = currentPage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onNavigate(item.id);
                if (isMobile) onCloseMobile();
              }}
              title={collapsed && !isMobile ? item.label : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-slate-900 dark:hover:text-white'
              } ${collapsed && !isMobile ? 'justify-center px-2' : ''}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {(!collapsed || isMobile) && (
                <span className="truncate">{item.label}</span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-slate-200 dark:border-slate-800 shrink-0">
        <div
          className={`flex items-center gap-3 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 ${
            collapsed && !isMobile ? 'justify-center' : ''
          }`}
        >
          {!imgError && planner.profile.avatarUrl ? (
            <img
              src={planner.profile.avatarUrl}
              alt={planner.profile.fullName}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="w-9 h-9 rounded-lg object-cover shrink-0 border border-slate-200 dark:border-slate-700"
            />
          ) : (
            <span className="w-9 h-9 rounded-lg bg-indigo-600 text-white text-xs font-bold flex items-center justify-center shrink-0">
              {initials || 'EE'}
            </span>
          )}

          {(!collapsed || isMobile) && (
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                {planner.profile.fullName}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {planner.profile.semester}
              </p>
            </div>
          )}
        </div>

        <div className="mt-2">
          {isDemoMode ? (
            <button
              type="button"
              onClick={() => signInWithGoogle()}
              className={`w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors cursor-pointer whitespace-nowrap ${
                collapsed && !isMobile ? 'px-2' : ''
              }`}
              title="Sign in with Google to save to PostgreSQL"
            >
              <LogIn className="w-3.5 h-3.5 shrink-0" />
              {(!collapsed || isMobile) && <span>Sign In with Google</span>}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => logout()}
              className={`w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap ${
                collapsed && !isMobile ? 'px-2' : ''
              }`}
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5 shrink-0" />
              {(!collapsed || isMobile) && <span>Logout</span>}
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside
        className={`hidden lg:block shrink-0 transition-all duration-200 ${
          collapsed ? 'w-[76px]' : 'w-[252px]'
        }`}
      >
        <div className="sticky top-0 h-screen">{renderNavContent(false)}</div>
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">
            {renderNavContent(true)}
          </div>
        </div>
      )}
    </>
  );
}
