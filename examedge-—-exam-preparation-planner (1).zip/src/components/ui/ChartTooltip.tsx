interface TooltipPayloadItem {
  name?: string;
  value?: string | number;
  color?: string;
  unit?: string;
  payload?: Record<string, unknown>;
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string;
  unitSuffix?: string;
}

export function ChartTooltip({
  active,
  payload,
  label,
  unitSuffix = '',
}: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;

  const fullName =
    typeof payload[0]?.payload?.name === 'string' &&
    payload[0].payload.name !== label
      ? payload[0].payload.name
      : null;

  return (
    <div className="px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-lg text-xs">
      {(label || fullName) && (
        <p className="font-semibold text-slate-900 dark:text-white mb-1.5">
          {fullName ? `${label} — ${fullName}` : label}
        </p>
      )}
      <div className="space-y-1">
        {payload.map((entry, idx) => (
          <div
            key={`${entry.name ?? idx}`}
            className="flex items-center justify-between gap-4"
          >
            <span className="inline-flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
              <span
                className="w-2.5 h-2.5 rounded-xs shrink-0"
                style={{ backgroundColor: entry.color || '#4F46E5' }}
              />
              {entry.name}
            </span>
            <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
              {entry.value}
              {unitSuffix}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
