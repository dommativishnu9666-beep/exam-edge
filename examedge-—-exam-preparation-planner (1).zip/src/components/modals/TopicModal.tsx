import React, { useEffect, useState } from 'react';
import { Modal } from '../ui/Modal.tsx';
import { usePlanner } from '../../context/PlannerContext.tsx';
import type {
  PriorityLevel,
  SyllabusTopic,
  TopicStatus,
} from '../../types/examedge.ts';

interface TopicModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultSubjectId: number;
  editingTopic?: SyllabusTopic | null;
}

export function TopicModal({
  isOpen,
  onClose,
  defaultSubjectId,
  editingTopic,
}: TopicModalProps) {
  const { planner, createTopic, updateTopic } = usePlanner();
  const [subjectId, setSubjectId] = useState(defaultSubjectId);
  const [unitNumber, setUnitNumber] = useState(1);
  const [unitName, setUnitName] = useState('');
  const [topicTitle, setTopicTitle] = useState('');
  const [priority, setPriority] = useState<PriorityLevel>('Medium');
  const [estimatedHours, setEstimatedHours] = useState(2);
  const [status, setStatus] = useState<TopicStatus>('Not Started');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (editingTopic) {
      setSubjectId(editingTopic.subjectId);
      setUnitNumber(editingTopic.unitNumber);
      setUnitName(editingTopic.unitName);
      setTopicTitle(editingTopic.topicTitle);
      setPriority(editingTopic.priority);
      setEstimatedHours(editingTopic.estimatedHours);
      setStatus(editingTopic.status);
      setNotes(editingTopic.notes);
    } else {
      setSubjectId(defaultSubjectId);
      const subjectTopics = planner.topics.filter(
        (t) => t.subjectId === defaultSubjectId
      );
      setUnitNumber(subjectTopics.length + 1);
      setUnitName('');
      setTopicTitle('');
      setPriority('Medium');
      setEstimatedHours(2);
      setStatus('Not Started');
      setNotes('');
    }
    setError('');
  }, [defaultSubjectId, editingTopic, isOpen, planner.topics]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!Number.isInteger(unitNumber) || unitNumber < 1 || unitNumber > 50) {
      setError('Unit number must be a whole number between 1 and 50.');
      return;
    }
    if (!unitName.trim() || unitName.trim().length > 120) {
      setError('Unit name is required (max 120 characters).');
      return;
    }
    if (!topicTitle.trim() || topicTitle.trim().length > 240) {
      setError('Topic title is required (max 240 characters).');
      return;
    }
    if (
      !Number.isFinite(estimatedHours) ||
      estimatedHours < 1 ||
      estimatedHours > 60
    ) {
      setError('Estimated hours must be between 1 and 60.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      if (editingTopic) {
        await updateTopic(editingTopic.id, {
          unitNumber,
          unitName: unitName.trim(),
          topicTitle: topicTitle.trim(),
          priority,
          estimatedHours,
          status,
          notes: notes.trim(),
        });
      } else {
        await createTopic({
          subjectId,
          unitNumber,
          unitName: unitName.trim(),
          topicTitle: topicTitle.trim(),
          priority,
          estimatedHours,
          status,
          notes: notes.trim(),
        });
      }
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save topic.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingTopic ? 'Edit Syllabus Topic' : 'Add Syllabus Topic'}
      subtitle="Track unit coverage, estimated study hours, and personal notes."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
            {error}
          </div>
        )}

        {!editingTopic && (
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Subject
            </label>
            <select
              value={subjectId}
              onChange={(e) => setSubjectId(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              {planner.subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} — {s.name}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Unit No.
            </label>
            <input
              type="number"
              min={1}
              max={20}
              value={unitNumber}
              onChange={(e) => setUnitNumber(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Unit Name
            </label>
            <input
              type="text"
              value={unitName}
              onChange={(e) => setUnitName(e.target.value)}
              placeholder="e.g., Fourier Series"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Topics Covered
          </label>
          <input
            type="text"
            value={topicTitle}
            onChange={(e) => setTopicTitle(e.target.value)}
            placeholder="e.g., Half-range sine & cosine expansions, Parseval's identity"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as PriorityLevel)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Est. Hours
            </label>
            <input
              type="number"
              min={1}
              max={40}
              value={estimatedHours}
              onChange={(e) => setEstimatedHours(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as TopicStatus)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="Not Started">Not Started</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Personal Study Notes
          </label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Key formulas, textbook pages, or practice problem reminders..."
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
          >
            {submitting
              ? 'Saving...'
              : editingTopic
                ? 'Save Topic'
                : 'Add Topic'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
