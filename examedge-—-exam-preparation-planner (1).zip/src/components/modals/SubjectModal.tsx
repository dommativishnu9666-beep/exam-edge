import React, { useEffect, useState } from 'react';
import {
  Atom,
  BookOpen,
  Code2,
  FlaskConical,
  Sigma,
  Zap,
} from 'lucide-react';
import { Modal } from '../ui/Modal.tsx';
import { usePlanner } from '../../context/PlannerContext.tsx';
import {
  SUBJECT_PALETTE,
  type PriorityLevel,
  type Subject,
  type SubjectColor,
} from '../../types/examedge.ts';
import { shiftDateISO } from '../../data/demoSeed.ts';

interface SubjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingSubject?: Subject | null;
}

const COLOR_OPTIONS: SubjectColor[] = [
  'indigo',
  'blue',
  'purple',
  'cyan',
  'emerald',
  'amber',
  'rose',
];

const ICON_OPTIONS = [
  { id: 'book', label: 'Literature / General', Icon: BookOpen },
  { id: 'sigma', label: 'Mathematics', Icon: Sigma },
  { id: 'atom', label: 'Physics', Icon: Atom },
  { id: 'code', label: 'Computer Science', Icon: Code2 },
  { id: 'zap', label: 'Engineering', Icon: Zap },
  { id: 'flask', label: 'Chemistry / Lab', Icon: FlaskConical },
];

export function SubjectModal({
  isOpen,
  onClose,
  editingSubject,
}: SubjectModalProps) {
  const { planner, createSubject, updateSubject } = usePlanner();
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [color, setColor] = useState<SubjectColor>('indigo');
  const [icon, setIcon] = useState('book');
  const [examDate, setExamDate] = useState(shiftDateISO(14));
  const [priority, setPriority] = useState<PriorityLevel>('High');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (editingSubject) {
      setName(editingSubject.name);
      setCode(editingSubject.code);
      setColor(editingSubject.color);
      setIcon(editingSubject.icon || 'book');
      setExamDate(editingSubject.examDate);
      setPriority(editingSubject.priority);
    } else {
      setName('');
      setCode('');
      setColor('indigo');
      setIcon('book');
      setExamDate(shiftDateISO(14));
      setPriority('High');
    }
    setError('');
  }, [editingSubject, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    const cleanCode = code.trim().toUpperCase();

    if (cleanName.length < 2 || cleanName.length > 120) {
      setError('Subject name must be between 2 and 120 characters.');
      return;
    }
    if (cleanCode.length < 2 || cleanCode.length > 20) {
      setError('Subject code must be between 2 and 20 characters.');
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(examDate)) {
      setError('Please choose a valid exam date.');
      return;
    }

    const duplicate = planner.subjects.find(
      (s) =>
        s.code.toUpperCase() === cleanCode &&
        (!editingSubject || s.id !== editingSubject.id)
    );
    if (duplicate) {
      setError(`Subject code "${cleanCode}" already exists in your planner.`);
      return;
    }

    setSubmitting(true);
    setError('');
    try {
      if (editingSubject) {
        await updateSubject(editingSubject.id, {
          name: cleanName,
          code: cleanCode,
          color,
          icon,
          examDate,
          priority,
        });
      } else {
        await createSubject({
          name: cleanName,
          code: cleanCode,
          color,
          icon,
          examDate,
          priority,
        });
      }
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save subject.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingSubject ? 'Edit Subject' : 'Add New Subject'}
      subtitle="Organize your syllabus units and track exam readiness."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Subject Name
            </label>
            <input
              type="text"
              maxLength={120}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Data Structures & Algorithms"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Subject Code
            </label>
            <input
              type="text"
              maxLength={20}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="e.g., CS201"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono uppercase text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Exam Date
            </label>
            <input
              type="date"
              value={examDate}
              onChange={(e) => setExamDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as PriorityLevel)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Subject Icon
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {ICON_OPTIONS.map((opt) => {
              const IconComp = opt.Icon;
              const active = icon === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  title={opt.label}
                  onClick={() => setIcon(opt.id)}
                  className={`flex items-center justify-center py-2 rounded-xl border transition-all cursor-pointer ${
                    active
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <IconComp className="w-4 h-4" />
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Subject Accent Colour
          </label>
          <div className="flex flex-wrap gap-2">
            {COLOR_OPTIONS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  color === c
                    ? 'border-slate-900 dark:border-white bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span
                  className={`w-3 h-3 rounded-sm ${SUBJECT_PALETTE[c].solidBg}`}
                />
                {SUBJECT_PALETTE[c].label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
          >
            {submitting
              ? 'Saving...'
              : editingSubject
                ? 'Save Changes'
                : 'Add Subject'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
