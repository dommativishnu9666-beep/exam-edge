import React, { useEffect, useState } from 'react';
import { Modal } from '../ui/Modal.tsx';
import { usePlanner } from '../../context/PlannerContext.tsx';
import {
  calculateDurationMinutes,
  formatDurationLabel,
  type PriorityLevel,
  type RevisionSession,
  type RevisionStatus,
} from '../../types/examedge.ts';
import { shiftDateISO } from '../../data/demoSeed.ts';

interface RevisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultDate?: string;
  defaultSubjectId?: number | null;
  defaultTopicId?: number | null;
  editingRevision?: RevisionSession | null;
}

export function RevisionModal({
  isOpen,
  onClose,
  defaultDate,
  defaultSubjectId,
  defaultTopicId,
  editingRevision,
}: RevisionModalProps) {
  const { planner, createRevision, updateRevision } = usePlanner();

  const firstSubjectId = defaultSubjectId || planner.subjects[0]?.id || 0;
  const [subjectId, setSubjectId] = useState<number>(firstSubjectId);
  const [selectedTopicId, setSelectedTopicId] = useState<string>('');
  const [topicTitle, setTopicTitle] = useState('');
  const [sessionDate, setSessionDate] = useState(
    defaultDate || shiftDateISO(0)
  );
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:30');
  const [priority, setPriority] = useState<PriorityLevel>('High');
  const [status, setStatus] = useState<RevisionStatus>('Pending');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const subjectTopics = planner.topics.filter((t) => t.subjectId === subjectId);

  useEffect(() => {
    if (editingRevision) {
      setSubjectId(editingRevision.subjectId);
      setSelectedTopicId(
        editingRevision.topicId ? String(editingRevision.topicId) : 'custom'
      );
      setTopicTitle(editingRevision.topicTitle);
      setSessionDate(editingRevision.sessionDate);
      setStartTime(editingRevision.startTime);
      setEndTime(editingRevision.endTime);
      setPriority(editingRevision.priority);
      setStatus(editingRevision.status);
      setNotes(editingRevision.notes);
    } else {
      const initialSubId = defaultSubjectId || planner.subjects[0]?.id || 0;
      setSubjectId(initialSubId);
      const initialTopics = planner.topics.filter(
        (t) => t.subjectId === initialSubId
      );
      const requestedTopic = defaultTopicId
        ? initialTopics.find((t) => t.id === defaultTopicId)
        : undefined;
      const chosenTopic = requestedTopic ?? initialTopics[0];
      if (chosenTopic) {
        setSelectedTopicId(String(chosenTopic.id));
        setTopicTitle(chosenTopic.topicTitle);
        setPriority(chosenTopic.priority);
      } else {
        setSelectedTopicId('custom');
        setTopicTitle('');
        setPriority('High');
      }
      setSessionDate(defaultDate || shiftDateISO(0));
      setStartTime('09:00');
      setEndTime('10:30');
      setStatus('Pending');
      setNotes('');
    }
    setError('');
  }, [
    defaultDate,
    defaultSubjectId,
    defaultTopicId,
    editingRevision,
    isOpen,
    planner.subjects,
    planner.topics,
  ]);

  const handleSubjectChange = (newSubjectId: number) => {
    setSubjectId(newSubjectId);
    const matchingTopics = planner.topics.filter(
      (t) => t.subjectId === newSubjectId
    );
    if (matchingTopics[0]) {
      setSelectedTopicId(String(matchingTopics[0].id));
      setTopicTitle(matchingTopics[0].topicTitle);
    } else {
      setSelectedTopicId('custom');
      setTopicTitle('');
    }
  };

  const handleTopicSelect = (val: string) => {
    setSelectedTopicId(val);
    if (val !== 'custom') {
      const found = subjectTopics.find((t) => String(t.id) === val);
      if (found) setTopicTitle(found.topicTitle);
    } else {
      setTopicTitle('');
    }
  };

  const durationMinutes = calculateDurationMinutes(startTime, endTime);
  const isTimeRangeValid = endTime > startTime;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectId) {
      setError('Please create or select a subject first.');
      return;
    }
    if (!topicTitle.trim()) {
      setError('Please select or enter a topic to revise.');
      return;
    }
    if (!sessionDate || !startTime || !endTime) {
      setError('Date, start time, and end time are required.');
      return;
    }
    if (!isTimeRangeValid) {
      setError('End time must be later than start time.');
      return;
    }

    setSubmitting(true);
    try {
      const topicIdNum =
        selectedTopicId && selectedTopicId !== 'custom'
          ? Number(selectedTopicId)
          : null;

      if (editingRevision) {
        await updateRevision(editingRevision.id, {
          subjectId,
          topicId: topicIdNum,
          topicTitle: topicTitle.trim(),
          sessionDate,
          startTime,
          endTime,
          priority,
          status,
          notes: notes.trim(),
        });
      } else {
        await createRevision({
          subjectId,
          topicId: topicIdNum,
          topicTitle: topicTitle.trim(),
          sessionDate,
          startTime,
          endTime,
          priority,
          status,
          notes: notes.trim(),
        });
      }
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to save revision session.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingRevision ? 'Edit Revision Session' : 'Schedule Revision Session'}
      subtitle="Duration is calculated automatically from your start and end times."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Select Subject
          </label>
          <select
            value={subjectId}
            onChange={(e) => handleSubjectChange(Number(e.target.value))}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          >
            {planner.subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} — {s.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Select Topic
          </label>
          <select
            value={selectedTopicId}
            onChange={(e) => handleTopicSelect(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          >
            {subjectTopics.map((t) => (
              <option key={t.id} value={String(t.id)}>
                Unit {t.unitNumber}: {t.topicTitle}
              </option>
            ))}
            <option value="custom">Custom topic title...</option>
          </select>

          {selectedTopicId === 'custom' && (
            <input
              type="text"
              value={topicTitle}
              onChange={(e) => setTopicTitle(e.target.value)}
              placeholder="Enter custom revision topic..."
              className="mt-2 w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Select Date
            </label>
            <input
              type="date"
              value={sessionDate}
              onChange={(e) => setSessionDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Start Time
            </label>
            <input
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              End Time
            </label>
            <input
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
        </div>

        <div className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs">
          <span className="text-slate-500 dark:text-slate-400">
            Calculated Duration
          </span>
          <span className="font-mono font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums">
            {isTimeRangeValid ? formatDurationLabel(durationMinutes) : 'Invalid time range'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as PriorityLevel)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as RevisionStatus)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
              <option value="Missed">Missed</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Additional Notes
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Chapters, past paper questions, or flashcards to review..."
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
          >
            {submitting ? 'Saving...' : 'Save Revision'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
