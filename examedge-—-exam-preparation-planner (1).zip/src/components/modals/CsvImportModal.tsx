import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Upload,
} from 'lucide-react';
import { Modal } from '../ui/Modal.tsx';
import { usePlanner } from '../../context/PlannerContext.tsx';
import type { Subject } from '../../types/examedge.ts';
import {
  TOPICS_CSV_TEMPLATE,
  buildRevisionsCsvTemplate,
  downloadCsvFile,
  parseRevisionsCsv,
  parseTopicsCsv,
} from '../../utils/csv.ts';
import { shiftDateISO } from '../../data/demoSeed.ts';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'topics' | 'revisions';
  defaultSubject?: Subject | null;
}

export function CsvImportModal({
  isOpen,
  onClose,
  mode,
  defaultSubject,
}: CsvImportModalProps) {
  const { bulkImportTopics, bulkImportRevisions } = usePlanner();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [csvText, setCsvText] = useState('');
  const [fileName, setFileName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const parsedTopics = useMemo(() => {
    if (mode !== 'topics' || !csvText.trim()) return null;
    return parseTopicsCsv(csvText, defaultSubject);
  }, [csvText, defaultSubject, mode]);

  const parsedRevisions = useMemo(() => {
    if (mode !== 'revisions' || !csvText.trim()) return null;
    return parseRevisionsCsv(csvText, defaultSubject);
  }, [csvText, defaultSubject, mode]);

  const parsed = mode === 'topics' ? parsedTopics : parsedRevisions;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      setSubmitError('CSV file must be smaller than 1.5 MB.');
      return;
    }
    setSubmitError('');
    setFileName(file.name);
    const text = await file.text();
    setCsvText(text);
  };

  const handleDownloadTemplate = () => {
    if (mode === 'topics') {
      downloadCsvFile('examedge_syllabus_template.csv', TOPICS_CSV_TEMPLATE);
    } else {
      downloadCsvFile(
        'examedge_revisions_template.csv',
        buildRevisionsCsvTemplate(shiftDateISO(1))
      );
    }
  };

  const handleImport = async () => {
    if (!parsed || parsed.rows.length === 0) {
      setSubmitError('Please upload or paste at least one valid CSV row.');
      return;
    }
    if (parsed.rows.length > 500) {
      setSubmitError('You can import up to 500 rows at once.');
      return;
    }
    setSubmitting(true);
    setSubmitError('');
    try {
      if (mode === 'topics' && parsedTopics) {
        await bulkImportTopics(parsedTopics.rows);
      } else if (mode === 'revisions' && parsedRevisions) {
        await bulkImportRevisions(parsedRevisions.rows);
      }
      setCsvText('');
      setFileName('');
      onClose();
    } catch (err) {
      setSubmitError(
        err instanceof Error ? err.message : 'Unable to import CSV rows.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    setSubmitError('');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={
        mode === 'topics'
          ? 'Bulk Import Syllabus Topics (CSV)'
          : 'Bulk Import Revision Sessions (CSV)'
      }
      subtitle="Upload a CSV file or paste spreadsheet rows. Unknown subject codes are created automatically."
      maxWidth="max-w-2xl"
    >
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-300">
            <FileSpreadsheet className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span>
              Need the exact column format? Download a starter CSV template.
            </span>
          </div>
          <button
            type="button"
            onClick={handleDownloadTemplate}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-slate-800 cursor-pointer shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Sample Template
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-dashed border-indigo-400 dark:border-indigo-700 bg-indigo-50/50 dark:bg-indigo-950/30 text-xs sm:text-sm font-semibold text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100/60 dark:hover:bg-indigo-950/60 cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            {fileName ? `Loaded: ${fileName}` : 'Choose .csv File'}
          </button>
          {csvText && (
            <button
              type="button"
              onClick={() => {
                setCsvText('');
                setFileName('');
                setSubmitError('');
              }}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white cursor-pointer"
            >
              Clear CSV
            </button>
          )}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Or Paste CSV Content Directly
          </label>
          <textarea
            rows={5}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder={
              mode === 'topics'
                ? TOPICS_CSV_TEMPLATE
                : buildRevisionsCsvTemplate(shiftDateISO(1))
            }
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        {submitError && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs sm:text-sm text-rose-700 dark:text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{submitError}</span>
          </div>
        )}

        {parsed && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                {parsed.rows.length} valid row
                {parsed.rows.length === 1 ? '' : 's'} ready to import
              </span>
              {parsed.errors.length > 0 && (
                <span className="font-semibold text-amber-700 dark:text-amber-400">
                  {parsed.errors.length} row error
                  {parsed.errors.length === 1 ? '' : 's'} skipped
                </span>
              )}
            </div>

            {parsed.errors.length > 0 && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 max-h-24 overflow-y-auto space-y-1">
                {parsed.errors.slice(0, 6).map((err, idx) => (
                  <p key={idx}>{err}</p>
                ))}
              </div>
            )}

            {parsed.rows.length > 0 && (
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-x-auto max-h-48">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {mode === 'topics' ? (
                      <tr>
                        <th className="py-2 px-3">Code</th>
                        <th className="py-2 px-3">Unit</th>
                        <th className="py-2 px-3">Topic</th>
                        <th className="py-2 px-3">Priority</th>
                        <th className="py-2 px-3">Status</th>
                      </tr>
                    ) : (
                      <tr>
                        <th className="py-2 px-3">Code</th>
                        <th className="py-2 px-3">Topic</th>
                        <th className="py-2 px-3">Date</th>
                        <th className="py-2 px-3">Time</th>
                        <th className="py-2 px-3">Priority</th>
                      </tr>
                    )}
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {mode === 'topics' &&
                      parsedTopics?.rows.slice(0, 6).map((row, idx) => (
                        <tr key={idx}>
                          <td className="py-2 px-3 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                            {row.subjectCode}
                          </td>
                          <td className="py-2 px-3 text-slate-700 dark:text-slate-300">
                            U{row.unitNumber}: {row.unitName}
                          </td>
                          <td className="py-2 px-3 text-slate-900 dark:text-white font-medium">
                            {row.topicTitle}
                          </td>
                          <td className="py-2 px-3">{row.priority}</td>
                          <td className="py-2 px-3">{row.status}</td>
                        </tr>
                      ))}
                    {mode === 'revisions' &&
                      parsedRevisions?.rows.slice(0, 6).map((row, idx) => (
                        <tr key={idx}>
                          <td className="py-2 px-3 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                            {row.subjectCode}
                          </td>
                          <td className="py-2 px-3 text-slate-900 dark:text-white font-medium">
                            {row.topicTitle}
                          </td>
                          <td className="py-2 px-3 font-mono">{row.sessionDate}</td>
                          <td className="py-2 px-3 font-mono">
                            {row.startTime}–{row.endTime}
                          </td>
                          <td className="py-2 px-3">{row.priority}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleImport}
            disabled={submitting || !parsed || parsed.rows.length === 0}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
          >
            {submitting
              ? 'Importing...'
              : `Import ${parsed?.rows.length ?? 0} Rows`}
          </button>
        </div>
      </div>
    </Modal>
  );
}
