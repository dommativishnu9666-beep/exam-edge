import React, { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';
import { Modal } from '../ui/Modal.tsx';
import { usePlanner } from '../../context/PlannerContext.tsx';

interface StudyLogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_MINUTES = [25, 30, 45, 60, 90];

export function StudyLogModal({ isOpen, onClose }: StudyLogModalProps) {
  const { planner, logStudyMinutes } = usePlanner();
  const [minutes, setMinutes] = useState(45);
  const [subjectId, setSubjectId] = useState<string>('general');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setMinutes(45);
      setSubjectId(planner.subjects[0] ? String(planner.subjects[0].id) : 'general');
      setDescription('');
      setError('');
    }
  }, [isOpen, planner.subjects]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!Number.isFinite(minutes) || minutes < 1 || minutes > 720) {
      setError('Study duration must be between 1 and 720 minutes.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      const subj = planner.subjects.find((s) => String(s.id) === subjectId);
      const baseNote =
        description.trim() || `Focused study session (${Math.round(minutes)}m)`;
      const fullDescription = subj ? `${subj.code}: ${baseNote}` : baseNote;
      await logStudyMinutes(Math.round(minutes), fullDescription);
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to log study session.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Log Study Session"
      subtitle="Record focused study time toward your daily preparation goal."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Quick Duration Presets
          </label>
          <div className="flex flex-wrap gap-2">
            {PRESET_MINUTES.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setMinutes(preset)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-semibold transition-colors cursor-pointer ${
                  minutes === preset
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {preset}m
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Duration (Minutes)
            </label>
            <div className="relative">
              <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="number"
                min={1}
                max={720}
                value={minutes}
                onChange={(e) => setMinutes(Number(e.target.value))}
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Subject
            </label>
            <select
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="general">General Revision</option>
              {planner.subjects.map((s) => (
                <option key={s.id} value={String(s.id)}>
                  {s.code} — {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            What did you study?
          </label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g., Solved 15 practice problems on Binary Trees"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
          >
            {submitting ? 'Logging...' : 'Save Study Log'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
