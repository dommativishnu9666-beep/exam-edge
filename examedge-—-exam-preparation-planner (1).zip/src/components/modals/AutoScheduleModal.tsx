import React, { useState } from 'react';
import { CalendarCheck2, Sparkles } from 'lucide-react';
import { Modal } from '../ui/Modal.tsx';
import { usePlanner } from '../../context/PlannerContext.tsx';
import { shiftDateISO } from '../../data/demoSeed.ts';
import type { ProposedRevisionSlot } from '../../utils/scheduler.ts';
import { formatDurationLabel, formatShortDate } from '../../types/examedge.ts';
import { PriorityBadge } from '../ui/Badges.tsx';

interface AutoScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AutoScheduleModal({ isOpen, onClose }: AutoScheduleModalProps) {
  const { planner, autoScheduleRevisions } = usePlanner();

  const [startDate, setStartDate] = useState(shiftDateISO(0));
  const [endDate, setEndDate] = useState(shiftDateISO(7));
  const [sessionsPerDay, setSessionsPerDay] = useState(2);
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [preferredWindow, setPreferredWindow] = useState<
    'morning' | 'afternoon' | 'evening'
  >('morning');
  const [subjectFilter, setSubjectFilter] = useState<string>('all');
  const [proposals, setProposals] = useState<ProposedRevisionSlot[] | null>(
    null
  );
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePreview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (endDate < startDate) {
      setError('End date must be on or after start date.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await autoScheduleRevisions({
        startDate,
        endDate,
        sessionsPerDay,
        durationMinutes,
        preferredWindow,
        subjectId: subjectFilter === 'all' ? null : Number(subjectFilter),
        commit: false,
      });
      setProposals(res.proposals);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to generate schedule.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleCommit = async () => {
    setLoading(true);
    setError('');
    try {
      await autoScheduleRevisions({
        startDate,
        endDate,
        sessionsPerDay,
        durationMinutes,
        preferredWindow,
        subjectId: subjectFilter === 'all' ? null : Number(subjectFilter),
        commit: true,
      });
      setProposals(null);
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to save schedule.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setProposals(null);
        setError('');
        onClose();
      }}
      title="Automatic Revision Scheduler"
      subtitle="Generates conflict-free revision sessions weighted by exam proximity and topic priority."
      maxWidth="max-w-2xl"
    >
      <form onSubmit={handlePreview} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              End Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Sessions / Day
            </label>
            <select
              value={sessionsPerDay}
              onChange={(e) => setSessionsPerDay(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
            >
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n} {n === 1 ? 'session' : 'sessions'}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Block Duration
            </label>
            <select
              value={durationMinutes}
              onChange={(e) => setDurationMinutes(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
            >
              <option value={45}>45 minutes</option>
              <option value={60}>1 hour</option>
              <option value={90}>1h 30m</option>
              <option value={120}>2 hours</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Preferred Window
            </label>
            <select
              value={preferredWindow}
              onChange={(e) =>
                setPreferredWindow(
                  e.target.value as 'morning' | 'afternoon' | 'evening'
                )
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
            >
              <option value="morning">Morning (08:30+)</option>
              <option value="afternoon">Afternoon (14:00+)</option>
              <option value="evening">Evening (18:30+)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Subject Scope
          </label>
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
          >
            <option value="all">
              All Uncompleted Subjects (Sorted by Exam Urgency)
            </option>
            {planner.subjects.map((s) => (
              <option key={s.id} value={String(s.id)}>
                {s.code} — {s.name} (Exam {s.examDate})
              </option>
            ))}
          </select>
        </div>

        {proposals !== null && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-800 flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white">
              <span>Proposed Schedule ({proposals.length} sessions)</span>
              <span className="font-mono text-indigo-600 dark:text-indigo-400">
                Conflict-free slots
              </span>
            </div>
            {proposals.length === 0 ? (
              <p className="p-4 text-xs text-slate-500 dark:text-slate-400">
                All matching syllabus topics are already completed or no
                available slots fit inside this range.
              </p>
            ) : (
              <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {proposals.map((slot, idx) => (
                  <div
                    key={idx}
                    className="px-4 py-2.5 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="font-mono text-[11px] text-indigo-600 dark:text-indigo-400">
                        {formatShortDate(slot.sessionDate)} · {slot.startTime}–
                        {slot.endTime} ({formatDurationLabel(slot.durationMinutes)})
                      </p>
                      <p className="font-semibold text-slate-900 dark:text-white truncate">
                        {slot.subjectCode} · {slot.topicTitle}
                      </p>
                    </div>
                    <PriorityBadge priority={slot.priority} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            {proposals ? 'Regenerate Preview' : 'Generate Plan'}
          </button>

          {proposals && proposals.length > 0 && (
            <button
              type="button"
              disabled={loading}
              onClick={handleCommit}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
            >
              <CalendarCheck2 className="w-4 h-4" />
              {loading ? 'Scheduling...' : `Confirm (${proposals.length})`}
            </button>
          )}
        </div>
      </form>
    </Modal>
  );
}
