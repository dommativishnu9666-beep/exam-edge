import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  Atom,
  BookOpen,
  CalendarPlus,
  Check,
  Code2,
  Download,
  Edit3,
  FlaskConical,
  Plus,
  Search,
  Sigma,
  Trash2,
  Upload,
  Zap,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { usePlanner } from '../context/PlannerContext.tsx';
import {
  SUBJECT_PALETTE,
  formatShortDate,
  type PriorityLevel,
  type Subject,
  type SyllabusTopic,
  type TopicStatus,
} from '../types/examedge.ts';
import { PriorityBadge } from '../components/ui/Badges.tsx';
import { Pagination } from '../components/ui/Pagination.tsx';
import { ConfirmDialog } from '../components/ui/ConfirmDialog.tsx';
import { SubjectModal } from '../components/modals/SubjectModal.tsx';
import { TopicModal } from '../components/modals/TopicModal.tsx';
import { RevisionModal } from '../components/modals/RevisionModal.tsx';
import { CsvImportModal } from '../components/modals/CsvImportModal.tsx';
import { buildTopicsCsv, downloadCsvFile } from '../utils/csv.ts';

interface SubjectsSyllabusPageProps {
  mode: 'subjects' | 'syllabus';
  selectedSubjectId: number | null;
  onSelectSubject: (subjectId: number) => void;
  onSwitchMode: (mode: 'subjects' | 'syllabus') => void;
}

type TopicFilter =
  | 'All'
  | 'Completed'
  | 'In Progress'
  | 'Not Started'
  | 'High Priority';

type TopicSortField =
  | 'unitNumber'
  | 'unitName'
  | 'priority'
  | 'estimatedHours'
  | 'status';

type SubjectSortOption = 'examDate' | 'completion' | 'name' | 'units';

const PRIORITY_WEIGHT: Record<PriorityLevel, number> = {
  High: 3,
  Medium: 2,
  Low: 1,
};

const STATUS_WEIGHT: Record<TopicStatus, number> = {
  'Not Started': 1,
  'In Progress': 2,
  Completed: 3,
};

function getSubjectIcon(iconKey: string) {
  switch (iconKey) {
    case 'sigma':
      return Sigma;
    case 'atom':
      return Atom;
    case 'code':
      return Code2;
    case 'zap':
      return Zap;
    case 'flask':
      return FlaskConical;
    default:
      return BookOpen;
  }
}

export function SubjectsSyllabusPage({
  mode,
  selectedSubjectId,
  onSelectSubject,
  onSwitchMode,
}: SubjectsSyllabusPageProps) {
  const {
    planner,
    deleteSubject,
    updateTopic,
    deleteTopic,
    bulkActionTopics,
    notify,
  } = usePlanner();

  const [subjectModalOpen, setSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  const [topicModalOpen, setTopicModalOpen] = useState(false);
  const [editingTopic, setEditingTopic] = useState<SyllabusTopic | null>(null);

  const [csvImportOpen, setCsvImportOpen] = useState(false);

  const [scheduleTopicId, setScheduleTopicId] = useState<number | null>(null);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);

  // Confirm delete dialogs
  const [confirmDeleteSubject, setConfirmDeleteSubject] =
    useState<Subject | null>(null);
  const [confirmDeleteTopic, setConfirmDeleteTopic] =
    useState<SyllabusTopic | null>(null);
  const [confirmBulkDeleteOpen, setConfirmBulkDeleteOpen] = useState(false);

  // Subject cards search/filter/sort
  const [subjectSearch, setSubjectSearch] = useState('');
  const [subjectPriorityFilter, setSubjectPriorityFilter] = useState<
    'All' | PriorityLevel
  >('All');
  const [subjectSortBy, setSubjectSortBy] =
    useState<SubjectSortOption>('examDate');

  // Syllabus table filter, search, sort, pagination, bulk selection
  const [filter, setFilter] = useState<TopicFilter>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<TopicSortField>('unitNumber');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedTopicIds, setSelectedTopicIds] = useState<number[]>([]);

  const activeSubject =
    planner.subjects.find((s) => s.id === selectedSubjectId) ??
    planner.subjects[0] ??
    null;

  const subjectCardsList = useMemo(() => {
    const q = subjectSearch.trim().toLowerCase();
    return planner.subjects
      .map((subj) => {
        const topics = planner.topics.filter((t) => t.subjectId === subj.id);
        const done = topics.filter((t) => t.status === 'Completed').length;
        const pct =
          topics.length > 0 ? Math.round((done / topics.length) * 100) : 0;
        return { subj, topics, done, pending: topics.length - done, pct };
      })
      .filter(({ subj }) => {
        if (
          subjectPriorityFilter !== 'All' &&
          subj.priority !== subjectPriorityFilter
        ) {
          return false;
        }
        if (q) {
          return (
            subj.name.toLowerCase().includes(q) ||
            subj.code.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (subjectSortBy === 'examDate') {
          return a.subj.examDate.localeCompare(b.subj.examDate);
        }
        if (subjectSortBy === 'completion') {
          return b.pct - a.pct;
        }
        if (subjectSortBy === 'units') {
          return b.topics.length - a.topics.length;
        }
        return a.subj.name.localeCompare(b.subj.name);
      });
  }, [
    planner.subjects,
    planner.topics,
    subjectPriorityFilter,
    subjectSearch,
    subjectSortBy,
  ]);

  const subjectTopics = useMemo(() => {
    if (!activeSubject) return [];
    return planner.topics.filter((t) => t.subjectId === activeSubject.id);
  }, [activeSubject, planner.topics]);

  const filteredAndSortedTopics = useMemo(() => {
    const filtered = subjectTopics.filter((t) => {
      if (filter === 'Completed' && t.status !== 'Completed') return false;
      if (filter === 'In Progress' && t.status !== 'In Progress') return false;
      if (filter === 'Not Started' && t.status !== 'Not Started') return false;
      if (filter === 'High Priority' && t.priority !== 'High') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          t.unitName.toLowerCase().includes(q) ||
          t.topicTitle.toLowerCase().includes(q) ||
          t.notes.toLowerCase().includes(q)
        );
      }
      return true;
    });

    const mult = sortDir === 'asc' ? 1 : -1;
    return [...filtered].sort((a, b) => {
      let cmp = 0;
      if (sortField === 'unitNumber') {
        cmp = a.unitNumber - b.unitNumber;
      } else if (sortField === 'unitName') {
        cmp = a.unitName.localeCompare(b.unitName);
      } else if (sortField === 'priority') {
        cmp = PRIORITY_WEIGHT[a.priority] - PRIORITY_WEIGHT[b.priority];
      } else if (sortField === 'estimatedHours') {
        cmp = a.estimatedHours - b.estimatedHours;
      } else if (sortField === 'status') {
        cmp = STATUS_WEIGHT[a.status] - STATUS_WEIGHT[b.status];
      }
      return cmp !== 0 ? cmp * mult : a.id - b.id;
    });
  }, [filter, searchQuery, sortDir, sortField, subjectTopics]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredAndSortedTopics.length / pageSize)
  );
  const safePage = Math.min(currentPage, totalPages);

  useEffect(() => {
    setCurrentPage(1);
    setSelectedTopicIds([]);
  }, [activeSubject?.id, filter, searchQuery]);

  const paginatedTopics = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredAndSortedTopics.slice(start, start + pageSize);
  }, [filteredAndSortedTopics, pageSize, safePage]);

  const pageTopicIds = useMemo(
    () => paginatedTopics.map((t) => t.id),
    [paginatedTopics]
  );
  const allOnPageSelected =
    pageTopicIds.length > 0 &&
    pageTopicIds.every((id) => selectedTopicIds.includes(id));

  const toggleSort = (field: TopicSortField) => {
    if (sortField === field) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const renderSortIcon = (field: TopicSortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />;
    }
    return sortDir === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
    );
  };

  const toggleTopicSelection = (id: number) => {
    setSelectedTopicIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAllOnPage = () => {
    if (allOnPageSelected) {
      setSelectedTopicIds((prev) =>
        prev.filter((id) => !pageTopicIds.includes(id))
      );
    } else {
      setSelectedTopicIds((prev) => Array.from(new Set([...prev, ...pageTopicIds])));
    }
  };

  const handleExportCsv = () => {
    if (mode === 'syllabus' && activeSubject) {
      const csv = buildTopicsCsv(filteredAndSortedTopics, planner.subjects);
      downloadCsvFile(
        `examedge_${activeSubject.code.toLowerCase()}_syllabus.csv`,
        csv
      );
      notify(
        `Exported ${filteredAndSortedTopics.length} ${activeSubject.code} topics to CSV.`,
        'success'
      );
    } else {
      const csv = buildTopicsCsv(planner.topics, planner.subjects);
      downloadCsvFile('examedge_all_syllabus.csv', csv);
      notify(
        `Exported ${planner.topics.length} syllabus topics to CSV.`,
        'success'
      );
    }
  };

  const activeCompleted = subjectTopics.filter(
    (t) => t.status === 'Completed'
  ).length;
  const activeRemaining = subjectTopics.length - activeCompleted;
  const activePct =
    subjectTopics.length > 0
      ? Math.round((activeCompleted / subjectTopics.length) * 100)
      : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
            My Subjects & Syllabus
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Organize every subject, track every topic, and complete your
            syllabus on time.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <div className="inline-flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => onSwitchMode('subjects')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                mode === 'subjects'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Subject Cards
            </button>
            <button
              type="button"
              onClick={() => onSwitchMode('syllabus')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                mode === 'syllabus'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Syllabus Table
            </button>
          </div>

          <button
            type="button"
            onClick={() => setCsvImportOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            Import CSV
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            Export CSV
          </button>

          <button
            type="button"
            onClick={() => {
              setEditingSubject(null);
              setSubjectModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Add Subject
          </button>
        </div>
      </div>

      {mode === 'subjects' && planner.subjects.length === 0 && (
        <div className="p-12 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
          <BookOpen className="w-10 h-10 mx-auto text-indigo-500 mb-3" />
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            No Subjects Yet
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
            Add your first exam subject or import a syllabus CSV to start
            organizing units, study hours, and revision sessions.
          </p>
          <button
            type="button"
            onClick={() => {
              setEditingSubject(null);
              setSubjectModalOpen(true);
            }}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add First Subject
          </button>
        </div>
      )}

      {mode === 'subjects' && planner.subjects.length > 0 && (
        <>
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="relative flex-1 md:max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={subjectSearch}
                onChange={(e) => setSubjectSearch(e.target.value)}
                placeholder="Search subjects by name or code..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={subjectPriorityFilter}
                onChange={(e) =>
                  setSubjectPriorityFilter(
                    e.target.value as 'All' | PriorityLevel
                  )
                }
                aria-label="Filter subjects by priority"
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              >
                <option value="All">All Priorities</option>
                <option value="High">High Priority</option>
                <option value="Medium">Medium Priority</option>
                <option value="Low">Low Priority</option>
              </select>

              <select
                value={subjectSortBy}
                onChange={(e) =>
                  setSubjectSortBy(e.target.value as SubjectSortOption)
                }
                aria-label="Sort subjects"
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              >
                <option value="examDate">Sort: Exam Date</option>
                <option value="completion">Sort: Completion %</option>
                <option value="units">Sort: Total Units</option>
                <option value="name">Sort: Subject Name</option>
              </select>
            </div>
          </div>

          {subjectCardsList.length === 0 ? (
            <div className="p-10 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                No subjects match your search or priority filter.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSubjectSearch('');
                  setSubjectPriorityFilter('All');
                }}
                className="mt-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Reset subject filters
              </button>
            </div>
          ) : (
            <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
              {subjectCardsList.map(({ subj, topics, done, pending, pct }) => {
                const palette =
                  SUBJECT_PALETTE[subj.color] ?? SUBJECT_PALETTE.indigo;
                const Icon = getSubjectIcon(subj.icon);

                return (
                  <div
                    key={subj.id}
                    className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md transition-all duration-150 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3">
                        <span
                          className={`inline-flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-br ${palette.gradient} text-white shadow-xs`}
                        >
                          <Icon className="w-5 h-5" />
                        </span>

                        <div className="flex items-center gap-1.5">
                          <PriorityBadge priority={subj.priority} />
                          <button
                            type="button"
                            onClick={() => {
                              setEditingSubject(subj);
                              setSubjectModalOpen(true);
                            }}
                            aria-label={`Edit ${subj.name}`}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteSubject(subj)}
                            aria-label={`Delete ${subj.name}`}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="mt-4">
                        <p className="text-xs font-mono font-semibold text-slate-500 dark:text-slate-400">
                          {subj.code} · Exam {formatShortDate(subj.examDate)}
                        </p>
                        <h2 className="mt-1 font-display text-lg font-bold text-slate-900 dark:text-white">
                          {subj.name}
                        </h2>
                      </div>

                      <div className="mt-4 grid grid-cols-3 gap-2 py-3 border-y border-slate-100 dark:border-slate-800 text-center">
                        <div>
                          <p className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums">
                            {topics.length}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            Total Units
                          </p>
                        </div>
                        <div>
                          <p className="font-mono text-base font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                            {done}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            Completed
                          </p>
                        </div>
                        <div>
                          <p className="font-mono text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                            {pending}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            Pending
                          </p>
                        </div>
                      </div>

                      <div className="mt-4">
                        <div className="flex items-center justify-between text-xs mb-1.5">
                          <span className="font-medium text-slate-600 dark:text-slate-300">
                            Syllabus Completion
                          </span>
                          <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                            {pct}%
                          </span>
                        </div>
                        <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                          <div
                            className={`h-full bg-gradient-to-r ${palette.gradient} rounded-full transition-all duration-300`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        onSelectSubject(subj.id);
                        onSwitchMode('syllabus');
                      }}
                      className="mt-5 w-full py-2.5 px-4 rounded-xl text-sm font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border border-indigo-200/80 dark:border-indigo-800/80 transition-colors cursor-pointer"
                    >
                      View Syllabus
                    </button>
                  </div>
                );
              })}
            </section>
          )}
        </>
      )}

      {mode === 'syllabus' && !activeSubject && (
        <div className="p-12 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
          <BookOpen className="w-10 h-10 mx-auto text-indigo-500 mb-3" />
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            Select or Add a Subject
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Create a subject first to manage its syllabus units and topics.
          </p>
          <button
            type="button"
            onClick={() => {
              setEditingSubject(null);
              setSubjectModalOpen(true);
            }}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Subject
          </button>
        </div>
      )}

      {mode === 'syllabus' && activeSubject && (
        <section className="space-y-5">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {planner.subjects.map((subj) => {
              const isSelected = subj.id === activeSubject.id;
              return (
                <button
                  key={subj.id}
                  type="button"
                  onClick={() => onSelectSubject(subj.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white border-transparent shadow-xs'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {subj.code} · {subj.name}
                </button>
              );
            })}
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <p className="text-xs font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                  {activeSubject.code} · Exam Date:{' '}
                  {formatShortDate(activeSubject.examDate)}
                </p>
                <h2 className="mt-1 font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  {activeSubject.name}
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-6">
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Total Units
                  </p>
                  <p className="font-mono text-xl font-bold text-slate-900 dark:text-white tabular-nums">
                    {subjectTopics.length}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Completed
                  </p>
                  <p className="font-mono text-xl font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {activeCompleted}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Remaining
                  </p>
                  <p className="font-mono text-xl font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                    {activeRemaining}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Overall Progress
                  </p>
                  <p className="font-mono text-xl font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                    {activePct}%
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className={`h-full bg-gradient-to-r ${(SUBJECT_PALETTE[activeSubject.color] ?? SUBJECT_PALETTE.indigo).gradient} rounded-full transition-all duration-300`}
                style={{ width: `${activePct}%` }}
              />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  'All',
                  'Completed',
                  'In Progress',
                  'Not Started',
                  'High Priority',
                ] as TopicFilter[]
              ).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    filter === tab
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {tab === 'All' ? 'All Topics' : tab}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search topics or notes..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditingTopic(null);
                  setTopicModalOpen(true);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4" />
                Add Topic
              </button>
            </div>
          </div>

          {selectedTopicIds.length > 0 && (
            <div className="px-4 py-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs sm:text-sm font-semibold text-indigo-950 dark:text-indigo-100">
                {selectedTopicIds.length} topic
                {selectedTopicIds.length === 1 ? '' : 's'} selected
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    await bulkActionTopics(selectedTopicIds, 'complete');
                    setSelectedTopicIds([]);
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
                >
                  Mark Completed
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await bulkActionTopics(selectedTopicIds, 'reopen');
                    setSelectedTopicIds([]);
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  Mark In Progress
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmBulkDeleteOpen(true)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white cursor-pointer"
                >
                  Delete Selected
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTopicIds([])}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Clear
                </button>
              </div>
            </div>
          )}

          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            {filteredAndSortedTopics.length === 0 ? (
              <div className="p-10 text-center">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  No syllabus topics match your current filter.
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Try clearing the search query or add a new unit topic.
                </p>
              </div>
            ) : (
              <>
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-600 dark:text-slate-300">
                        <th className="py-3.5 px-4 w-10">
                          <input
                            type="checkbox"
                            checked={allOnPageSelected}
                            onChange={toggleSelectAllOnPage}
                            aria-label="Select all topics on page"
                            className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                          />
                        </th>
                        <th className="py-3.5 px-4 w-24">
                          <button
                            type="button"
                            onClick={() => toggleSort('unitNumber')}
                            className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                          >
                            Unit No.
                            {renderSortIcon('unitNumber')}
                          </button>
                        </th>
                        <th className="py-3.5 px-4 w-44">
                          <button
                            type="button"
                            onClick={() => toggleSort('unitName')}
                            className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                          >
                            Unit Name
                            {renderSortIcon('unitName')}
                          </button>
                        </th>
                        <th className="py-3.5 px-4">Topics</th>
                        <th className="py-3.5 px-4 w-28">
                          <button
                            type="button"
                            onClick={() => toggleSort('priority')}
                            className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                          >
                            Priority
                            {renderSortIcon('priority')}
                          </button>
                        </th>
                        <th className="py-3.5 px-4 w-28 text-right">
                          <button
                            type="button"
                            onClick={() => toggleSort('estimatedHours')}
                            className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer ml-auto"
                          >
                            Est. Hours
                            {renderSortIcon('estimatedHours')}
                          </button>
                        </th>
                        <th className="py-3.5 px-4 w-40">
                          <button
                            type="button"
                            onClick={() => toggleSort('status')}
                            className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                          >
                            Status
                            {renderSortIcon('status')}
                          </button>
                        </th>
                        <th className="py-3.5 px-4 w-44 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                      {paginatedTopics.map((topic, idx) => {
                        const isDone = topic.status === 'Completed';
                        const isSelected = selectedTopicIds.includes(topic.id);
                        return (
                          <tr
                            key={topic.id}
                            className={`transition-colors hover:bg-indigo-50/40 dark:hover:bg-slate-800/50 ${
                              isSelected
                                ? 'bg-indigo-50/70 dark:bg-indigo-950/30'
                                : idx % 2 === 1
                                  ? 'bg-slate-50/50 dark:bg-slate-900/40'
                                  : ''
                            }`}
                          >
                            <td className="py-3.5 px-4">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => toggleTopicSelection(topic.id)}
                                aria-label={`Select ${topic.topicTitle}`}
                                className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                              />
                            </td>
                            <td className="py-3.5 px-4 font-mono font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                              Unit {String(topic.unitNumber).padStart(2, '0')}
                            </td>
                            <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white">
                              {topic.unitName}
                            </td>
                            <td className="py-3.5 px-4">
                              <p className="font-medium text-slate-800 dark:text-slate-200">
                                {topic.topicTitle}
                              </p>
                              {topic.notes && (
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                                  Note: {topic.notes}
                                </p>
                              )}
                            </td>
                            <td className="py-3.5 px-4">
                              <PriorityBadge priority={topic.priority} />
                            </td>
                            <td className="py-3.5 px-4 text-right font-mono text-slate-700 dark:text-slate-300 tabular-nums">
                              {topic.estimatedHours}h
                            </td>
                            <td className="py-3.5 px-4">
                              <select
                                value={topic.status}
                                onChange={(e) =>
                                  updateTopic(topic.id, {
                                    status: e.target.value as TopicStatus,
                                  })
                                }
                                aria-label={`Status for ${topic.topicTitle}`}
                                className={`px-2.5 py-1 rounded-lg border text-xs font-semibold cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-600 ${
                                  topic.status === 'Completed'
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                                    : topic.status === 'In Progress'
                                      ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800'
                                      : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                                }`}
                              >
                                <option value="Not Started">Not Started</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                              </select>
                            </td>
                            <td className="py-3.5 px-4">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateTopic(topic.id, {
                                      status: isDone
                                        ? 'In Progress'
                                        : 'Completed',
                                    })
                                  }
                                  title={
                                    isDone
                                      ? 'Mark as In Progress'
                                      : 'Mark as Completed'
                                  }
                                  className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                    isDone
                                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                      : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-emerald-950'
                                  }`}
                                >
                                  <Check className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setScheduleTopicId(topic.id);
                                    setScheduleModalOpen(true);
                                  }}
                                  title="Schedule revision for this topic"
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:text-slate-400 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <CalendarPlus className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingTopic(topic);
                                    setTopicModalOpen(true);
                                  }}
                                  title="Edit topic & notes"
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:text-slate-400 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteTopic(topic)}
                                  title="Delete topic"
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:text-slate-400 dark:hover:bg-rose-950/60 cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="md:hidden divide-y divide-slate-200 dark:divide-slate-800">
                  {paginatedTopics.map((topic) => {
                    const isDone = topic.status === 'Completed';
                    const isSelected = selectedTopicIds.includes(topic.id);
                    return (
                      <div key={topic.id} className="p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-start gap-2.5">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleTopicSelection(topic.id)}
                              className="w-4 h-4 mt-1 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                            />
                            <div>
                              <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                                Unit {topic.unitNumber} · {topic.unitName} ·{' '}
                                {topic.estimatedHours}h
                              </p>
                              <h3 className="font-semibold text-sm text-slate-900 dark:text-white mt-0.5">
                                {topic.topicTitle}
                              </h3>
                            </div>
                          </div>
                          <PriorityBadge priority={topic.priority} />
                        </div>

                        {topic.notes && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 pl-6">
                            {topic.notes}
                          </p>
                        )}

                        <div className="flex items-center justify-between pt-1 pl-6 gap-2">
                          <select
                            value={topic.status}
                            onChange={(e) =>
                              updateTopic(topic.id, {
                                status: e.target.value as TopicStatus,
                              })
                            }
                            className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200"
                          >
                            <option value="Not Started">Not Started</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                          </select>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                updateTopic(topic.id, {
                                  status: isDone ? 'In Progress' : 'Completed',
                                })
                              }
                              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 cursor-pointer"
                            >
                              {isDone ? 'Reopen' : 'Complete'}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setScheduleTopicId(topic.id);
                                setScheduleModalOpen(true);
                              }}
                              aria-label="Schedule revision"
                              className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 cursor-pointer"
                            >
                              <CalendarPlus className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingTopic(topic);
                                setTopicModalOpen(true);
                              }}
                              aria-label="Edit topic"
                              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteTopic(topic)}
                              aria-label="Delete topic"
                              className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <Pagination
                  totalItems={filteredAndSortedTopics.length}
                  currentPage={safePage}
                  pageSize={pageSize}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setCurrentPage(1);
                  }}
                />
              </>
            )}
          </div>
        </section>
      )}

      <SubjectModal
        isOpen={subjectModalOpen}
        onClose={() => setSubjectModalOpen(false)}
        editingSubject={editingSubject}
      />

      {activeSubject && (
        <TopicModal
          isOpen={topicModalOpen}
          onClose={() => setTopicModalOpen(false)}
          defaultSubjectId={activeSubject.id}
          editingTopic={editingTopic}
        />
      )}

      <CsvImportModal
        isOpen={csvImportOpen}
        onClose={() => setCsvImportOpen(false)}
        mode="topics"
        defaultSubject={activeSubject}
      />

      {activeSubject && (
        <RevisionModal
          isOpen={scheduleModalOpen}
          onClose={() => {
            setScheduleModalOpen(false);
            setScheduleTopicId(null);
          }}
          defaultSubjectId={activeSubject.id}
          defaultTopicId={scheduleTopicId}
        />
      )}

      <ConfirmDialog
        isOpen={Boolean(confirmDeleteSubject)}
        onClose={() => setConfirmDeleteSubject(null)}
        onConfirm={() => {
          if (confirmDeleteSubject) {
            return deleteSubject(confirmDeleteSubject.id);
          }
        }}
        title={`Delete ${confirmDeleteSubject?.code ?? 'Subject'}?`}
        message={`Deleting "${confirmDeleteSubject?.name ?? ''}" will permanently remove all syllabus topics and scheduled revision sessions linked to this subject.`}
        confirmLabel="Delete Subject"
        variant="danger"
      />

      <ConfirmDialog
        isOpen={Boolean(confirmDeleteTopic)}
        onClose={() => setConfirmDeleteTopic(null)}
        onConfirm={() => {
          if (confirmDeleteTopic) {
            return deleteTopic(confirmDeleteTopic.id);
          }
        }}
        title="Delete Syllabus Topic?"
        message={`Remove "${confirmDeleteTopic?.topicTitle ?? ''}" from your syllabus tracker?`}
        confirmLabel="Delete Topic"
        variant="danger"
      />

      <ConfirmDialog
        isOpen={confirmBulkDeleteOpen}
        onClose={() => setConfirmBulkDeleteOpen(false)}
        onConfirm={async () => {
          await bulkActionTopics(selectedTopicIds, 'delete');
          setSelectedTopicIds([]);
        }}
        title={`Delete ${selectedTopicIds.length} Selected Topics?`}
        message="This will permanently remove all selected syllabus topics. This action cannot be undone."
        confirmLabel="Delete Selected"
        variant="danger"
      />
    </div>
  );
}
