import {
  ArrowRight,
  BarChart3,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  GraduationCap,
  Lightbulb,
  ListChecks,
  Target,
} from 'lucide-react';
import { useState } from 'react';
import { usePlanner } from '../context/PlannerContext.tsx';
import type { AppPage } from '../types/examedge.ts';

interface LandingPageProps {
  onEnterWorkspace: (page?: AppPage) => void;
}

const FEATURES: Array<{
  num: string;
  title: string;
  desc: string;
  icon: typeof BookOpen;
  target: AppPage;
  accent: string;
  span?: string;
}> = [
  {
    num: '01',
    title: 'Subject Management',
    desc: 'Group every course with subject codes, exam countdowns, priority levels, and distinct color accents.',
    icon: BookOpen,
    target: 'subjects',
    accent: 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60',
    span: 'lg:col-span-2',
  },
  {
    num: '02',
    title: 'Syllabus Tracking',
    desc: 'Break chapters into units, log personal notes, and watch completion percentages recalculate automatically.',
    icon: ListChecks,
    target: 'syllabus',
    accent: 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60',
  },
  {
    num: '03',
    title: 'Smart Revision Calendar',
    desc: 'Switch between monthly and weekly views, compute session durations automatically, and catch missed slots.',
    icon: CalendarDays,
    target: 'calendar',
    accent: 'text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/60',
  },
  {
    num: '04',
    title: 'Daily Study Tips',
    desc: 'Apply evidence-backed techniques like Pomodoro, Active Recall, and Spaced Intervals with saved favorites.',
    icon: Lightbulb,
    target: 'tips',
    accent: 'text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60',
    span: 'lg:col-span-2',
  },
  {
    num: '05',
    title: 'Progress Analytics',
    desc: 'Inspect subject readiness, weekly study hours, and revision completion trends powered by real planner data.',
    icon: BarChart3,
    target: 'analytics',
    accent: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60',
  },
  {
    num: '06',
    title: 'Study Goal Tracking',
    desc: 'Set realistic daily study targets, track completed tasks each morning, and keep momentum steady before exams.',
    icon: Target,
    target: 'dashboard',
    accent: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60',
    span: 'lg:col-span-2',
  },
];

export function LandingPage({ onEnterWorkspace }: LandingPageProps) {
  const { firebaseUser, signInWithGoogle, planner } = usePlanner();
  const [heroImgError, setHeroImgError] = useState(false);

  const completedTopics = planner.topics.filter(
    (t) => t.status === 'Completed'
  ).length;
  const completedMinutes = planner.studyLogs.reduce(
    (sum, l) => sum + l.minutes,
    0
  );
  const sampleHours = (completedMinutes / 60).toFixed(1);

  const handlePrimaryStart = async () => {
    if (firebaseUser) {
      onEnterWorkspace('dashboard');
      return;
    }
    onEnterWorkspace('dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          <a
            href="#top"
            className="flex items-center gap-2.5 font-display font-bold text-lg tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
          >
            <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-violet-600 text-white">
              <GraduationCap className="w-4 h-4" />
            </span>
            ExamEdge
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300">
            <a
              href="#features"
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors whitespace-nowrap shrink-0"
            >
              Features
            </a>
            <button
              type="button"
              onClick={() => onEnterWorkspace('subjects')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Subjects
            </button>
            <button
              type="button"
              onClick={() => onEnterWorkspace('calendar')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Calendar
            </button>
            <button
              type="button"
              onClick={() => onEnterWorkspace('tips')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Study Tips
            </button>
          </nav>

          <div className="shrink-0">
            {firebaseUser ? (
              <button
                type="button"
                onClick={() => onEnterWorkspace('dashboard')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer"
              >
                Open Planner
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={async () => {
                  const ok = await signInWithGoogle();
                  if (ok) onEnterWorkspace('dashboard');
                }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer"
              >
                Sign In with Google
              </button>
            )}
          </div>
        </div>
      </header>

      <main id="top">
        <section className="relative overflow-hidden bg-gradient-to-b from-indigo-50/70 via-white to-slate-50 dark:from-indigo-950/30 dark:via-slate-950 dark:to-slate-950 border-b border-slate-200/80 dark:border-slate-800/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-20">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
              <div className="lg:col-span-6 flex flex-col justify-center">
                <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 tracking-wide mb-3">
                  Plan Smarter · Study Better · Score Higher
                </p>
                <h1
                  className="font-display font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.1] max-w-xl"
                  style={{
                    fontSize: 'clamp(2.25rem, 4vw, 3.5rem)',
                    textWrap: 'balance',
                  }}
                >
                  Your Success Starts With a Smart Study Plan.
                </h1>
                <p className="mt-5 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
                  Organize your syllabus, schedule your revisions, track your
                  progress, and prepare for every exam with confidence.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3.5">
                  <button
                    type="button"
                    onClick={handlePrimaryStart}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-md transition-all cursor-pointer whitespace-nowrap"
                  >
                    Get Started
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <a
                    href="#features"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
                  >
                    Explore Features
                  </a>
                </div>

                <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    Interactive Syllabus Tables
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    Monthly & Weekly Revision Calendar
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    PostgreSQL Cloud Persistence
                  </span>
                </div>
              </div>

              <div className="lg:col-span-6 flex">
                <div className="relative w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg">
                  {!heroImgError ? (
                    <img
                      src="/src/assets/images/hero_study_workspace_1795155880817.jpg"
                      alt="ExamEdge study desk workspace showing structured academic schedule and engineering notes"
                      referrerPolicy="no-referrer"
                      onError={() => setHeroImgError(true)}
                      className="w-full h-full min-h-[300px] lg:min-h-[420px] object-cover"
                    />
                  ) : (
                    <div className="w-full h-full min-h-[340px] bg-gradient-to-br from-indigo-600 via-violet-600 to-blue-600 flex flex-col items-center justify-center p-8 text-white">
                      <GraduationCap className="w-14 h-14 mb-4 opacity-90" />
                      <p className="font-display font-bold text-xl">
                        ExamEdge Academic Planner
                      </p>
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-slate-950/85 via-slate-950/45 to-transparent text-white">
                    <p className="text-xs font-medium text-indigo-200">
                      Sample Starter Workspace
                    </p>
                    <p className="text-sm font-semibold mt-0.5">
                      5 Engineering Subjects · 21 Units · Live Revision Schedule
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5">
            <h2 className="font-display text-sm font-semibold text-slate-700 dark:text-slate-300">
              Sample Demonstration Snapshot
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Demonstration figures below reflect the starter semester plan until
              you customize your own records.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Subjects Organized
              </p>
              <p className="mt-2 font-display text-3xl font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                {planner.subjects.length}
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Sample core engineering courses
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Topics Completed
              </p>
              <p className="mt-2 font-display text-3xl font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                {completedTopics} / {planner.topics.length}
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Tracked unit-by-unit
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Revision Sessions
              </p>
              <p className="mt-2 font-display text-3xl font-bold text-violet-600 dark:text-violet-400 tabular-nums">
                {planner.revisions.length}
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Timed & prioritized blocks
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Study Hours Logged
              </p>
              <p className="mt-2 font-display text-3xl font-bold text-cyan-600 dark:text-cyan-400 tabular-nums">
                {sampleHours}h
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Across this week's logs
              </p>
            </div>
          </div>
        </section>

        <section
          id="features"
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16"
        >
          <div className="max-w-2xl mb-10">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
              Built for Structured Exam Preparation
            </h2>
            <p className="mt-2.5 text-slate-600 dark:text-slate-300 text-base">
              Every module works together—completing a topic in your syllabus
              updates dashboard readiness, revision priorities, and analytics
              charts automatically.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map((feat) => {
              const Icon = feat.icon;
              return (
                <button
                  key={feat.num}
                  type="button"
                  onClick={() => onEnterWorkspace(feat.target)}
                  className={`group text-left p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 hover:-translate-y-0.5 hover:shadow-md transition-all duration-150 cursor-pointer flex flex-col justify-between ${feat.span ?? ''}`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span
                        className={`inline-flex items-center justify-center w-11 h-11 rounded-xl ${feat.accent}`}
                      >
                        <Icon className="w-5 h-5" />
                      </span>
                      <span className="font-mono text-xs font-semibold text-slate-400 dark:text-slate-500">
                        {feat.num}
                      </span>
                    </div>
                    <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                      {feat.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {feat.desc}
                    </p>
                  </div>
                  <div className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                    Open {feat.title}
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <div className="rounded-3xl bg-gradient-to-r from-indigo-600 via-violet-600 to-blue-600 p-8 sm:p-12 text-white flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 shadow-lg">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight">
                Take Control of Your Preparation Today.
              </h2>
              <p className="mt-2 text-indigo-100 max-w-xl text-sm sm:text-base">
                Jump into the interactive workspace with starter sample data, or
                sign in with Google to save your custom syllabus and revision
                calendar to PostgreSQL.
              </p>
            </div>
            <button
              type="button"
              onClick={handlePrimaryStart}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white text-indigo-700 font-semibold text-sm hover:bg-indigo-50 transition-colors shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
            >
              Start Planning Now
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <p className="font-medium text-slate-700 dark:text-slate-300">
            ExamEdge — Plan Smarter. Study Better. Score Higher.
          </p>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => onEnterWorkspace('dashboard')}
              className="hover:text-slate-900 dark:hover:text-white cursor-pointer"
            >
              Dashboard
            </button>
            <button
              type="button"
              onClick={() => onEnterWorkspace('subjects')}
              className="hover:text-slate-900 dark:hover:text-white cursor-pointer"
            >
              Syllabus
            </button>
            <button
              type="button"
              onClick={() => onEnterWorkspace('calendar')}
              className="hover:text-slate-900 dark:hover:text-white cursor-pointer"
            >
              Revision Calendar
            </button>
            <button
              type="button"
              onClick={() => onEnterWorkspace('tips')}
              className="hover:text-slate-900 dark:hover:text-white cursor-pointer"
            >
              Study Tips
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
