import { useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { usePlanner } from '../context/PlannerContext.tsx';
import { shiftDateISO } from '../data/demoSeed.ts';
import { ChartTooltip } from '../components/ui/ChartTooltip.tsx';
import { SUBJECT_PALETTE } from '../types/examedge.ts';

type TimeRange = 'week' | 'month' | 'all';

interface AnalyticsPageProps {
  onOpenSubjectSyllabus?: (subjectId: number) => void;
}

export function AnalyticsPage({ onOpenSubjectSyllabus }: AnalyticsPageProps) {
  const { planner } = usePlanner();
  const [range, setRange] = useState<TimeRange>('week');

  const cutoffISO = useMemo(() => {
    if (range === 'week') return shiftDateISO(-6);
    if (range === 'month') return shiftDateISO(-29);
    return '0000-00-00';
  }, [range]);

  const filteredLogs = useMemo(
    () => planner.studyLogs.filter((l) => l.logDate >= cutoffISO),
    [cutoffISO, planner.studyLogs]
  );

  const filteredRevisions = useMemo(
    () =>
      range === 'all'
        ? planner.revisions
        : planner.revisions.filter((r) => r.sessionDate >= cutoffISO),
    [cutoffISO, planner.revisions, range]
  );

  const totalTopics = planner.topics.length;
  const completedTopics = planner.topics.filter(
    (t) => t.status === 'Completed'
  ).length;
  const inProgressTopics = planner.topics.filter(
    (t) => t.status === 'In Progress'
  ).length;
  const notStartedTopics = planner.topics.filter(
    (t) => t.status === 'Not Started'
  ).length;

  const overallCompletion =
    totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  const totalStudyHours = (
    filteredLogs.reduce((s, l) => s + l.minutes, 0) / 60
  ).toFixed(1);

  const completedRevisionsCount = filteredRevisions.filter(
    (r) => r.status === 'Completed'
  ).length;

  const subjectChartData = planner.subjects.map((subj) => {
    const subTopics = planner.topics.filter((t) => t.subjectId === subj.id);
    const done = subTopics.filter((t) => t.status === 'Completed').length;
    const pct =
      subTopics.length > 0 ? Math.round((done / subTopics.length) * 100) : 0;
    return {
      subjectId: subj.id,
      code: subj.code,
      name: subj.name,
      completion: pct,
      colorHex: (SUBJECT_PALETTE[subj.color] ?? SUBJECT_PALETTE.indigo).hex,
    };
  });

  const daysWindow = range === 'week' ? 7 : range === 'month' ? 14 : 7;
  const hoursTrendData = Array.from({ length: daysWindow }, (_, idx) => {
    const offset = -(daysWindow - 1 - idx);
    const iso = shiftDateISO(offset);
    const parts = iso.split('-').map(Number);
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    const label =
      daysWindow <= 7
        ? d.toLocaleDateString('en-US', { weekday: 'short' })
        : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const mins = filteredLogs
      .filter((l) => l.logDate === iso)
      .reduce((sum, l) => sum + l.minutes, 0);
    return {
      label,
      hours: Number((mins / 60).toFixed(1)),
    };
  });

  const topicBreakdownPie = [
    { name: 'Completed', value: completedTopics, color: '#10B981' },
    { name: 'In Progress', value: inProgressTopics, color: '#2563EB' },
    { name: 'Not Started', value: notStartedTopics, color: '#94A3B8' },
  ].filter((d) => d.value > 0);

  const revisionTrendData = Array.from({ length: 7 }, (_, idx) => {
    const offset = -(6 - idx);
    const iso = shiftDateISO(offset);
    const parts = iso.split('-').map(Number);
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    const label = d.toLocaleDateString('en-US', { weekday: 'short' });
    const completedCount = planner.revisions.filter(
      (r) => r.sessionDate === iso && r.status === 'Completed'
    ).length;
    const scheduledCount = planner.revisions.filter(
      (r) => r.sessionDate === iso
    ).length;
    return {
      day: label,
      completed: completedCount,
      scheduled: scheduledCount,
    };
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
            Progress Analytics
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Live visual insights derived directly from your syllabus topics,
            revision calendar, and study logs.
          </p>
        </div>

        <div className="inline-flex p-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shrink-0">
          {(
            [
              { id: 'week', label: 'This Week' },
              { id: 'month', label: 'This Month' },
              { id: 'all', label: 'All Time' },
            ] as Array<{ id: TimeRange; label: string }>
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setRange(item.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                range === item.id
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Overall Syllabus Completion
          </p>
          <p className="mt-2 font-display text-3xl font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
            {overallCompletion}%
          </p>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Total Study Hours
          </p>
          <p className="mt-2 font-display text-3xl font-bold text-blue-600 dark:text-blue-400 tabular-nums">
            {totalStudyHours}h
          </p>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Completed Revisions
          </p>
          <p className="mt-2 font-display text-3xl font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
            {completedRevisionsCount}
          </p>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Pending Topics
          </p>
          <p className="mt-2 font-display text-3xl font-bold text-amber-600 dark:text-amber-400 tabular-nums">
            {totalTopics - completedTopics}
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <section className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            Subject-wise Completion (%)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 mb-5">
            Click any subject bar to open its syllabus tracker
          </p>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectChartData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#E2E8F0"
                  opacity={0.45}
                />
                <XAxis
                  dataKey="code"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#64748B' }}
                />
                <YAxis
                  domain={[0, 100]}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#64748B' }}
                  unit="%"
                />
                <Tooltip
                  cursor={{ fill: 'rgba(99, 102, 241, 0.08)' }}
                  content={<ChartTooltip unitSuffix="%" />}
                />
                <Bar
                  dataKey="completion"
                  name="Completion"
                  radius={[8, 8, 0, 0]}
                  maxBarSize={44}
                  className={onOpenSubjectSyllabus ? 'cursor-pointer' : ''}
                      onClick={(data) => {
                        const payload = (
                          data as { payload?: { subjectId?: number } }
                        )?.payload;
                        const sid = Number(payload?.subjectId);
                        if (sid > 0 && onOpenSubjectSyllabus) {
                          onOpenSubjectSyllabus(sid);
                        }
                      }}
                >
                  {subjectChartData.map((entry) => (
                    <Cell key={entry.subjectId} fill={entry.colorHex} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            Study Hours Distribution
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 mb-5">
            Logged focus hours across the selected timeframe
          </p>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hoursTrendData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#E2E8F0"
                  opacity={0.45}
                />
                <XAxis
                  dataKey="label"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#64748B' }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#64748B' }}
                  unit="h"
                />
                <Tooltip
                  cursor={{ fill: 'rgba(37, 99, 235, 0.08)' }}
                  content={<ChartTooltip unitSuffix="h" />}
                />
                <Bar
                  dataKey="hours"
                  name="Hours Studied"
                  fill="#2563EB"
                  radius={[8, 8, 0, 0]}
                  maxBarSize={36}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            Completed vs Pending Topics
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 mb-5">
            Current distribution across all syllabus units
          </p>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={topicBreakdownPie}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={62}
                  outerRadius={95}
                  paddingAngle={4}
                >
                  {topicBreakdownPie.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<ChartTooltip unitSuffix=" topics" />} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            Revision Completion Trend
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 mb-5">
            Scheduled vs completed revision sessions over the past 7 days
          </p>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revisionTrendData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#E2E8F0"
                  opacity={0.45}
                />
                <XAxis
                  dataKey="day"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#64748B' }}
                />
                <YAxis
                  allowDecimals={false}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#64748B' }}
                />
                <Tooltip content={<ChartTooltip unitSuffix=" sessions" />} />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="scheduled"
                  name="Scheduled"
                  stroke="#7C3AED"
                  fill="#7C3AED"
                  fillOpacity={0.18}
                />
                <Area
                  type="monotone"
                  dataKey="completed"
                  name="Completed"
                  stroke="#10B981"
                  fill="#10B981"
                  fillOpacity={0.25}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>
    </div>
  );
}
