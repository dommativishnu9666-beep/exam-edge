import React, { useEffect, useState } from 'react';
import {
  Bell,
  Download,
  LogIn,
  LogOut,
  Moon,
  RotateCcw,
  Save,
  ShieldCheck,
  Sun,
} from 'lucide-react';
import { usePlanner } from '../context/PlannerContext.tsx';
import { ConfirmDialog } from '../components/ui/ConfirmDialog.tsx';
import {
  buildRevisionsCsv,
  buildTopicsCsv,
  downloadCsvFile,
} from '../utils/csv.ts';

export function SettingsProfilePage() {
  const {
    planner,
    isDemoMode,
    updateProfile,
    setTheme,
    resetDemoData,
    signInWithGoogle,
    logout,
    notify,
  } = usePlanner();

  const [fullName, setFullName] = useState(planner.profile.fullName);
  const [studentId, setStudentId] = useState(planner.profile.studentId);
  const [course, setCourse] = useState(planner.profile.course);
  const [semester, setSemester] = useState(planner.profile.semester);
  const [dailyTargetHours, setDailyTargetHours] = useState(
    planner.profile.dailyTargetHours
  );
  const [notificationsEnabled, setNotificationsEnabled] = useState(
    planner.profile.notificationsEnabled
  );
  const [imgError, setImgError] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  useEffect(() => {
    setFullName(planner.profile.fullName);
    setStudentId(planner.profile.studentId);
    setCourse(planner.profile.course);
    setSemester(planner.profile.semester);
    setDailyTargetHours(planner.profile.dailyTargetHours);
    setNotificationsEnabled(planner.profile.notificationsEnabled);
  }, [planner.profile]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !studentId.trim() || !course.trim()) {
      setError('Full name, student ID, and course are required.');
      return;
    }
    if (
      !Number.isFinite(dailyTargetHours) ||
      dailyTargetHours < 1 ||
      dailyTargetHours > 16
    ) {
      setError('Daily target hours must be between 1 and 16.');
      return;
    }
    setError('');
    setSaving(true);
    try {
      await updateProfile({
        fullName: fullName.trim(),
        studentId: studentId.trim(),
        course: course.trim(),
        semester: semester.trim(),
        dailyTargetHours,
        notificationsEnabled,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleExportAllSyllabus = () => {
    const csv = buildTopicsCsv(planner.topics, planner.subjects);
    downloadCsvFile('examedge_all_syllabus.csv', csv);
    notify(
      `Exported ${planner.topics.length} syllabus topics to CSV.`,
      'success'
    );
  };

  const handleExportAllRevisions = () => {
    const csv = buildRevisionsCsv(planner.revisions, planner.subjects);
    downloadCsvFile('examedge_all_revisions.csv', csv);
    notify(
      `Exported ${planner.revisions.length} revision sessions to CSV.`,
      'success'
    );
  };

  const initials = planner.profile.fullName
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
          Student Profile & Settings
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Manage your academic details, daily study target, notification
          preferences, CSV exports, and appearance theme.
        </p>
      </div>

      <section className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
        <div className="flex items-center gap-4">
          {!imgError && planner.profile.avatarUrl ? (
            <img
              src={planner.profile.avatarUrl}
              alt={planner.profile.fullName}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700"
            />
          ) : (
            <div className="w-16 h-16 rounded-2xl bg-indigo-600 text-white font-display font-bold text-xl flex items-center justify-center">
              {initials || 'EE'}
            </div>
          )}
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              {planner.profile.fullName}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {planner.profile.course} · {planner.profile.semester}
            </p>
            <p className="text-xs font-mono text-slate-500 dark:text-slate-400 mt-1">
              ID: {planner.profile.studentId} · {planner.profile.email}
            </p>
          </div>
        </div>

        <div className="shrink-0">
          {isDemoMode ? (
            <button
              type="button"
              onClick={() => signInWithGoogle()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              Sign In with Google
            </button>
          ) : (
            <button
              type="button"
              onClick={() => logout()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          )}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-7 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-4">
            Edit Academic Profile
          </h3>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-sm text-rose-700 dark:text-rose-300">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  maxLength={120}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Student ID
                </label>
                <input
                  type="text"
                  maxLength={40}
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Course / Degree Program
              </label>
              <input
                type="text"
                maxLength={160}
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Semester
                </label>
                <input
                  type="text"
                  maxLength={80}
                  value={semester}
                  onChange={(e) => setSemester(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Daily Study Target (Hours)
                </label>
                <input
                  type="number"
                  min={1}
                  max={16}
                  value={dailyTargetHours}
                  onChange={(e) => setDailyTargetHours(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 transition-colors cursor-pointer"
              >
                <Save className="w-4 h-4" />
                {saving ? 'Saving...' : 'Save Profile'}
              </button>
            </div>
          </form>
        </section>

        <section className="lg:col-span-5 space-y-5">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-3">
              Theme Selection
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Switch between crisp daylight mode and low-glare evening dark
              mode.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTheme('light')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-semibold transition-all cursor-pointer ${
                  planner.profile.theme === 'light'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Sun className="w-4 h-4" />
                Light Mode
              </button>
              <button
                type="button"
                onClick={() => setTheme('dark')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-semibold transition-all cursor-pointer ${
                  planner.profile.theme === 'dark'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Moon className="w-4 h-4" />
                Dark Mode
              </button>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="font-display text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  Notification Preferences
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Display in-app reminders for upcoming revision sessions.
                </p>
              </div>
              <input
                type="checkbox"
                checked={notificationsEnabled}
                onChange={async (e) => {
                  const next = e.target.checked;
                  setNotificationsEnabled(next);
                  await updateProfile({ notificationsEnabled: next });
                }}
                className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer mt-1"
              />
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Data Backup & CSV Export
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={handleExportAllSyllabus}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  Export Syllabus CSV
                </button>
                <button
                  type="button"
                  onClick={handleExportAllRevisions}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  Export Revisions CSV
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                Account Security
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Authentication and password security are managed directly via
                your Google Account.
              </p>
              <button
                type="button"
                onClick={() =>
                  notify(
                    isDemoMode
                      ? 'Preview mode active. Sign in with Google to sync securely with PostgreSQL.'
                      : `Signed in as ${planner.profile.email} via Google Sign-In.`,
                    'info'
                  )
                }
                className="mt-2.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Verify Sign-In Status
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setConfirmResetOpen(true)}
                className="inline-flex items-center gap-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Restore Sample Demonstration Starter Data
              </button>
            </div>
          </div>
        </section>
      </div>

      <ConfirmDialog
        isOpen={confirmResetOpen}
        onClose={() => setConfirmResetOpen(false)}
        onConfirm={() => resetDemoData()}
        title="Restore Sample Starter Data?"
        message="This will replace your current subjects, syllabus topics, and revision calendar with the starter sample dataset. Export your CSVs first if you want to keep a copy."
        confirmLabel="Restore Sample Data"
        variant="danger"
      />
    </div>
  );
}
