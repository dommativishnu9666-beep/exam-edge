import {
  ArrowRight,
  BookOpen,
  Brain,
  CheckCircle2,
  Clock,
  Heart,
  Lightbulb,
  Repeat,
  Search,
  Sparkles,
  Target,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { STUDY_TIPS, TIP_CATEGORIES } from '../data/studyTips.ts';
import { usePlanner } from '../context/PlannerContext.tsx';
import { SUBJECT_PALETTE, type StudyTip } from '../types/examedge.ts';
import { Modal } from '../components/ui/Modal.tsx';

function getCategoryIcon(category: StudyTip['category']) {
  switch (category) {
    case 'Time Management':
      return Clock;
    case 'Effective Note Making':
      return BookOpen;
    case 'Memory Improvement':
      return Brain;
    case 'Exam Preparation':
      return Target;
    case 'Concentration & Focus':
      return Sparkles;
    case 'Revision Techniques':
      return Repeat;
    default:
      return Lightbulb;
  }
}

export function StudyTipsPage() {
  const { planner, toggleFavoriteTip } = usePlanner();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTip, setActiveTip] = useState<StudyTip | null>(null);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const dailyTip = STUDY_TIPS[new Date().getDate() % STUDY_TIPS.length];

  const filteredTips = useMemo(() => {
    return STUDY_TIPS.filter((tip) => {
      if (selectedCategory !== 'All' && tip.category !== selectedCategory) {
        return false;
      }
      if (favoritesOnly && !planner.favoriteTipIds.includes(tip.id)) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          tip.title.toLowerCase().includes(q) ||
          tip.summary.toLowerCase().includes(q) ||
          tip.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [favoritesOnly, planner.favoriteTipIds, searchQuery, selectedCategory]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
            Study Smarter, Not Harder.
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Discover practical study strategies to improve focus, consistency,
            and academic performance.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setFavoritesOnly((prev) => !prev)}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            favoritesOnly
              ? 'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-950/60 dark:border-rose-800 dark:text-rose-300'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Heart
            className={`w-4 h-4 ${favoritesOnly ? 'fill-rose-500 text-rose-500' : ''}`}
          />
          Saved Favorites ({planner.favoriteTipIds.length})
        </button>
      </div>

      <section className="rounded-2xl overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
              Daily Tip of the Day · {dailyTip.category} · {dailyTip.readTime}
            </p>
            <h2 className="mt-2 font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {dailyTip.title}
            </h2>
            <p className="mt-2.5 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              {dailyTip.summary}
            </p>
            <ul className="mt-4 space-y-2">
              {dailyTip.steps.slice(0, 3).map((step, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              type="button"
              onClick={() => setActiveTip(dailyTip)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors cursor-pointer"
            >
              Read Full Strategy
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => toggleFavoriteTip(dailyTip.id)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <Heart
                className={`w-4 h-4 ${
                  planner.favoriteTipIds.includes(dailyTip.id)
                    ? 'fill-rose-500 text-rose-500'
                    : ''
                }`}
              />
              {planner.favoriteTipIds.includes(dailyTip.id)
                ? 'Favorited'
                : 'Save Tip'}
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 bg-slate-100 dark:bg-slate-800 min-h-[220px]">
          {dailyTip.imageUrl && !failedImages[dailyTip.id] ? (
            <img
              src={dailyTip.imageUrl}
              alt={dailyTip.title}
              referrerPolicy="no-referrer"
              onError={() =>
                setFailedImages((prev) => ({ ...prev, [dailyTip.id]: true }))
              }
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center p-8 text-white">
              <Lightbulb className="w-16 h-16 opacity-85" />
            </div>
          )}
        </div>
      </section>

      <section className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1.5">
          {TIP_CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full lg:w-64 shrink-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search study tips..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>
      </section>

      {filteredTips.length === 0 ? (
        <div className="p-10 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            No study tips match your search or category filter.
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('All');
              setFavoritesOnly(false);
              setSearchQuery('');
            }}
            className="mt-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
          >
            Show all tips
          </button>
        </div>
      ) : (
        <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredTips.map((tip) => {
            const palette =
              SUBJECT_PALETTE[tip.accentColor] ?? SUBJECT_PALETTE.indigo;
            const Icon = getCategoryIcon(tip.category);
            const isFav = planner.favoriteTipIds.includes(tip.id);

            return (
              <article
                key={tip.id}
                className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md transition-all duration-150 flex flex-col justify-between"
              >
                <div>
                  <div className="h-40 w-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    {tip.imageUrl && !failedImages[tip.id] ? (
                      <img
                        src={tip.imageUrl}
                        alt={tip.title}
                        referrerPolicy="no-referrer"
                        onError={() =>
                          setFailedImages((prev) => ({
                            ...prev,
                            [tip.id]: true,
                          }))
                        }
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div
                        className={`w-full h-full bg-gradient-to-br ${palette.gradient} flex items-center justify-center text-white`}
                      >
                        <Icon className="w-12 h-12 opacity-90" />
                      </div>
                    )}
                  </div>

                  <div className="p-5">
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                        {tip.category} · {tip.readTime}
                      </span>
                      <button
                        type="button"
                        onClick={() => toggleFavoriteTip(tip.id)}
                        aria-label={
                          isFav ? 'Remove from favorites' : 'Save to favorites'
                        }
                        className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            isFav
                              ? 'fill-rose-500 text-rose-500'
                              : 'text-slate-400'
                          }`}
                        />
                      </button>
                    </div>

                    <h3 className="mt-1.5 font-display text-lg font-bold text-slate-900 dark:text-white">
                      {tip.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {tip.summary}
                    </p>

                    <ul className="mt-3.5 space-y-1.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                      {tip.steps.slice(0, 2).map((step, i) => (
                        <li
                          key={i}
                          className="text-xs text-slate-600 dark:text-slate-400 flex items-start gap-2"
                        >
                          <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                            0{i + 1}.
                          </span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="px-5 pb-5">
                  <button
                    type="button"
                    onClick={() => setActiveTip(tip)}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border border-indigo-200/80 dark:border-indigo-800/80 transition-colors cursor-pointer"
                  >
                    Read More
                  </button>
                </div>
              </article>
            );
          })}
        </section>
      )}

      <Modal
        isOpen={Boolean(activeTip)}
        onClose={() => setActiveTip(null)}
        title={activeTip?.title ?? ''}
        subtitle={
          activeTip
            ? `${activeTip.category} · ${activeTip.readTime}`
            : undefined
        }
        maxWidth="max-w-xl"
      >
        {activeTip && (
          <div className="space-y-4">
            <p className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
              {activeTip.summary}
            </p>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
              <p className="text-xs font-bold text-slate-900 dark:text-white mb-1.5">
                Why It Works
              </p>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {activeTip.deepDive}
              </p>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white mb-2">
                Practical Action Steps
              </p>
              <ol className="space-y-2">
                {activeTip.steps.map((step, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2.5 text-sm text-slate-700 dark:text-slate-300"
                  >
                    <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400 mt-0.5">
                      0{i + 1}.
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
