import { useMemo, useState } from 'react';
import {
  Activity,
  ArrowRight,
  BookOpen,
  CalendarClock,
  CheckCircle2,
  Clock,
  Plus,
  Target,
  TrendingUp,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { usePlanner } from '../context/PlannerContext.tsx';
import {
  SUBJECT_PALETTE,
  formatDurationLabel,
  formatShortDate,
  type AppPage,
} from '../types/examedge.ts';
import { shiftDateISO } from '../data/demoSeed.ts';
import { PriorityBadge } from '../components/ui/Badges.tsx';
import { ChartTooltip } from '../components/ui/ChartTooltip.tsx';
import { StudyLogModal } from '../components/modals/StudyLogModal.tsx';

interface DashboardPageProps {
  onNavigate: (page: AppPage) => void;
  onOpenSubjectSyllabus: (subjectId: number) => void;
  onQuickAddRevision: () => void;
}

type DashboardChartTab = 'hours' | 'readiness' | 'topics';

const MOTIVATIONAL_QUOTES = [
  'Small daily focus sessions compound into effortless exam confidence.',
  'Clarity over cramming: master one unit deeply at a time.',
  'Every completed revision block lowers exam-week stress.',
];

export function DashboardPage({
  onNavigate,
  onOpenSubjectSyllabus,
  onQuickAddRevision,
}: DashboardPageProps) {
  const { planner, updateTopic, updateRevision, logStudyMinutes } =
    usePlanner();

  const [chartTab, setChartTab] = useState<DashboardChartTab>('hours');
  const [hoursWindow, setHoursWindow] = useState<7 | 14>(7);
  const [studyLogOpen, setStudyLogOpen] = useState(false);

  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

  const todayISO = shiftDateISO(0);
  const formattedToday = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  const totalSubjects = planner.subjects.length;
  const completedTopics = planner.topics.filter(
    (t) => t.status === 'Completed'
  ).length;
  const inProgressTopics = planner.topics.filter(
    (t) => t.status === 'In Progress'
  ).length;
  const notStartedTopics = planner.topics.filter(
    (t) => t.status === 'Not Started'
  ).length;
  const pendingTopics = planner.topics.length - completedTopics;
  const progressPct =
    planner.topics.length > 0
      ? Math.round((completedTopics / planner.topics.length) * 100)
      : 0;

  const todaysRevisions = planner.revisions.filter(
    (r) => r.sessionDate === todayISO
  );
  const plannedTopicsToday = planner.topics
    .filter((t) => t.status !== 'Completed')
    .slice(0, 4);

  const nextRevision = planner.revisions.find(
    (r) => r.status === 'Pending' && r.sessionDate >= todayISO
  );

  const todayLoggedMinutes = planner.studyLogs
    .filter((l) => l.logDate === todayISO)
    .reduce((acc, l) => acc + l.minutes, 0);
  const targetMinutes = planner.profile.dailyTargetHours * 60;
  const dailyTargetPct = Math.min(
    100,
    Math.round((todayLoggedMinutes / Math.max(1, targetMinutes)) * 100)
  );

  const studyHoursSeries = useMemo(() => {
    return Array.from({ length: hoursWindow }, (_, idx) => {
      const offset = -(hoursWindow - 1 - idx);
      const iso = shiftDateISO(offset);
      const parts = iso.split('-').map(Number);
      const d = new Date(parts[0], parts[1] - 1, parts[2]);
      const label =
        hoursWindow === 7
          ? d.toLocaleDateString('en-US', { weekday: 'short' })
          : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const mins = planner.studyLogs
        .filter((l) => l.logDate === iso)
        .reduce((sum, l) => sum + l.minutes, 0);
      return {
        day: label,
        hours: Number((mins / 60).toFixed(1)),
      };
    });
  }, [hoursWindow, planner.studyLogs]);

  const subjectReadinessSeries = useMemo(() => {
    return planner.subjects.map((subj) => {
      const subTopics = planner.topics.filter((t) => t.subjectId === subj.id);
      const done = subTopics.filter((t) => t.status === 'Completed').length;
      const pct =
        subTopics.length > 0 ? Math.round((done / subTopics.length) * 100) : 0;
      return {
        subjectId: subj.id,
        code: subj.code,
        name: subj.name,
        readiness: pct,
        colorHex: (SUBJECT_PALETTE[subj.color] ?? SUBJECT_PALETTE.indigo).hex,
      };
    });
  }, [planner.subjects, planner.topics]);

  const topicBreakdownPie = useMemo(
    () =>
      [
        { name: 'Completed', value: completedTopics, color: '#10B981' },
        { name: 'In Progress', value: inProgressTopics, color: '#2563EB' },
        { name: 'Not Started', value: notStartedTopics, color: '#94A3B8' },
      ].filter((d) => d.value > 0),
    [completedTopics, inProgressTopics, notStartedTopics]
  );

  const upcomingExams = [...planner.subjects]
    .sort((a, b) => a.examDate.localeCompare(b.examDate))
    .slice(0, 4)
    .map((subj) => {
      const subTopics = planner.topics.filter((t) => t.subjectId === subj.id);
      const subDone = subTopics.filter((t) => t.status === 'Completed').length;
      const pct =
        subTopics.length > 0
          ? Math.round((subDone / subTopics.length) * 100)
          : 0;

      const [ey, em, ed] = subj.examDate.split('-').map(Number);
      const examDt = new Date(ey, em - 1, ed);
      const nowDt = new Date();
      const todayMidnight = new Date(
        nowDt.getFullYear(),
        nowDt.getMonth(),
        nowDt.getDate()
      );
      const daysLeft = Math.ceil(
        (examDt.getTime() - todayMidnight.getTime()) / (1000 * 60 * 60 * 24)
      );

      return { subj, pct, daysLeft };
    });

  const quote =
    MOTIVATIONAL_QUOTES[new Date().getDate() % MOTIVATIONAL_QUOTES.length];

  return (
    <div className="space-y-6">
      <section className="rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-blue-600 p-6 sm:p-8 text-white shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <p className="text-xs font-medium text-indigo-100">
              {formattedToday} · {planner.profile.course}
            </p>
            <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold tracking-tight">
              {greeting}, {planner.profile.fullName.split(' ')[0]}!
            </h1>
            <p className="mt-1.5 text-sm sm:text-base text-indigo-100">
              Every small step brings you closer to success.
            </p>
            <p className="mt-3 text-xs text-indigo-100/90 italic">
              “{quote}”
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() =>
                logStudyMinutes(30, 'Logged 30m focused study sprint')
              }
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs sm:text-sm font-semibold border border-white/20 backdrop-blur-xs transition-colors cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              +30m Quick
            </button>
            <button
              type="button"
              onClick={() => setStudyLogOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs sm:text-sm font-semibold border border-white/20 backdrop-blur-xs transition-colors cursor-pointer whitespace-nowrap"
            >
              <Clock className="w-4 h-4" />
              Log Study Session
            </button>
            <button
              type="button"
              onClick={onQuickAddRevision}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-indigo-700 hover:bg-indigo-50 text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer whitespace-nowrap"
            >
              <CalendarClock className="w-4 h-4" />
              Schedule Revision
            </button>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => onNavigate('subjects')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Total Subjects
            </span>
            <span className="p-2 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400">
              <BookOpen className="w-4 h-4" />
            </span>
          </div>
          <p className="mt-3 font-display text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
            {totalSubjects}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Enrolled subjects this semester
          </p>
          <div className="mt-3 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 w-full rounded-full" />
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('syllabus')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Completed Topics
            </span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <p className="mt-3 font-display text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
            {completedTopics}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Out of {planner.topics.length} syllabus topics
          </p>
          <div className="mt-3 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('syllabus')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-700 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Pending Topics
            </span>
            <span className="p-2 rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <p className="mt-3 font-display text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
            {pendingTopics}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Remaining topics to master
          </p>
          <div className="mt-3 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-300"
              style={{ width: `${100 - progressPct}%` }}
            />
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('analytics')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-violet-300 dark:hover:border-violet-700 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Study Progress
            </span>
            <span className="p-2 rounded-xl bg-violet-50 text-violet-600 dark:bg-violet-950/60 dark:text-violet-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <p className="mt-3 font-display text-3xl font-bold text-slate-900 dark:text-white tabular-nums">
            {progressPct}%
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Overall syllabus completion
          </p>
          <div className="mt-3 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-600 to-violet-600 rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </button>
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <section className="xl:col-span-7 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  Today's Study Overview
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Check off planned syllabus topics or revision blocks as you
                  finish them.
                </p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-xs text-slate-500 dark:text-slate-400 block">
                  Daily Target
                </span>
                <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                  {(todayLoggedMinutes / 60).toFixed(1)}h /{' '}
                  {planner.profile.dailyTargetHours}h
                </span>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                <span className="inline-flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  Daily Study Progress
                </span>
                <span className="font-mono font-semibold tabular-nums">
                  {dailyTargetPct}%
                </span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full transition-all duration-300"
                  style={{ width: `${dailyTargetPct}%` }}
                />
              </div>
            </div>

            <div className="mt-5 space-y-2.5">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Today's Revision Sessions ({todaysRevisions.length})
              </p>
              {todaysRevisions.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-400 py-2">
                  No revision sessions scheduled for today.
                </p>
              ) : (
                todaysRevisions.map((rev) => {
                  const subj = planner.subjects.find(
                    (s) => s.id === rev.subjectId
                  );
                  const done = rev.status === 'Completed';
                  return (
                    <label
                      key={rev.id}
                      className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <input
                          type="checkbox"
                          checked={done}
                          onChange={() =>
                            updateRevision(rev.id, {
                              status: done ? 'Pending' : 'Completed',
                            })
                          }
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer shrink-0"
                        />
                        <div className="min-w-0">
                          <p
                            className={`text-sm font-medium truncate ${
                              done
                                ? 'line-through text-slate-400 dark:text-slate-500'
                                : 'text-slate-900 dark:text-white'
                            }`}
                          >
                            {rev.topicTitle}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {subj?.name ?? 'Subject'} · {rev.startTime}–
                            {rev.endTime} ·{' '}
                            {formatDurationLabel(rev.durationMinutes)}
                          </p>
                        </div>
                      </div>
                      <PriorityBadge priority={rev.priority} />
                    </label>
                  );
                })
              )}

              <p className="pt-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                Priority Syllabus Queue ({plannedTopicsToday.length})
              </p>
              {plannedTopicsToday.length === 0 ? (
                <p className="text-sm text-emerald-700 dark:text-emerald-400 py-2 font-medium">
                  All syllabus topics are currently completed!
                </p>
              ) : (
                plannedTopicsToday.map((topic) => {
                  const subj = planner.subjects.find(
                    (s) => s.id === topic.subjectId
                  );
                  return (
                    <label
                      key={topic.id}
                      className="flex items-center justify-between gap-3 p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <input
                          type="checkbox"
                          checked={false}
                          onChange={() =>
                            updateTopic(topic.id, { status: 'Completed' })
                          }
                          className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600 cursor-pointer shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                            {topic.topicTitle}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {subj?.code} · Unit {topic.unitNumber}:{' '}
                            {topic.unitName} · {topic.estimatedHours}h est.
                          </p>
                        </div>
                      </div>
                      <PriorityBadge priority={topic.priority} />
                    </label>
                  );
                })
              )}
            </div>
          </div>

          {nextRevision && (
            <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-slate-600 dark:text-slate-300">
                <strong className="text-slate-900 dark:text-white">
                  Next Revision:
                </strong>{' '}
                {nextRevision.topicTitle} ({formatShortDate(nextRevision.sessionDate)}{' '}
                at {nextRevision.startTime})
              </span>
              <button
                type="button"
                onClick={() => onNavigate('calendar')}
                className="inline-flex items-center gap-1 font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer shrink-0"
              >
                Open Calendar
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </section>

        <section className="xl:col-span-5 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  Interactive Study Analytics
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {chartTab === 'hours'
                    ? `Hours logged over the last ${hoursWindow} days`
                    : chartTab === 'readiness'
                      ? 'Click any subject bar to open its syllabus'
                      : 'Syllabus topic completion breakdown'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('analytics')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Full Analytics
              </button>
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <div className="inline-flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                {(
                  [
                    { id: 'hours', label: 'Study Hours' },
                    { id: 'readiness', label: 'Readiness' },
                    { id: 'topics', label: 'Topics' },
                  ] as Array<{ id: DashboardChartTab; label: string }>
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setChartTab(t.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      chartTab === t.id
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {chartTab === 'hours' && (
                <div className="inline-flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() => setHoursWindow(7)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-mono font-semibold cursor-pointer ${
                      hoursWindow === 7
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    7D
                  </button>
                  <button
                    type="button"
                    onClick={() => setHoursWindow(14)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-mono font-semibold cursor-pointer ${
                      hoursWindow === 14
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    14D
                  </button>
                </div>
              )}
            </div>

            <div className="mt-4 h-60 w-full">
              {chartTab === 'hours' && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={studyHoursSeries}>
                    <defs>
                      <linearGradient id="dashBarGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#4F46E5" stopOpacity={1} />
                        <stop
                          offset="100%"
                          stopColor="#06B6D4"
                          stopOpacity={0.85}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#E2E8F0"
                      opacity={0.45}
                    />
                    <XAxis
                      dataKey="day"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      unit="h"
                    />
                    <Tooltip
                      cursor={{ fill: 'rgba(99, 102, 241, 0.08)' }}
                      content={<ChartTooltip unitSuffix="h" />}
                    />
                    <Bar
                      dataKey="hours"
                      name="Study Hours"
                      fill="url(#dashBarGrad)"
                      radius={[8, 8, 0, 0]}
                      maxBarSize={32}
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}

              {chartTab === 'readiness' && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={subjectReadinessSeries}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#E2E8F0"
                      opacity={0.45}
                    />
                    <XAxis
                      dataKey="code"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                    />
                    <YAxis
                      domain={[0, 100]}
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      unit="%"
                    />
                    <Tooltip
                      cursor={{ fill: 'rgba(99, 102, 241, 0.08)' }}
                      content={<ChartTooltip unitSuffix="%" />}
                    />
                    <Bar
                      dataKey="readiness"
                      name="Readiness"
                      radius={[8, 8, 0, 0]}
                      maxBarSize={38}
                      className="cursor-pointer"
                      onClick={(data) => {
                        const payload = (
                          data as { payload?: { subjectId?: number } }
                        )?.payload;
                        const sid = Number(payload?.subjectId);
                        if (sid > 0) onOpenSubjectSyllabus(sid);
                      }}
                    >
                      {subjectReadinessSeries.map((entry) => (
                        <Cell key={entry.subjectId} fill={entry.colorHex} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}

              {chartTab === 'topics' && (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={topicBreakdownPie}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={52}
                      outerRadius={82}
                      paddingAngle={4}
                    >
                      {topicBreakdownPie.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<ChartTooltip unitSuffix=" topics" />} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>
              {chartTab === 'hours'
                ? `${hoursWindow}-Day Study Total`
                : chartTab === 'readiness'
                  ? 'Average Readiness'
                  : 'Total Syllabus Topics'}
            </span>
            <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
              {chartTab === 'hours'
                ? `${studyHoursSeries.reduce((s, d) => s + d.hours, 0).toFixed(1)} hours`
                : chartTab === 'readiness'
                  ? `${progressPct}% overall`
                  : `${planner.topics.length} topics`}
            </span>
          </div>
        </section>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <section className="xl:col-span-7 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Upcoming Exams
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Countdown and current syllabus readiness per subject
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('subjects')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              Manage Subjects
            </button>
          </div>

          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {upcomingExams.map(({ subj, pct, daysLeft }) => {
              const palette =
                SUBJECT_PALETTE[subj.color] ?? SUBJECT_PALETTE.indigo;
              return (
                <button
                  key={subj.id}
                  type="button"
                  onClick={() => onOpenSubjectSyllabus(subj.id)}
                  className="text-left p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-mono font-semibold text-slate-500 dark:text-slate-400">
                        {subj.code} · {formatShortDate(subj.examDate)}
                      </p>
                      <h3 className="font-display font-bold text-sm text-slate-900 dark:text-white truncate mt-0.5">
                        {subj.name}
                      </h3>
                    </div>
                    <PriorityBadge priority={subj.priority} />
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums">
                      {daysLeft >= 0 ? `${daysLeft} days left` : 'Exam passed'}
                    </span>
                    <span className="font-mono font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                      {pct}% ready
                    </span>
                  </div>

                  <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${palette.gradient} rounded-full transition-all duration-300`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        <section className="xl:col-span-5 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Recent Activity
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Latest completed topics, revisions, and study updates
              </p>
            </div>
            <Activity className="w-4 h-4 text-slate-400" />
          </div>

          <div className="mt-3 divide-y divide-slate-100 dark:divide-slate-800">
            {planner.studyLogs.slice(0, 5).map((log) => (
              <div
                key={log.id}
                className="py-3 flex items-start justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
                    {log.description}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {formatShortDate(log.logDate)}
                  </p>
                </div>
                {log.minutes > 0 && (
                  <span className="font-mono text-xs font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums shrink-0">
                    +{formatDurationLabel(log.minutes)}
                  </span>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>

      <StudyLogModal
        isOpen={studyLogOpen}
        onClose={() => setStudyLogOpen(false)}
      />
    </div>
  );
}
