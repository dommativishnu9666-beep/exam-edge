import { BookOpen, CalendarDays, CheckCircle2, HelpCircle, Lightbulb } from 'lucide-react';
import type { AppPage } from '../types/examedge.ts';

export function HelpSupportPage({
  onNavigate,
}: {
  onNavigate: (page: AppPage) => void;
}) {
  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
          Help & Support
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Quick-start workflow guide to organizing your subjects, syllabus
          tables, and revision calendar.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => onNavigate('subjects')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors cursor-pointer"
        >
          <BookOpen className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mb-3" />
          <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
            1. Organize Subjects & Units
          </h2>
          <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300">
            Add your semester courses in My Subjects, then open any subject's
            Syllabus Table to mark topics completed or add study notes.
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('calendar')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors cursor-pointer"
        >
          <CalendarDays className="w-5 h-5 text-blue-600 dark:text-blue-400 mb-3" />
          <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
            2. Schedule Timed Revisions
          </h2>
          <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300">
            Click any date in the Monthly or Weekly calendar to filter sessions
            or schedule new revision blocks with automatic duration calculation.
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('tips')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors cursor-pointer"
        >
          <Lightbulb className="w-5 h-5 text-amber-600 dark:text-amber-400 mb-3" />
          <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
            3. Save Favorite Study Strategies
          </h2>
          <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300">
            Filter Study Tips by category, read full step-by-step guides, and
            bookmark techniques like Pomodoro and Active Recall.
          </p>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('dashboard')}
          className="text-left p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors cursor-pointer"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mb-3" />
          <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
            4. Track Daily Progress
          </h2>
          <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300">
            Every checked topic or completed revision automatically updates your
            dashboard cards, exam countdown readiness, and analytics charts.
          </p>
        </button>
      </div>

      <section className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          Frequently Asked Questions
        </h2>
        <div className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
          <div className="py-3">
            <p className="font-semibold text-slate-900 dark:text-white">
              How is my data saved across sessions?
            </p>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              When you sign in with Google, all subjects, syllabus topics,
              revisions, favorites, and profile settings are persisted to your
              private PostgreSQL account. Before signing in, you can explore the
              full app in interactive sample preview mode.
            </p>
          </div>
          <div className="py-3">
            <p className="font-semibold text-slate-900 dark:text-white">
              Can I restore the initial sample subjects?
            </p>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              Yes! Open Settings &amp; Profile and click &ldquo;Restore Sample
              Demonstration Starter Data&rdquo; at any time.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
