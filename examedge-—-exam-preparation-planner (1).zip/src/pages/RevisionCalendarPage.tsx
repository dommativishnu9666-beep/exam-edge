import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  Bell,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Download,
  Edit3,
  Plus,
  Search,
  Trash2,
  Upload,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { usePlanner } from '../context/PlannerContext.tsx';
import {
  SUBJECT_PALETTE,
  formatDayName,
  formatDurationLabel,
  formatShortDate,
  type PriorityLevel,
  type RevisionSession,
  type RevisionStatus,
} from '../types/examedge.ts';
import { shiftDateISO } from '../data/demoSeed.ts';
import { PriorityBadge } from '../components/ui/Badges.tsx';
import { Pagination } from '../components/ui/Pagination.tsx';
import { ConfirmDialog } from '../components/ui/ConfirmDialog.tsx';
import { RevisionModal } from '../components/modals/RevisionModal.tsx';
import { CsvImportModal } from '../components/modals/CsvImportModal.tsx';
import { buildRevisionsCsv, downloadCsvFile } from '../utils/csv.ts';

function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

type RevisionSortField =
  | 'sessionDate'
  | 'subject'
  | 'durationMinutes'
  | 'priority'
  | 'status';

const PRIORITY_WEIGHT: Record<PriorityLevel, number> = {
  High: 3,
  Medium: 2,
  Low: 1,
};

const REV_STATUS_WEIGHT: Record<RevisionStatus, number> = {
  Pending: 1,
  Missed: 2,
  Completed: 3,
};

export function RevisionCalendarPage() {
  const {
    planner,
    updateRevision,
    deleteRevision,
    bulkActionRevisions,
    notify,
  } = usePlanner();

  const todayISO = shiftDateISO(0);
  const tomorrowISO = shiftDateISO(1);

  const [viewMode, setViewMode] = useState<'monthly' | 'weekly'>('monthly');
  const [cursorDate, setCursorDate] = useState(() => new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const [subjectFilter, setSubjectFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [sortField, setSortField] = useState<RevisionSortField>('sessionDate');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedRevisionIds, setSelectedRevisionIds] = useState<number[]>([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingRevision, setEditingRevision] =
    useState<RevisionSession | null>(null);
  const [csvImportOpen, setCsvImportOpen] = useState(false);

  const [confirmDeleteRev, setConfirmDeleteRev] =
    useState<RevisionSession | null>(null);
  const [confirmBulkDeleteOpen, setConfirmBulkDeleteOpen] = useState(false);

  const [browserNotifState, setBrowserNotifState] = useState<string>(() =>
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'unsupported'
  );

  const monthLabel = cursorDate.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  // Build 6x7 monthly grid starting on Sunday
  const monthlyCells = useMemo(() => {
    const year = cursorDate.getFullYear();
    const month = cursorDate.getMonth();
    const firstOfMonth = new Date(year, month, 1);
    const startOffset = firstOfMonth.getDay();
    const gridStart = new Date(year, month, 1 - startOffset);

    return Array.from({ length: 42 }, (_, idx) => {
      const cellDate = new Date(
        gridStart.getFullYear(),
        gridStart.getMonth(),
        gridStart.getDate() + idx
      );
      return {
        date: cellDate,
        iso: toISODate(cellDate),
        inCurrentMonth: cellDate.getMonth() === month,
      };
    });
  }, [cursorDate]);

  // Build 7-day weekly grid centered around cursorDate's week (Sun-Sat)
  const weeklyCells = useMemo(() => {
    const dayOfWeek = cursorDate.getDay();
    const startOfWeek = new Date(
      cursorDate.getFullYear(),
      cursorDate.getMonth(),
      cursorDate.getDate() - dayOfWeek
    );
    return Array.from({ length: 7 }, (_, idx) => {
      const d = new Date(
        startOfWeek.getFullYear(),
        startOfWeek.getMonth(),
        startOfWeek.getDate() + idx
      );
      return {
        date: d,
        iso: toISODate(d),
        label: d.toLocaleDateString('en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
        }),
      };
    });
  }, [cursorDate]);

  const handlePrev = () => {
    setCursorDate((prev) =>
      viewMode === 'monthly'
        ? new Date(prev.getFullYear(), prev.getMonth() - 1, 1)
        : new Date(prev.getFullYear(), prev.getMonth(), prev.getDate() - 7)
    );
  };

  const handleNext = () => {
    setCursorDate((prev) =>
      viewMode === 'monthly'
        ? new Date(prev.getFullYear(), prev.getMonth() + 1, 1)
        : new Date(prev.getFullYear(), prev.getMonth(), prev.getDate() + 7)
    );
  };

  const handleToday = () => {
    const now = new Date();
    setCursorDate(now);
    setSelectedDate(toISODate(now));
  };

  const filteredAndSortedRevisions = useMemo(() => {
    const subjectMap = new Map(planner.subjects.map((s) => [s.id, s]));
    const filtered = planner.revisions.filter((r) => {
      if (selectedDate && r.sessionDate !== selectedDate) return false;
      if (subjectFilter !== 'all' && String(r.subjectId) !== subjectFilter) {
        return false;
      }
      if (statusFilter !== 'all' && r.status !== statusFilter) return false;
      if (priorityFilter !== 'all' && r.priority !== priorityFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const subj = subjectMap.get(r.subjectId);
        return (
          r.topicTitle.toLowerCase().includes(q) ||
          r.notes.toLowerCase().includes(q) ||
          (subj?.name.toLowerCase().includes(q) ?? false) ||
          (subj?.code.toLowerCase().includes(q) ?? false)
        );
      }
      return true;
    });

    const mult = sortDir === 'asc' ? 1 : -1;
    return [...filtered].sort((a, b) => {
      let cmp = 0;
      if (sortField === 'sessionDate') {
        cmp = `${a.sessionDate}${a.startTime}`.localeCompare(
          `${b.sessionDate}${b.startTime}`
        );
      } else if (sortField === 'subject') {
        const sa = subjectMap.get(a.subjectId)?.name ?? '';
        const sb = subjectMap.get(b.subjectId)?.name ?? '';
        cmp = sa.localeCompare(sb);
      } else if (sortField === 'durationMinutes') {
        cmp = a.durationMinutes - b.durationMinutes;
      } else if (sortField === 'priority') {
        cmp = PRIORITY_WEIGHT[a.priority] - PRIORITY_WEIGHT[b.priority];
      } else if (sortField === 'status') {
        cmp = REV_STATUS_WEIGHT[a.status] - REV_STATUS_WEIGHT[b.status];
      }
      return cmp !== 0 ? cmp * mult : a.id - b.id;
    });
  }, [
    planner.revisions,
    planner.subjects,
    priorityFilter,
    searchQuery,
    selectedDate,
    sortDir,
    sortField,
    statusFilter,
    subjectFilter,
  ]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredAndSortedRevisions.length / pageSize)
  );
  const safePage = Math.min(currentPage, totalPages);

  useEffect(() => {
    setCurrentPage(1);
    setSelectedRevisionIds([]);
  }, [selectedDate, subjectFilter, statusFilter, priorityFilter, searchQuery]);

  const paginatedRevisions = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredAndSortedRevisions.slice(start, start + pageSize);
  }, [filteredAndSortedRevisions, pageSize, safePage]);

  const pageRevisionIds = useMemo(
    () => paginatedRevisions.map((r) => r.id),
    [paginatedRevisions]
  );
  const allOnPageSelected =
    pageRevisionIds.length > 0 &&
    pageRevisionIds.every((id) => selectedRevisionIds.includes(id));

  const toggleSort = (field: RevisionSortField) => {
    if (sortField === field) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const renderSortIcon = (field: RevisionSortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />;
    }
    return sortDir === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
    );
  };

  const toggleRevisionSelection = (id: number) => {
    setSelectedRevisionIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAllOnPage = () => {
    if (allOnPageSelected) {
      setSelectedRevisionIds((prev) =>
        prev.filter((id) => !pageRevisionIds.includes(id))
      );
    } else {
      setSelectedRevisionIds((prev) =>
        Array.from(new Set([...prev, ...pageRevisionIds]))
      );
    }
  };

  const handleExportCsv = () => {
    const csv = buildRevisionsCsv(filteredAndSortedRevisions, planner.subjects);
    downloadCsvFile('examedge_revision_schedule.csv', csv);
    notify(
      `Exported ${filteredAndSortedRevisions.length} revision sessions to CSV.`,
      'success'
    );
  };

  const reminders = planner.revisions.filter(
    (r) =>
      r.status === 'Pending' &&
      (r.sessionDate === todayISO || r.sessionDate === tomorrowISO)
  );

  const handleEnableBrowserReminders = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      notify('Browser notifications are not supported in this browser.', 'info');
      return;
    }
    const perm = await Notification.requestPermission();
    setBrowserNotifState(perm);
    if (perm === 'granted') {
      notify('Browser revision reminders enabled!', 'success');
    } else {
      notify('Notification permission was not granted.', 'info');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
            My Revision Calendar
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Plan your revisions, manage your time, and stay prepared for every
            examination.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {browserNotifState !== 'granted' &&
            browserNotifState !== 'unsupported' && (
              <button
                type="button"
                onClick={handleEnableBrowserReminders}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
              >
                <Bell className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                Enable Reminders
              </button>
            )}

          <button
            type="button"
            onClick={() => setCsvImportOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            Import CSV
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            Export CSV
          </button>

          <button
            type="button"
            onClick={() => {
              setEditingRevision(null);
              setModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-xs transition-all cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Add Revision
          </button>
        </div>
      </div>

      {reminders.length > 0 && (
        <section className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/80 dark:border-indigo-800/80">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2 text-sm font-bold text-indigo-950 dark:text-indigo-100">
              <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              Upcoming Revision Reminders ({reminders.length})
            </div>
            <span className="text-xs text-indigo-700 dark:text-indigo-300">
              Due today & tomorrow
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {reminders.map((rem) => {
              const subj = planner.subjects.find(
                (s) => s.id === rem.subjectId
              );
              return (
                <div
                  key={rem.id}
                  className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400">
                      {subj?.code} ·{' '}
                      {rem.sessionDate === todayISO ? 'Today' : 'Tomorrow'} ·{' '}
                      {rem.startTime}
                    </p>
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate mt-0.5">
                      {rem.topicTitle}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      updateRevision(rem.id, { status: 'Completed' })
                    }
                    title="Mark completed"
                    className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-300 cursor-pointer shrink-0"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <section className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handlePrev}
              aria-label="Previous period"
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleToday}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              Today
            </button>
            <button
              type="button"
              onClick={handleNext}
              aria-label="Next period"
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <h2 className="ml-2 font-display text-lg font-bold text-slate-900 dark:text-white">
              {monthLabel}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {selectedDate && (
              <button
                type="button"
                onClick={() => setSelectedDate(null)}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Show All Dates ({formatShortDate(selectedDate)} selected)
              </button>
            )}

            <div className="inline-flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setViewMode('monthly')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  viewMode === 'monthly'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Monthly Calendar
              </button>
              <button
                type="button"
                onClick={() => setViewMode('weekly')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  viewMode === 'weekly'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Weekly Schedule
              </button>
            </div>
          </div>
        </div>

        {viewMode === 'monthly' ? (
          <div className="mt-4">
            <div className="grid grid-cols-7 gap-1.5 text-center text-xs font-semibold text-slate-500 dark:text-slate-400 pb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                <div key={d} className="py-1">
                  {d}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1.5">
              {monthlyCells.map((cell) => {
                const daySessions = planner.revisions.filter(
                  (r) => r.sessionDate === cell.iso
                );
                const isToday = cell.iso === todayISO;
                const isSelected = selectedDate === cell.iso;

                return (
                  <button
                    key={cell.iso}
                    type="button"
                    onClick={() =>
                      setSelectedDate(isSelected ? null : cell.iso)
                    }
                    className={`min-h-[76px] sm:min-h-[92px] p-2 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/50 ring-1 ring-indigo-600'
                        : isToday
                          ? 'border-blue-400 bg-blue-50/40 dark:bg-blue-950/30'
                          : 'border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    } ${!cell.inCurrentMonth ? 'opacity-45' : ''}`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span
                        className={`font-mono text-xs font-semibold tabular-nums ${
                          isToday
                            ? 'text-blue-600 dark:text-blue-400 font-bold'
                            : 'text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {cell.date.getDate()}
                      </span>
                      {daySessions.length > 0 && (
                        <span className="font-mono text-[10px] font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                          {daySessions.length}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1 mt-1 w-full">
                      {daySessions.slice(0, 2).map((sess) => {
                        const subj = planner.subjects.find(
                          (s) => s.id === sess.subjectId
                        );
                        const pal =
                          SUBJECT_PALETTE[subj?.color ?? 'indigo'] ??
                          SUBJECT_PALETTE.indigo;
                        return (
                          <div
                            key={sess.id}
                            className={`px-1.5 py-0.5 rounded text-[10px] font-medium truncate ${
                              sess.status === 'Completed'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : sess.status === 'Missed'
                                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                  : `${pal.softBg} ${pal.text}`
                            }`}
                          >
                            {sess.startTime} {subj?.code ?? ''}
                          </div>
                        );
                      })}
                      {daySessions.length > 2 && (
                        <p className="text-[10px] text-slate-400 font-medium">
                          +{daySessions.length - 2} more
                        </p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
            {weeklyCells.map((cell) => {
              const daySessions = planner.revisions.filter(
                (r) => r.sessionDate === cell.iso
              );
              const isToday = cell.iso === todayISO;
              return (
                <div
                  key={cell.iso}
                  className={`p-3 rounded-xl border flex flex-col justify-between min-h-[200px] ${
                    isToday
                      ? 'border-indigo-400 bg-indigo-50/30 dark:bg-indigo-950/20'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900/50'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between pb-2 border-b border-slate-200/70 dark:border-slate-800">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {cell.label}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedDate(cell.iso);
                          setEditingRevision(null);
                          setModalOpen(true);
                        }}
                        title={`Add revision on ${cell.label}`}
                        className="p-1 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="mt-2.5 space-y-2">
                      {daySessions.length === 0 ? (
                        <p className="text-xs text-slate-400 dark:text-slate-500 py-4 text-center">
                          No sessions
                        </p>
                      ) : (
                        daySessions.map((sess) => {
                          const subj = planner.subjects.find(
                            (s) => s.id === sess.subjectId
                          );
                          return (
                            <div
                              key={sess.id}
                              onClick={() => {
                                setEditingRevision(sess);
                                setModalOpen(true);
                              }}
                              className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-400 cursor-pointer transition-colors"
                            >
                              <p className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400">
                                {sess.startTime}–{sess.endTime}
                              </p>
                              <p className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-2 mt-0.5">
                                {sess.topicTitle}
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                                {subj?.code} · {sess.status}
                              </p>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              aria-label="Filter by subject"
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Subjects</option>
              {planner.subjects.map((s) => (
                <option key={s.id} value={String(s.id)}>
                  {s.code} — {s.name}
                </option>
              ))}
            </select>

            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              aria-label="Filter by priority"
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Priorities</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>

            <div className="flex flex-wrap items-center gap-1">
              {['all', 'Pending', 'Completed', 'Missed'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    statusFilter === st
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {st === 'all' ? 'All Status' : st}
                </button>
              ))}
            </div>
          </div>

          <div className="relative w-full xl:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search revision topics..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
        </div>

        {selectedRevisionIds.length > 0 && (
          <div className="px-4 py-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs sm:text-sm font-semibold text-indigo-950 dark:text-indigo-100">
              {selectedRevisionIds.length} revision session
              {selectedRevisionIds.length === 1 ? '' : 's'} selected
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  await bulkActionRevisions(selectedRevisionIds, 'complete');
                  setSelectedRevisionIds([]);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
              >
                Mark Completed
              </button>
              <button
                type="button"
                onClick={async () => {
                  await bulkActionRevisions(selectedRevisionIds, 'pending');
                  setSelectedRevisionIds([]);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white cursor-pointer"
              >
                Mark Pending
              </button>
              <button
                type="button"
                onClick={() => setConfirmBulkDeleteOpen(true)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white cursor-pointer"
              >
                Delete Selected
              </button>
              <button
                type="button"
                onClick={() => setSelectedRevisionIds([])}
                className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-800 cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>
        )}

        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
          {filteredAndSortedRevisions.length === 0 ? (
            <div className="p-10 text-center">
              <CalendarDays className="w-8 h-8 mx-auto text-slate-400 mb-2" />
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                No revision sessions match your filters.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedDate(null);
                  setSubjectFilter('all');
                  setStatusFilter('all');
                  setPriorityFilter('all');
                  setSearchQuery('');
                }}
                className="mt-3 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <>
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-600 dark:text-slate-300">
                      <th className="py-3.5 px-4 w-10">
                        <input
                          type="checkbox"
                          checked={allOnPageSelected}
                          onChange={toggleSelectAllOnPage}
                          aria-label="Select all revisions on page"
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                        />
                      </th>
                      <th className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => toggleSort('sessionDate')}
                          className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                        >
                          Date
                          {renderSortIcon('sessionDate')}
                        </button>
                      </th>
                      <th className="py-3.5 px-4">Day</th>
                      <th className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => toggleSort('subject')}
                          className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                        >
                          Subject
                          {renderSortIcon('subject')}
                        </button>
                      </th>
                      <th className="py-3.5 px-4">Topic</th>
                      <th className="py-3.5 px-4">Start Time</th>
                      <th className="py-3.5 px-4">End Time</th>
                      <th className="py-3.5 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => toggleSort('durationMinutes')}
                          className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer ml-auto"
                        >
                          Duration
                          {renderSortIcon('durationMinutes')}
                        </button>
                      </th>
                      <th className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => toggleSort('priority')}
                          className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                        >
                          Priority
                          {renderSortIcon('priority')}
                        </button>
                      </th>
                      <th className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => toggleSort('status')}
                          className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                        >
                          Status
                          {renderSortIcon('status')}
                        </button>
                      </th>
                      <th className="py-3.5 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                    {paginatedRevisions.map((rev, idx) => {
                      const subj = planner.subjects.find(
                        (s) => s.id === rev.subjectId
                      );
                      const isDone = rev.status === 'Completed';
                      const isSelected = selectedRevisionIds.includes(rev.id);
                      return (
                        <tr
                          key={rev.id}
                          className={`transition-colors hover:bg-indigo-50/40 dark:hover:bg-slate-800/50 ${
                            isSelected
                              ? 'bg-indigo-50/70 dark:bg-indigo-950/30'
                              : idx % 2 === 1
                                ? 'bg-slate-50/50 dark:bg-slate-900/40'
                                : ''
                          }`}
                        >
                          <td className="py-3.5 px-4">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleRevisionSelection(rev.id)}
                              aria-label={`Select ${rev.topicTitle}`}
                              className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                            />
                          </td>
                          <td className="py-3.5 px-4 font-mono text-xs font-semibold text-slate-700 dark:text-slate-300 whitespace-nowrap tabular-nums">
                            {formatShortDate(rev.sessionDate)}
                          </td>
                          <td className="py-3.5 px-4 text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
                            {formatDayName(rev.sessionDate)}
                          </td>
                          <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                            {subj?.name ?? 'Subject'}
                          </td>
                          <td className="py-3.5 px-4 max-w-xs">
                            <p className="font-medium text-slate-800 dark:text-slate-200 truncate">
                              {rev.topicTitle}
                            </p>
                            {rev.notes && (
                              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                                {rev.notes}
                              </p>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums whitespace-nowrap">
                            {rev.startTime}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums whitespace-nowrap">
                            {rev.endTime}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono text-xs font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums whitespace-nowrap">
                            {formatDurationLabel(rev.durationMinutes)}
                          </td>
                          <td className="py-3.5 px-4">
                            <PriorityBadge priority={rev.priority} />
                          </td>
                          <td className="py-3.5 px-4">
                            <select
                              value={rev.status}
                              onChange={(e) =>
                                updateRevision(rev.id, {
                                  status: e.target.value as RevisionStatus,
                                })
                              }
                              aria-label={`Status for ${rev.topicTitle}`}
                              className={`px-2.5 py-1 rounded-lg border text-xs font-semibold cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-600 ${
                                rev.status === 'Completed'
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                                  : rev.status === 'Missed'
                                    ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800'
                                    : 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                              }`}
                            >
                              <option value="Pending">Pending</option>
                              <option value="Completed">Completed</option>
                              <option value="Missed">Missed</option>
                            </select>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  updateRevision(rev.id, {
                                    status: isDone ? 'Pending' : 'Completed',
                                  })
                                }
                                title={
                                  isDone ? 'Mark Pending' : 'Mark Completed'
                                }
                                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                  isDone
                                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                    : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-emerald-950'
                                }`}
                              >
                                <Check className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingRevision(rev);
                                  setModalOpen(true);
                                }}
                                title="Edit revision"
                                className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:text-slate-400 dark:hover:bg-slate-800 cursor-pointer"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteRev(rev)}
                                title="Delete revision"
                                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:text-slate-400 dark:hover:bg-rose-950/60 cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="lg:hidden divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedRevisions.map((rev) => {
                  const subj = planner.subjects.find(
                    (s) => s.id === rev.subjectId
                  );
                  const isDone = rev.status === 'Completed';
                  const isSelected = selectedRevisionIds.includes(rev.id);
                  return (
                    <div key={rev.id} className="p-4 space-y-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleRevisionSelection(rev.id)}
                            className="w-4 h-4 mt-1 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                          />
                          <div>
                            <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                              {formatDayName(rev.sessionDate)} ·{' '}
                              {formatShortDate(rev.sessionDate)} · {subj?.name}
                            </p>
                            <h3 className="font-semibold text-sm text-slate-900 dark:text-white mt-0.5">
                              {rev.topicTitle}
                            </h3>
                          </div>
                        </div>
                        <PriorityBadge priority={rev.priority} />
                      </div>
                      <p className="text-xs font-mono text-slate-600 dark:text-slate-300 flex items-center gap-1.5 pl-6">
                        <Clock className="w-3.5 h-3.5" />
                        {rev.startTime} – {rev.endTime} (
                        {formatDurationLabel(rev.durationMinutes)})
                      </p>
                      <div className="flex items-center justify-between pt-1 pl-6 gap-2">
                        <select
                          value={rev.status}
                          onChange={(e) =>
                            updateRevision(rev.id, {
                              status: e.target.value as RevisionStatus,
                            })
                          }
                          className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200"
                        >
                          <option value="Pending">Pending</option>
                          <option value="Completed">Completed</option>
                          <option value="Missed">Missed</option>
                        </select>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              updateRevision(rev.id, {
                                status: isDone ? 'Pending' : 'Completed',
                              })
                            }
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 cursor-pointer"
                          >
                            {isDone ? 'Reopen' : 'Complete'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingRevision(rev);
                              setModalOpen(true);
                            }}
                            aria-label="Edit revision"
                            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteRev(rev)}
                            aria-label="Delete revision"
                            className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <Pagination
                totalItems={filteredAndSortedRevisions.length}
                currentPage={safePage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={(size) => {
                  setPageSize(size);
                  setCurrentPage(1);
                }}
              />
            </>
          )}
        </div>
      </section>

      <RevisionModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        defaultDate={selectedDate ?? undefined}
        editingRevision={editingRevision}
      />

      <CsvImportModal
        isOpen={csvImportOpen}
        onClose={() => setCsvImportOpen(false)}
        mode="revisions"
      />

      <ConfirmDialog
        isOpen={Boolean(confirmDeleteRev)}
        onClose={() => setConfirmDeleteRev(null)}
        onConfirm={() => {
          if (confirmDeleteRev) {
            return deleteRevision(confirmDeleteRev.id);
          }
        }}
        title="Delete Revision Session?"
        message={`Remove "${confirmDeleteRev?.topicTitle ?? ''}" scheduled on ${confirmDeleteRev ? formatShortDate(confirmDeleteRev.sessionDate) : ''}?`}
        confirmLabel="Delete Revision"
        variant="danger"
      />

      <ConfirmDialog
        isOpen={confirmBulkDeleteOpen}
        onClose={() => setConfirmBulkDeleteOpen(false)}
        onConfirm={async () => {
          await bulkActionRevisions(selectedRevisionIds, 'delete');
          setSelectedRevisionIds([]);
        }}
        title={`Delete ${selectedRevisionIds.length} Selected Revisions?`}
        message="This will permanently delete all selected revision sessions. This action cannot be undone."
        confirmLabel="Delete Selected"
        variant="danger"
      />
    </div>
  );
}
