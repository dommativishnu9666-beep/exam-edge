import cors from 'cors';
import rateLimit from 'express-rate-limit';
import type { NextFunction, Request, Response } from 'express';
import { appConfig } from '../config/env.ts';

export function securityHeaders(
  _req: Request,
  res: Response,
  next: NextFunction
) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=()'
  );
  // Keep popups functional for Firebase Google Sign-In
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin-allow-popups');
  next();
}

export const corsMiddleware = cors({
  origin: (origin, callback) => {
    // Allow same-origin requests (no Origin header) and local/configured origins
    if (!origin) return callback(null, true);
    const allowed = [
      'http://localhost:3000',
      'http://127.0.0.1:3000',
      appConfig.appUrl,
    ].filter(Boolean);

    if (
      allowed.includes(origin) ||
      origin.endsWith('.run.app') ||
      appConfig.nodeEnv !== 'production'
    ) {
      return callback(null, true);
    }
    return callback(new Error('Origin not allowed by CORS policy'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
});

export const apiRateLimiter = rateLimit({
  windowMs: appConfig.rateLimit.windowMs,
  max: appConfig.rateLimit.apiMaxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many requests. Please slow down and try again shortly.',
    code: 'RATE_LIMITED',
  },
});

export const importRateLimiter = rateLimit({
  windowMs: appConfig.rateLimit.windowMs,
  max: appConfig.rateLimit.importMaxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many CSV import requests. Please wait before trying again.',
    code: 'IMPORT_RATE_LIMITED',
  },
});
