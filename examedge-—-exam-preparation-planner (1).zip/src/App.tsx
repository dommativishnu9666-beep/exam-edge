import { useState } from 'react';
import { PlannerProvider, usePlanner } from './context/PlannerContext.tsx';
import type { AppPage } from './types/examedge.ts';
import { Sidebar } from './components/layout/Sidebar.tsx';
import { TopHeader } from './components/layout/TopHeader.tsx';
import { RevisionModal } from './components/modals/RevisionModal.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { SubjectsSyllabusPage } from './pages/SubjectsSyllabusPage.tsx';
import { RevisionCalendarPage } from './pages/RevisionCalendarPage.tsx';
import { StudyTipsPage } from './pages/StudyTipsPage.tsx';
import { AnalyticsPage } from './pages/AnalyticsPage.tsx';
import { SettingsProfilePage } from './pages/SettingsProfilePage.tsx';
import { HelpSupportPage } from './pages/HelpSupportPage.tsx';

function ExamEdgeShell() {
  const { planner, isLoadingData, dataError, refreshPlanner } = usePlanner();
  const [currentPage, setCurrentPage] = useState<AppPage>('landing');
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(
    null
  );
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [quickRevisionOpen, setQuickRevisionOpen] = useState(false);

  const selectedSubject =
    planner.subjects.find((s) => s.id === selectedSubjectId) ??
    planner.subjects[0] ??
    null;

  const handleOpenSubjectSyllabus = (subjectId: number) => {
    setSelectedSubjectId(subjectId);
    setCurrentPage('syllabus');
  };

  if (currentPage === 'landing') {
    return (
      <LandingPage
        onEnterWorkspace={(target = 'dashboard') => setCurrentPage(target)}
      />
    );
  }

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Sidebar
        currentPage={currentPage}
        onNavigate={(page) => setCurrentPage(page)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed((c) => !c)}
        mobileOpen={mobileDrawerOpen}
        onCloseMobile={() => setMobileDrawerOpen(false)}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        <TopHeader
          currentPage={currentPage}
          selectedSubjectName={selectedSubject?.name}
          onOpenMobileDrawer={() => setMobileDrawerOpen(true)}
          onQuickAddRevision={() => setQuickRevisionOpen(true)}
          onNavigate={(page) => setCurrentPage(page)}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1400px] w-full mx-auto">
          {dataError && (
            <div className="mb-6 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-center justify-between gap-4 text-sm text-rose-800 dark:text-rose-200">
              <span>{dataError}</span>
              <button
                type="button"
                onClick={() => refreshPlanner()}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700 cursor-pointer shrink-0"
              >
                Retry
              </button>
            </div>
          )}

          {isLoadingData ? (
            <div className="space-y-6 animate-pulse">
              <div className="h-36 rounded-2xl bg-slate-200 dark:bg-slate-800" />
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="h-32 rounded-2xl bg-slate-200 dark:bg-slate-800"
                  />
                ))}
              </div>
              <div className="h-72 rounded-2xl bg-slate-200 dark:bg-slate-800" />
            </div>
          ) : (
            <>
              {currentPage === 'dashboard' && (
                <DashboardPage
                  onNavigate={(p) => setCurrentPage(p)}
                  onOpenSubjectSyllabus={handleOpenSubjectSyllabus}
                  onQuickAddRevision={() => setQuickRevisionOpen(true)}
                />
              )}

              {(currentPage === 'subjects' || currentPage === 'syllabus') && (
                <SubjectsSyllabusPage
                  mode={currentPage}
                  selectedSubjectId={selectedSubject?.id ?? null}
                  onSelectSubject={(id) => setSelectedSubjectId(id)}
                  onSwitchMode={(m) => setCurrentPage(m)}
                />
              )}

              {currentPage === 'calendar' && <RevisionCalendarPage />}

              {currentPage === 'tips' && <StudyTipsPage />}

              {currentPage === 'analytics' && (
                <AnalyticsPage onOpenSubjectSyllabus={handleOpenSubjectSyllabus} />
              )}

              {currentPage === 'settings' && <SettingsProfilePage />}

              {currentPage === 'help' && (
                <HelpSupportPage onNavigate={(p) => setCurrentPage(p)} />
              )}
            </>
          )}
        </main>
      </div>

      <RevisionModal
        isOpen={quickRevisionOpen}
        onClose={() => setQuickRevisionOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <PlannerProvider>
      <ExamEdgeShell />
    </PlannerProvider>
  );
}
