import { Router } from 'express';
import { z } from 'zod';
import { requireAuth, type AuthRequest } from '../middleware/auth.ts';
import { importRateLimiter } from '../middleware/security.ts';
import { validateBody, validateParams } from '../middleware/validate.ts';
import { HttpError } from '../middleware/errorHandler.ts';
import { csvImportPayloadSchema } from '../validation/schemas.ts';
import { getOrCreateUser } from '../db/users.ts';
import {
  exportPlannerCsvService,
  processCsvImportService,
} from '../services/plannerService.ts';

export const csvRouter = Router();

csvRouter.use(requireAuth);

async function resolveDbUser(req: AuthRequest) {
  const uid = req.user?.uid;
  const email = req.user?.email || 'student@examedge.app';
  const name = typeof req.user?.name === 'string' ? req.user.name : undefined;
  if (!uid) {
    throw new HttpError(401, 'Missing authenticated user UID.', 'UNAUTHORIZED');
  }
  return await getOrCreateUser(uid, email, name);
}

const exportParamSchema = z.object({
  entity: z.enum(['subjects', 'topics', 'revisions', 'logs']),
});

csvRouter.post(
  '/csv/import',
  importRateLimiter,
  validateBody(csvImportPayloadSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const result = await processCsvImportService(dbUser.id, req.body);
      res.status(result.dryRun ? 200 : 201).json(result);
    } catch (err) {
      next(err);
    }
  }
);

csvRouter.get(
  '/csv/export/:entity',
  validateParams(exportParamSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const entity = req.params.entity as
        | 'subjects'
        | 'topics'
        | 'revisions'
        | 'logs';
      const { filename, csv } = await exportPlannerCsvService(
        dbUser.id,
        entity
      );
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${filename}"`
      );
      res.send(csv);
    } catch (err) {
      next(err);
    }
  }
);
