import { Router, type Response } from 'express';
import { requireAuth, type AuthRequest } from '../middleware/auth.ts';
import {
  validateBody,
  validateParams,
  validateQuery,
} from '../middleware/validate.ts';
import { HttpError } from '../middleware/errorHandler.ts';
import {
  autoScheduleSchema,
  createRevisionSchema,
  createSubjectSchema,
  createTopicSchema,
  idParamSchema,
  paginatedRevisionsQuerySchema,
  paginatedTopicsQuerySchema,
  profileUpdateSchema,
  studyLogSchema,
  updateRevisionSchema,
  updateSubjectSchema,
  updateTopicSchema,
} from '../validation/schemas.ts';
import { getOrCreateUser } from '../db/users.ts';
import {
  createRevisionForUser,
  createStudyLogForUser,
  createSubjectForUser,
  createTopicForUser,
  deleteRevisionForUser,
  deleteSubjectForUser,
  deleteTopicForUser,
  getPlannerStateForUser,
  listPaginatedRevisionsForUser,
  listPaginatedTopicsForUser,
  resetUserDemoData,
  toggleFavoriteTipForUser,
  updateRevisionForUser,
  updateSubjectForUser,
  updateTopicForUser,
  updateUserProfile,
} from '../db/plannerRepo.ts';
import { runAutoScheduleService } from '../services/plannerService.ts';

export const plannerRouter = Router();

plannerRouter.use(requireAuth);

async function resolveDbUser(req: AuthRequest) {
  const uid = req.user?.uid;
  const email = req.user?.email || 'student@examedge.app';
  const name = typeof req.user?.name === 'string' ? req.user.name : undefined;
  if (!uid) {
    throw new HttpError(401, 'Missing authenticated user UID.', 'UNAUTHORIZED');
  }
  return await getOrCreateUser(uid, email, name);
}

plannerRouter.get('/planner', async (req: AuthRequest, res, next) => {
  try {
    const dbUser = await resolveDbUser(req);
    const state = await getPlannerStateForUser(dbUser.id);
    res.json(state);
  } catch (err) {
    next(err);
  }
});

plannerRouter.post('/planner/reset-demo', async (req: AuthRequest, res, next) => {
  try {
    const dbUser = await resolveDbUser(req);
    const state = await resetUserDemoData(dbUser.id);
    res.json(state);
  } catch (err) {
    next(err);
  }
});

plannerRouter.patch(
  '/profile',
  validateBody(profileUpdateSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const updated = await updateUserProfile(dbUser.id, req.body);
      res.json(updated);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.post(
  '/subjects',
  validateBody(createSubjectSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const created = await createSubjectForUser(dbUser.id, req.body);
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof Error && err.message.includes('already exists')) {
        return next(new HttpError(409, err.message, 'DUPLICATE_SUBJECT_CODE'));
      }
      next(err);
    }
  }
);

plannerRouter.patch(
  '/subjects/:id',
  validateParams(idParamSchema),
  validateBody(updateSubjectSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const updated = await updateSubjectForUser(
        dbUser.id,
        Number(req.params.id),
        req.body
      );
      if (!updated) {
        return next(new HttpError(404, 'Subject not found.', 'NOT_FOUND'));
      }
      res.json(updated);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.delete(
  '/subjects/:id',
  validateParams(idParamSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const ok = await deleteSubjectForUser(dbUser.id, Number(req.params.id));
      if (!ok) {
        return next(new HttpError(404, 'Subject not found.', 'NOT_FOUND'));
      }
      res.json({ deleted: true });
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.get(
  '/topics',
  validateQuery(paginatedTopicsQuerySchema),
  async (req: AuthRequest, res: Response, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const q = res.locals.validatedQuery as {
        subjectId?: number;
        status: string;
        priority: string;
        search: string;
        sortBy: 'unitNumber' | 'priority' | 'estimatedHours' | 'status';
        sortDir: 'asc' | 'desc';
        page: number;
        pageSize: number;
      };
      const result = await listPaginatedTopicsForUser(dbUser.id, q);
      res.json(result);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.post(
  '/topics',
  validateBody(createTopicSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const created = await createTopicForUser(dbUser.id, req.body);
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof Error && err.message.includes('not found')) {
        return next(new HttpError(404, err.message, 'NOT_FOUND'));
      }
      next(err);
    }
  }
);

plannerRouter.patch(
  '/topics/:id',
  validateParams(idParamSchema),
  validateBody(updateTopicSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const updated = await updateTopicForUser(
        dbUser.id,
        Number(req.params.id),
        req.body
      );
      if (!updated) {
        return next(new HttpError(404, 'Topic not found.', 'NOT_FOUND'));
      }
      res.json(updated);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.delete(
  '/topics/:id',
  validateParams(idParamSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const ok = await deleteTopicForUser(dbUser.id, Number(req.params.id));
      if (!ok) {
        return next(new HttpError(404, 'Topic not found.', 'NOT_FOUND'));
      }
      res.json({ deleted: true });
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.get(
  '/revisions',
  validateQuery(paginatedRevisionsQuerySchema),
  async (req: AuthRequest, res: Response, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const q = res.locals.validatedQuery as {
        subjectId?: number;
        status: string;
        date?: string;
        search: string;
        sortBy: 'sessionDate' | 'durationMinutes' | 'priority' | 'status';
        sortDir: 'asc' | 'desc';
        page: number;
        pageSize: number;
      };
      const result = await listPaginatedRevisionsForUser(dbUser.id, q);
      res.json(result);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.post(
  '/revisions',
  validateBody(createRevisionSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const created = await createRevisionForUser(dbUser.id, req.body);
      res.status(201).json(created);
    } catch (err) {
      if (err instanceof Error && err.message.includes('not found')) {
        return next(new HttpError(404, err.message, 'NOT_FOUND'));
      }
      next(err);
    }
  }
);

plannerRouter.post(
  '/revisions/auto-schedule',
  validateBody(autoScheduleSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const result = await runAutoScheduleService(dbUser.id, req.body);
      res.status(result.committed ? 201 : 200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.patch(
  '/revisions/:id',
  validateParams(idParamSchema),
  validateBody(updateRevisionSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const updated = await updateRevisionForUser(
        dbUser.id,
        Number(req.params.id),
        req.body
      );
      if (!updated) {
        return next(
          new HttpError(404, 'Revision session not found.', 'NOT_FOUND')
        );
      }
      res.json(updated);
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.delete(
  '/revisions/:id',
  validateParams(idParamSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const ok = await deleteRevisionForUser(dbUser.id, Number(req.params.id));
      if (!ok) {
        return next(
          new HttpError(404, 'Revision session not found.', 'NOT_FOUND')
        );
      }
      res.json({ deleted: true });
    } catch (err) {
      next(err);
    }
  }
);

plannerRouter.post('/tips/:tipId/toggle', async (req: AuthRequest, res, next) => {
  try {
    const dbUser = await resolveDbUser(req);
    const tipId = String(req.params.tipId).trim();
    if (!tipId || tipId.length > 80) {
      return next(new HttpError(400, 'Invalid tip ID.', 'INVALID_PARAM'));
    }
    const result = await toggleFavoriteTipForUser(dbUser.id, tipId);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

plannerRouter.post(
  '/study-logs',
  validateBody(studyLogSchema),
  async (req: AuthRequest, res, next) => {
    try {
      const dbUser = await resolveDbUser(req);
      const created = await createStudyLogForUser(
        dbUser.id,
        req.body.minutes,
        req.body.description
      );
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  }
);
