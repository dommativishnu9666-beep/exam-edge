export const appConfig = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  appUrl: process.env.APP_URL || '',
  csv: {
    maxBytes: 1024 * 1024, // 1 MB strict upload limit
    maxRows: 500,
  },
  pagination: {
    defaultPageSize: 10,
    maxPageSize: 100,
  },
  rateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    apiMaxRequests: 300,
    importMaxRequests: 25,
  },
};
