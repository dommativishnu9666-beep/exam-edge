import { db } from './index.ts';
import { users } from './schema.ts';

export async function getOrCreateUser(
  uid: string,
  email: string,
  displayName?: string
) {
  try {
    const cleanName = displayName?.trim() || email.split('@')[0] || 'Student';
    const result = await db
      .insert(users)
      .values({
        uid,
        email,
        fullName: cleanName,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email,
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Failed to get or create user:', error);
    throw new Error('Unable to synchronize user profile.', { cause: error });
  }
}
