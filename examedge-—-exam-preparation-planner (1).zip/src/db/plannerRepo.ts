import { and, desc, eq, inArray } from 'drizzle-orm';
import { db } from './index.ts';
import {
  favoriteTips,
  revisionSessions,
  studyLogs,
  subjects,
  syllabusTopics,
  users,
} from './schema.ts';
import {
  SAMPLE_REVISIONS_SEED,
  SAMPLE_STUDY_LOGS_SEED,
  SAMPLE_SUBJECTS_SEED,
  shiftDateISO,
} from '../data/demoSeed.ts';
import { calculateDurationMinutes } from '../types/examedge.ts';

const SUBJECT_COLOR_CYCLE = [
  'indigo',
  'blue',
  'purple',
  'cyan',
  'emerald',
  'amber',
  'rose',
];

async function seedUserWorkspace(userId: number) {
  const existingSubjects = await db
    .select({ id: subjects.id })
    .from(subjects)
    .where(eq(subjects.userId, userId))
    .limit(1);

  if (existingSubjects.length > 0) {
    return;
  }

  await db.transaction(async (tx) => {
    const subjectIdByCode = new Map<string, number>();
    const topicIdByTitle = new Map<string, number>();

    for (const spec of SAMPLE_SUBJECTS_SEED) {
      const [insertedSubject] = await tx
        .insert(subjects)
        .values({
          userId,
          name: spec.name,
          code: spec.code,
          color: spec.color,
          icon: spec.icon,
          examDate: shiftDateISO(spec.examOffsetDays),
          priority: spec.priority,
        })
        .returning();

      subjectIdByCode.set(spec.code, insertedSubject.id);

      for (const t of spec.topics) {
        const [insertedTopic] = await tx
          .insert(syllabusTopics)
          .values({
            userId,
            subjectId: insertedSubject.id,
            unitNumber: t.unitNumber,
            unitName: t.unitName,
            topicTitle: t.topicTitle,
            priority: t.priority,
            estimatedHours: t.estimatedHours,
            status: t.status,
            notes: t.notes,
            completedAt: t.status === 'Completed' ? new Date() : null,
          })
          .returning();
        topicIdByTitle.set(t.topicTitle, insertedTopic.id);
      }
    }

    for (const rev of SAMPLE_REVISIONS_SEED) {
      const subjectId = subjectIdByCode.get(rev.subjectCode);
      if (!subjectId) continue;
      await tx.insert(revisionSessions).values({
        userId,
        subjectId,
        topicId: topicIdByTitle.get(rev.topicTitle) ?? null,
        topicTitle: rev.topicTitle,
        sessionDate: shiftDateISO(rev.offsetDays),
        startTime: rev.startTime,
        endTime: rev.endTime,
        durationMinutes: rev.durationMinutes,
        priority: rev.priority,
        status: rev.status,
        notes: rev.notes,
      });
    }

    for (const log of SAMPLE_STUDY_LOGS_SEED) {
      await tx.insert(studyLogs).values({
        userId,
        logDate: shiftDateISO(log.offsetDays),
        minutes: log.minutes,
        actionType: log.actionType,
        description: log.description,
      });
    }

    await tx.insert(favoriteTips).values([
      { userId, tipId: 'pomodoro-technique' },
      { userId, tipId: 'active-recall' },
    ]);
  });
}

export async function getPlannerStateForUser(userId: number) {
  try {
    await seedUserWorkspace(userId);

    const [
      profileRows,
      subjectRows,
      topicRows,
      revisionRows,
      logRows,
      favRows,
    ] = await Promise.all([
      db.select().from(users).where(eq(users.id, userId)).limit(1),
      db
        .select()
        .from(subjects)
        .where(eq(subjects.userId, userId))
        .orderBy(subjects.id),
      db
        .select()
        .from(syllabusTopics)
        .where(eq(syllabusTopics.userId, userId))
        .orderBy(syllabusTopics.unitNumber, syllabusTopics.id),
      db
        .select()
        .from(revisionSessions)
        .where(eq(revisionSessions.userId, userId))
        .orderBy(revisionSessions.sessionDate, revisionSessions.startTime),
      db
        .select()
        .from(studyLogs)
        .where(eq(studyLogs.userId, userId))
        .orderBy(desc(studyLogs.createdAt))
        .limit(60),
      db
        .select()
        .from(favoriteTips)
        .where(eq(favoriteTips.userId, userId)),
    ]);

    return {
      profile: profileRows[0],
      subjects: subjectRows,
      topics: topicRows,
      revisions: revisionRows,
      studyLogs: logRows,
      favoriteTipIds: favRows.map((f) => f.tipId),
    };
  } catch (error) {
    console.error('Database query failed in getPlannerStateForUser:', error);
    throw new Error('Failed to load planner data.', { cause: error });
  }
}

export async function resetUserDemoData(userId: number) {
  try {
    await db.transaction(async (tx) => {
      await tx.delete(subjects).where(eq(subjects.userId, userId));
      await tx.delete(studyLogs).where(eq(studyLogs.userId, userId));
      await tx.delete(favoriteTips).where(eq(favoriteTips.userId, userId));
    });
    await seedUserWorkspace(userId);
    return await getPlannerStateForUser(userId);
  } catch (error) {
    console.error('Database query failed in resetUserDemoData:', error);
    throw new Error('Failed to reset sample demonstration data.', {
      cause: error,
    });
  }
}

export async function updateUserProfile(
  userId: number,
  patch: Partial<{
    fullName: string;
    studentId: string;
    course: string;
    semester: string;
    dailyTargetHours: number;
    theme: string;
    notificationsEnabled: boolean;
  }>
) {
  try {
    const [updated] = await db
      .update(users)
      .set(patch)
      .where(eq(users.id, userId))
      .returning();
    return updated;
  } catch (error) {
    console.error('Database query failed in updateUserProfile:', error);
    throw new Error('Failed to update user profile.', { cause: error });
  }
}

export async function createSubjectForUser(
  userId: number,
  input: {
    name: string;
    code: string;
    color: string;
    icon: string;
    examDate: string;
    priority: string;
  }
) {
  try {
    const [created] = await db
      .insert(subjects)
      .values({
        userId,
        name: input.name,
        code: input.code,
        color: input.color,
        icon: input.icon,
        examDate: input.examDate,
        priority: input.priority,
      })
      .returning();

    await db.insert(studyLogs).values({
      userId,
      logDate: shiftDateISO(0),
      minutes: 0,
      actionType: 'subject_added',
      description: `Added subject ${input.name} (${input.code})`,
    });

    return created;
  } catch (error) {
    console.error('Database query failed in createSubjectForUser:', error);
    throw new Error('Failed to create subject.', { cause: error });
  }
}

export async function updateSubjectForUser(
  userId: number,
  subjectId: number,
  patch: Partial<{
    name: string;
    code: string;
    color: string;
    icon: string;
    examDate: string;
    priority: string;
  }>
) {
  try {
    const [updated] = await db
      .update(subjects)
      .set(patch)
      .where(and(eq(subjects.id, subjectId), eq(subjects.userId, userId)))
      .returning();
    return updated;
  } catch (error) {
    console.error('Database query failed in updateSubjectForUser:', error);
    throw new Error('Failed to update subject.', { cause: error });
  }
}

export async function deleteSubjectForUser(userId: number, subjectId: number) {
  try {
    const [deleted] = await db
      .delete(subjects)
      .where(and(eq(subjects.id, subjectId), eq(subjects.userId, userId)))
      .returning({ id: subjects.id });
    return Boolean(deleted);
  } catch (error) {
    console.error('Database query failed in deleteSubjectForUser:', error);
    throw new Error('Failed to delete subject.', { cause: error });
  }
}

export async function createTopicForUser(
  userId: number,
  input: {
    subjectId: number;
    unitNumber: number;
    unitName: string;
    topicTitle: string;
    priority: string;
    estimatedHours: number;
    status: string;
    notes: string;
  }
) {
  try {
    const [ownedSubject] = await db
      .select({ id: subjects.id })
      .from(subjects)
      .where(
        and(eq(subjects.id, input.subjectId), eq(subjects.userId, userId))
      )
      .limit(1);

    if (!ownedSubject) {
      throw new Error('Selected subject not found.');
    }

    const [created] = await db
      .insert(syllabusTopics)
      .values({
        userId,
        subjectId: input.subjectId,
        unitNumber: input.unitNumber,
        unitName: input.unitName,
        topicTitle: input.topicTitle,
        priority: input.priority,
        estimatedHours: input.estimatedHours,
        status: input.status,
        notes: input.notes,
        completedAt: input.status === 'Completed' ? new Date() : null,
      })
      .returning();

    if (input.status === 'Completed') {
      await db.insert(studyLogs).values({
        userId,
        logDate: shiftDateISO(0),
        minutes: Math.min(input.estimatedHours * 30, 180),
        actionType: 'topic_completed',
        description: `Completed topic: ${input.topicTitle}`,
      });
    }

    return created;
  } catch (error) {
    console.error('Database query failed in createTopicForUser:', error);
    if (error instanceof Error && error.message.includes('not found')) {
      throw error;
    }
    throw new Error('Failed to create syllabus topic.', { cause: error });
  }
}

export async function updateTopicForUser(
  userId: number,
  topicId: number,
  patch: Partial<{
    unitNumber: number;
    unitName: string;
    topicTitle: string;
    priority: string;
    estimatedHours: number;
    status: string;
    notes: string;
  }>
) {
  try {
    const [existing] = await db
      .select()
      .from(syllabusTopics)
      .where(
        and(eq(syllabusTopics.id, topicId), eq(syllabusTopics.userId, userId))
      );

    if (!existing) {
      return null;
    }

    const nextStatus = patch.status ?? existing.status;
    const becameCompleted =
      existing.status !== 'Completed' && nextStatus === 'Completed';

    const [updated] = await db
      .update(syllabusTopics)
      .set({
        ...patch,
        completedAt:
          nextStatus === 'Completed'
            ? existing.completedAt ?? new Date()
            : null,
      })
      .where(
        and(eq(syllabusTopics.id, topicId), eq(syllabusTopics.userId, userId))
      )
      .returning();

    if (becameCompleted) {
      await db.insert(studyLogs).values({
        userId,
        logDate: shiftDateISO(0),
        minutes: Math.min(
          (patch.estimatedHours ?? existing.estimatedHours) * 30,
          120
        ),
        actionType: 'topic_completed',
        description: `Completed syllabus topic: ${updated.topicTitle}`,
      });
    }

    return updated;
  } catch (error) {
    console.error('Database query failed in updateTopicForUser:', error);
    throw new Error('Failed to update syllabus topic.', { cause: error });
  }
}

export async function deleteTopicForUser(userId: number, topicId: number) {
  try {
    const [deleted] = await db
      .delete(syllabusTopics)
      .where(
        and(eq(syllabusTopics.id, topicId), eq(syllabusTopics.userId, userId))
      )
      .returning({ id: syllabusTopics.id });
    return Boolean(deleted);
  } catch (error) {
    console.error('Database query failed in deleteTopicForUser:', error);
    throw new Error('Failed to delete syllabus topic.', { cause: error });
  }
}

export async function bulkImportTopicsForUser(
  userId: number,
  rows: Array<{
    subjectCode: string;
    subjectName?: string;
    unitNumber: number;
    unitName: string;
    topicTitle: string;
    priority: string;
    estimatedHours: number;
    status: string;
    notes: string;
  }>
) {
  try {
    return await db.transaction(async (tx) => {
      const existingSubjects = await tx
        .select()
        .from(subjects)
        .where(eq(subjects.userId, userId));

      const subjectByCode = new Map<string, number>();
      for (const s of existingSubjects) {
        subjectByCode.set(s.code.toUpperCase(), s.id);
      }

      let colorIdx = existingSubjects.length;
      const insertedTopics = [];

      for (const row of rows) {
        const normCode = row.subjectCode.trim().toUpperCase();
        let subjectId = subjectByCode.get(normCode);
        if (!subjectId) {
          const [createdSub] = await tx
            .insert(subjects)
            .values({
              userId,
              name: (row.subjectName || normCode).trim(),
              code: normCode,
              color:
                SUBJECT_COLOR_CYCLE[colorIdx % SUBJECT_COLOR_CYCLE.length],
              icon: 'book',
              examDate: shiftDateISO(21),
              priority: 'Medium',
            })
            .returning();
          colorIdx++;
          subjectId = createdSub.id;
          subjectByCode.set(normCode, subjectId);
        }

        const [createdTopic] = await tx
          .insert(syllabusTopics)
          .values({
            userId,
            subjectId,
            unitNumber: row.unitNumber,
            unitName: row.unitName,
            topicTitle: row.topicTitle,
            priority: row.priority,
            estimatedHours: row.estimatedHours,
            status: row.status,
            notes: row.notes,
            completedAt: row.status === 'Completed' ? new Date() : null,
          })
          .returning();

        insertedTopics.push(createdTopic);
      }

      if (insertedTopics.length > 0) {
        await tx.insert(studyLogs).values({
          userId,
          logDate: shiftDateISO(0),
          minutes: 0,
          actionType: 'topic_completed',
          description: `Imported ${insertedTopics.length} syllabus topics from CSV`,
        });
      }

      return insertedTopics;
    });
  } catch (error) {
    console.error('Database query failed in bulkImportTopicsForUser:', error);
    throw new Error('Failed to import syllabus topics.', { cause: error });
  }
}

export async function bulkActionTopicsForUser(
  userId: number,
  ids: number[],
  action: 'complete' | 'reopen' | 'delete'
) {
  if (ids.length === 0) return { count: 0 };
  try {
    return await db.transaction(async (tx) => {
      if (action === 'delete') {
        const deleted = await tx
          .delete(syllabusTopics)
          .where(
            and(
              eq(syllabusTopics.userId, userId),
              inArray(syllabusTopics.id, ids)
            )
          )
          .returning({ id: syllabusTopics.id });
        return { count: deleted.length };
      }

      const nextStatus = action === 'complete' ? 'Completed' : 'In Progress';
      const updated = await tx
        .update(syllabusTopics)
        .set({
          status: nextStatus,
          completedAt: action === 'complete' ? new Date() : null,
        })
        .where(
          and(
            eq(syllabusTopics.userId, userId),
            inArray(syllabusTopics.id, ids)
          )
        )
        .returning({ id: syllabusTopics.id });

      if (action === 'complete' && updated.length > 0) {
        await tx.insert(studyLogs).values({
          userId,
          logDate: shiftDateISO(0),
          minutes: Math.min(updated.length * 30, 180),
          actionType: 'topic_completed',
          description: `Marked ${updated.length} syllabus topics completed`,
        });
      }

      return { count: updated.length };
    });
  } catch (error) {
    console.error('Database query failed in bulkActionTopicsForUser:', error);
    throw new Error('Failed to apply bulk topic update.', { cause: error });
  }
}

export async function createRevisionForUser(
  userId: number,
  input: {
    subjectId: number;
    topicId?: number | null;
    topicTitle: string;
    sessionDate: string;
    startTime: string;
    endTime: string;
    priority: string;
    status?: string;
    notes: string;
  }
) {
  try {
    const [ownedSubject] = await db
      .select({ id: subjects.id })
      .from(subjects)
      .where(
        and(eq(subjects.id, input.subjectId), eq(subjects.userId, userId))
      )
      .limit(1);

    if (!ownedSubject) {
      throw new Error('Selected subject not found.');
    }

    const durationMinutes = calculateDurationMinutes(
      input.startTime,
      input.endTime
    );
    const [created] = await db
      .insert(revisionSessions)
      .values({
        userId,
        subjectId: input.subjectId,
        topicId: input.topicId ?? null,
        topicTitle: input.topicTitle,
        sessionDate: input.sessionDate,
        startTime: input.startTime,
        endTime: input.endTime,
        durationMinutes,
        priority: input.priority,
        status: input.status ?? 'Pending',
        notes: input.notes,
      })
      .returning();

    return created;
  } catch (error) {
    console.error('Database query failed in createRevisionForUser:', error);
    if (error instanceof Error && error.message.includes('not found')) {
      throw error;
    }
    throw new Error('Failed to schedule revision session.', { cause: error });
  }
}

export async function updateRevisionForUser(
  userId: number,
  revisionId: number,
  patch: Partial<{
    subjectId: number;
    topicId: number | null;
    topicTitle: string;
    sessionDate: string;
    startTime: string;
    endTime: string;
    priority: string;
    status: string;
    notes: string;
  }>
) {
  try {
    const [existing] = await db
      .select()
      .from(revisionSessions)
      .where(
        and(
          eq(revisionSessions.id, revisionId),
          eq(revisionSessions.userId, userId)
        )
      );

    if (!existing) {
      return null;
    }

    if (patch.subjectId !== undefined) {
      const [ownedSubject] = await db
        .select({ id: subjects.id })
        .from(subjects)
        .where(
          and(eq(subjects.id, patch.subjectId), eq(subjects.userId, userId))
        )
        .limit(1);
      if (!ownedSubject) {
        throw new Error('Selected subject not found.');
      }
    }

    const startTime = patch.startTime ?? existing.startTime;
    const endTime = patch.endTime ?? existing.endTime;
    if (endTime <= startTime) {
      throw new Error('End time must be later than start time.');
    }

    const durationMinutes = calculateDurationMinutes(startTime, endTime);
    const becameCompleted =
      existing.status !== 'Completed' && patch.status === 'Completed';

    const [updated] = await db
      .update(revisionSessions)
      .set({
        ...patch,
        durationMinutes,
      })
      .where(
        and(
          eq(revisionSessions.id, revisionId),
          eq(revisionSessions.userId, userId)
        )
      )
      .returning();

    if (becameCompleted) {
      await db.insert(studyLogs).values({
        userId,
        logDate: shiftDateISO(0),
        minutes: durationMinutes,
        actionType: 'revision_completed',
        description: `Completed revision session: ${updated.topicTitle}`,
      });
    }

    return updated;
  } catch (error) {
    console.error('Database query failed in updateRevisionForUser:', error);
    if (
      error instanceof Error &&
      (error.message.includes('End time') ||
        error.message.includes('not found'))
    ) {
      throw error;
    }
    throw new Error('Failed to update revision session.', { cause: error });
  }
}

export async function deleteRevisionForUser(userId: number, revisionId: number) {
  try {
    const [deleted] = await db
      .delete(revisionSessions)
      .where(
        and(
          eq(revisionSessions.id, revisionId),
          eq(revisionSessions.userId, userId)
        )
      )
      .returning({ id: revisionSessions.id });
    return Boolean(deleted);
  } catch (error) {
    console.error('Database query failed in deleteRevisionForUser:', error);
    throw new Error('Failed to delete revision session.', { cause: error });
  }
}

export async function bulkImportRevisionsForUser(
  userId: number,
  rows: Array<{
    subjectCode: string;
    subjectName?: string;
    topicTitle: string;
    sessionDate: string;
    startTime: string;
    endTime: string;
    priority: string;
    status: string;
    notes: string;
  }>
) {
  try {
    return await db.transaction(async (tx) => {
      const existingSubjects = await tx
        .select()
        .from(subjects)
        .where(eq(subjects.userId, userId));

      const subjectByCode = new Map<string, number>();
      for (const s of existingSubjects) {
        subjectByCode.set(s.code.toUpperCase(), s.id);
      }

      let colorIdx = existingSubjects.length;
      const inserted = [];

      for (const row of rows) {
        const normCode = row.subjectCode.trim().toUpperCase();
        let subjectId = subjectByCode.get(normCode);
        if (!subjectId) {
          const [createdSub] = await tx
            .insert(subjects)
            .values({
              userId,
              name: (row.subjectName || normCode).trim(),
              code: normCode,
              color:
                SUBJECT_COLOR_CYCLE[colorIdx % SUBJECT_COLOR_CYCLE.length],
              icon: 'book',
              examDate: shiftDateISO(21),
              priority: 'Medium',
            })
            .returning();
          colorIdx++;
          subjectId = createdSub.id;
          subjectByCode.set(normCode, subjectId);
        }

        const durationMinutes = calculateDurationMinutes(
          row.startTime,
          row.endTime
        );
        const [createdRev] = await tx
          .insert(revisionSessions)
          .values({
            userId,
            subjectId,
            topicId: null,
            topicTitle: row.topicTitle,
            sessionDate: row.sessionDate,
            startTime: row.startTime,
            endTime: row.endTime,
            durationMinutes,
            priority: row.priority,
            status: row.status,
            notes: row.notes,
          })
          .returning();

        inserted.push(createdRev);
      }

      if (inserted.length > 0) {
        await tx.insert(studyLogs).values({
          userId,
          logDate: shiftDateISO(0),
          minutes: 0,
          actionType: 'revision_completed',
          description: `Imported ${inserted.length} revision sessions from CSV`,
        });
      }

      return inserted;
    });
  } catch (error) {
    console.error('Database query failed in bulkImportRevisionsForUser:', error);
    throw new Error('Failed to import revision sessions.', { cause: error });
  }
}

export async function bulkActionRevisionsForUser(
  userId: number,
  ids: number[],
  action: 'complete' | 'pending' | 'delete'
) {
  if (ids.length === 0) return { count: 0 };
  try {
    return await db.transaction(async (tx) => {
      if (action === 'delete') {
        const deleted = await tx
          .delete(revisionSessions)
          .where(
            and(
              eq(revisionSessions.userId, userId),
              inArray(revisionSessions.id, ids)
            )
          )
          .returning({ id: revisionSessions.id });
        return { count: deleted.length };
      }

      const nextStatus = action === 'complete' ? 'Completed' : 'Pending';
      const updated = await tx
        .update(revisionSessions)
        .set({ status: nextStatus })
        .where(
          and(
            eq(revisionSessions.userId, userId),
            inArray(revisionSessions.id, ids)
          )
        )
        .returning({
          id: revisionSessions.id,
          durationMinutes: revisionSessions.durationMinutes,
        });

      if (action === 'complete' && updated.length > 0) {
        const totalMins = updated.reduce((s, r) => s + r.durationMinutes, 0);
        await tx.insert(studyLogs).values({
          userId,
          logDate: shiftDateISO(0),
          minutes: totalMins,
          actionType: 'revision_completed',
          description: `Completed ${updated.length} revision sessions`,
        });
      }

      return { count: updated.length };
    });
  } catch (error) {
    console.error('Database query failed in bulkActionRevisionsForUser:', error);
    throw new Error('Failed to apply bulk revision update.', { cause: error });
  }
}

export async function toggleFavoriteTipForUser(userId: number, tipId: string) {
  try {
    const existing = await db
      .select()
      .from(favoriteTips)
      .where(
        and(eq(favoriteTips.userId, userId), eq(favoriteTips.tipId, tipId))
      );

    if (existing.length > 0) {
      await db
        .delete(favoriteTips)
        .where(
          and(eq(favoriteTips.userId, userId), eq(favoriteTips.tipId, tipId))
        );
      return { favorited: false };
    }

    await db.insert(favoriteTips).values({ userId, tipId });
    return { favorited: true };
  } catch (error) {
    console.error('Database query failed in toggleFavoriteTipForUser:', error);
    throw new Error('Failed to toggle favorite tip.', { cause: error });
  }
}

export async function createStudyLogForUser(
  userId: number,
  minutes: number,
  description: string
) {
  try {
    const [created] = await db
      .insert(studyLogs)
      .values({
        userId,
        logDate: shiftDateISO(0),
        minutes,
        actionType: 'study_logged',
        description,
      })
      .returning();
    return created;
  } catch (error) {
    console.error('Database query failed in createStudyLogForUser:', error);
    throw new Error('Failed to log study session.', { cause: error });
  }
}
