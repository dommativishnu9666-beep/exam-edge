import { relations } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  fullName: text('full_name').notNull().default('Aarav Sharma'),
  studentId: text('student_id').notNull().default('EE-2026-1042'),
  course: text('course').notNull().default('B.Tech Computer Science & Engineering'),
  semester: text('semester').notNull().default('Semester 1 · 2026'),
  dailyTargetHours: integer('daily_target_hours').notNull().default(4),
  theme: text('theme').notNull().default('light'),
  notificationsEnabled: boolean('notifications_enabled').notNull().default(true),
  avatarUrl: text('avatar_url')
    .notNull()
    .default('/src/assets/images/avatar_student_profile_1795155880836.jpg'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const subjects = pgTable(
  'subjects',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    name: text('name').notNull(),
    code: text('code').notNull(),
    color: text('color').notNull().default('indigo'),
    icon: text('icon').notNull().default('book'),
    examDate: text('exam_date').notNull(),
    priority: text('priority').notNull().default('High'),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => [index('subjects_user_id_idx').on(table.userId)]
);

export const syllabusTopics = pgTable(
  'syllabus_topics',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    unitNumber: integer('unit_number').notNull(),
    unitName: text('unit_name').notNull(),
    topicTitle: text('topic_title').notNull(),
    priority: text('priority').notNull().default('Medium'),
    estimatedHours: integer('estimated_hours').notNull().default(2),
    status: text('status').notNull().default('Not Started'),
    notes: text('notes').notNull().default(''),
    completedAt: timestamp('completed_at'),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => [
    index('syllabus_topics_user_id_idx').on(table.userId),
    index('syllabus_topics_subject_id_idx').on(table.subjectId),
  ]
);

export const revisionSessions = pgTable(
  'revision_sessions',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    topicId: integer('topic_id').references(() => syllabusTopics.id, {
      onDelete: 'set null',
    }),
    topicTitle: text('topic_title').notNull(),
    sessionDate: text('session_date').notNull(),
    startTime: text('start_time').notNull(),
    endTime: text('end_time').notNull(),
    durationMinutes: integer('duration_minutes').notNull().default(60),
    priority: text('priority').notNull().default('Medium'),
    status: text('status').notNull().default('Pending'),
    notes: text('notes').notNull().default(''),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => [
    index('revision_sessions_user_id_idx').on(table.userId),
    index('revision_sessions_subject_id_idx').on(table.subjectId),
    index('revision_sessions_date_idx').on(table.sessionDate),
  ]
);

export const studyLogs = pgTable(
  'study_logs',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    logDate: text('log_date').notNull(),
    minutes: integer('minutes').notNull().default(60),
    actionType: text('action_type').notNull(),
    description: text('description').notNull(),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => [
    index('study_logs_user_id_idx').on(table.userId),
    index('study_logs_date_idx').on(table.logDate),
  ]
);

export const favoriteTips = pgTable(
  'favorite_tips',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    tipId: text('tip_id').notNull(),
    createdAt: timestamp('created_at').defaultNow(),
  },
  (table) => [index('favorite_tips_user_id_idx').on(table.userId)]
);

export const usersRelations = relations(users, ({ many }) => ({
  subjects: many(subjects),
  syllabusTopics: many(syllabusTopics),
  revisionSessions: many(revisionSessions),
  studyLogs: many(studyLogs),
  favoriteTips: many(favoriteTips),
}));

export const subjectsRelations = relations(subjects, ({ one, many }) => ({
  user: one(users, {
    fields: [subjects.userId],
    references: [users.id],
  }),
  topics: many(syllabusTopics),
  revisions: many(revisionSessions),
}));

export const syllabusTopicsRelations = relations(syllabusTopics, ({ one }) => ({
  user: one(users, {
    fields: [syllabusTopics.userId],
    references: [users.id],
  }),
  subject: one(subjects, {
    fields: [syllabusTopics.subjectId],
    references: [subjects.id],
  }),
}));

export const revisionSessionsRelations = relations(revisionSessions, ({ one }) => ({
  user: one(users, {
    fields: [revisionSessions.userId],
    references: [users.id],
  }),
  subject: one(subjects, {
    fields: [revisionSessions.subjectId],
    references: [subjects.id],
  }),
  topic: one(syllabusTopics, {
    fields: [revisionSessions.topicId],
    references: [syllabusTopics.id],
  }),
}));

export const studyLogsRelations = relations(studyLogs, ({ one }) => ({
  user: one(users, {
    fields: [studyLogs.userId],
    references: [users.id],
  }),
}));

export const favoriteTipsRelations = relations(favoriteTips, ({ one }) => ({
  user: one(users, {
    fields: [favoriteTips.userId],
    references: [users.id],
  }),
}));
