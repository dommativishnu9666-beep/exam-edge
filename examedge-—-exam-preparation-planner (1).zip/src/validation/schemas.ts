const VALID_COLORS = new Set([
  'indigo',
  'blue',
  'purple',
  'cyan',
  'emerald',
  'amber',
  'rose',
]);
const VALID_ICONS = new Set([
  'book',
  'sigma',
  'atom',
  'code',
  'zap',
  'flask',
]);
const VALID_PRIORITIES = new Set(['High', 'Medium', 'Low']);
const VALID_TOPIC_STATUSES = new Set([
  'Not Started',
  'In Progress',
  'Completed',
]);
const VALID_REVISION_STATUSES = new Set(['Pending', 'Completed', 'Missed']);

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

export function isValidISODate(val: unknown): val is string {
  if (typeof val !== 'string' || !DATE_RE.test(val)) return false;
  const [y, m, d] = val.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return (
    dt.getFullYear() === y &&
    dt.getMonth() === m - 1 &&
    dt.getDate() === d
  );
}

export function isValidTime24(val: unknown): val is string {
  return typeof val === 'string' && TIME_RE.test(val);
}

export function sanitizeText(val: unknown, maxLen = 300): string {
  if (typeof val !== 'string') return '';
  return val.trim().slice(0, maxLen);
}

export function validateSubjectPatch(
  body: Record<string, unknown>,
  requireAll = false
) {
  const out: {
    name?: string;
    code?: string;
    color?: string;
    icon?: string;
    examDate?: string;
    priority?: string;
  } = {};

  if (requireAll || body.name !== undefined) {
    const name = sanitizeText(body.name, 120);
    if (!name) return { error: 'Subject name is required.' };
    out.name = name;
  }

  if (requireAll || body.code !== undefined) {
    const code = sanitizeText(body.code, 20).toUpperCase();
    if (!code) return { error: 'Subject code is required.' };
    out.code = code;
  }

  if (requireAll || body.examDate !== undefined) {
    if (!isValidISODate(body.examDate)) {
      return { error: 'Exam date must be in YYYY-MM-DD format.' };
    }
    out.examDate = body.examDate;
  }

  if (body.color !== undefined) {
    const color = String(body.color);
    if (!VALID_COLORS.has(color)) {
      return { error: 'Invalid subject color.' };
    }
    out.color = color;
  } else if (requireAll) {
    out.color = 'indigo';
  }

  if (body.icon !== undefined) {
    const icon = String(body.icon);
    out.icon = VALID_ICONS.has(icon) ? icon : 'book';
  } else if (requireAll) {
    out.icon = 'book';
  }

  if (body.priority !== undefined) {
    const priority = String(body.priority);
    if (!VALID_PRIORITIES.has(priority)) {
      return { error: 'Priority must be High, Medium, or Low.' };
    }
    out.priority = priority;
  } else if (requireAll) {
    out.priority = 'High';
  }

  return { data: out };
}

export function validateTopicPatch(
  body: Record<string, unknown>,
  requireAll = false
) {
  const out: {
    subjectId?: number;
    unitNumber?: number;
    unitName?: string;
    topicTitle?: string;
    priority?: string;
    estimatedHours?: number;
    status?: string;
    notes?: string;
  } = {};

  if (requireAll) {
    const subjectId = Number(body.subjectId);
    if (!Number.isInteger(subjectId) || subjectId <= 0) {
      return { error: 'Valid subject ID is required.' };
    }
    out.subjectId = subjectId;
  }

  if (requireAll || body.unitNumber !== undefined) {
    const unitNumber = Number(body.unitNumber ?? 1);
    if (!Number.isInteger(unitNumber) || unitNumber < 1 || unitNumber > 50) {
      return { error: 'Unit number must be an integer between 1 and 50.' };
    }
    out.unitNumber = unitNumber;
  }

  if (requireAll || body.unitName !== undefined) {
    const unitName = sanitizeText(body.unitName, 120);
    if (!unitName) return { error: 'Unit name is required.' };
    out.unitName = unitName;
  }

  if (requireAll || body.topicTitle !== undefined) {
    const topicTitle = sanitizeText(body.topicTitle, 240);
    if (!topicTitle) return { error: 'Topic title is required.' };
    out.topicTitle = topicTitle;
  }

  if (body.priority !== undefined) {
    const priority = String(body.priority);
    if (!VALID_PRIORITIES.has(priority)) {
      return { error: 'Priority must be High, Medium, or Low.' };
    }
    out.priority = priority;
  } else if (requireAll) {
    out.priority = 'Medium';
  }

  if (requireAll || body.estimatedHours !== undefined) {
    const estimatedHours = Number(body.estimatedHours ?? 2);
    if (
      !Number.isFinite(estimatedHours) ||
      estimatedHours < 1 ||
      estimatedHours > 60
    ) {
      return { error: 'Estimated hours must be between 1 and 60.' };
    }
    out.estimatedHours = Math.round(estimatedHours);
  }

  if (body.status !== undefined) {
    const status = String(body.status);
    if (!VALID_TOPIC_STATUSES.has(status)) {
      return { error: 'Invalid topic status.' };
    }
    out.status = status;
  } else if (requireAll) {
    out.status = 'Not Started';
  }

  if (body.notes !== undefined) {
    out.notes = sanitizeText(body.notes, 1000);
  } else if (requireAll) {
    out.notes = '';
  }

  return { data: out };
}

export function validateRevisionPatch(
  body: Record<string, unknown>,
  requireAll = false
) {
  const out: {
    subjectId?: number;
    topicId?: number | null;
    topicTitle?: string;
    sessionDate?: string;
    startTime?: string;
    endTime?: string;
    priority?: string;
    status?: string;
    notes?: string;
  } = {};

  if (requireAll || body.subjectId !== undefined) {
    const subjectId = Number(body.subjectId);
    if (!Number.isInteger(subjectId) || subjectId <= 0) {
      return { error: 'Valid subject ID is required.' };
    }
    out.subjectId = subjectId;
  }

  if (body.topicId !== undefined) {
    out.topicId = body.topicId ? Number(body.topicId) : null;
  } else if (requireAll) {
    out.topicId = null;
  }

  if (requireAll || body.topicTitle !== undefined) {
    const topicTitle = sanitizeText(body.topicTitle, 240);
    if (!topicTitle) return { error: 'Revision topic is required.' };
    out.topicTitle = topicTitle;
  }

  if (requireAll || body.sessionDate !== undefined) {
    if (!isValidISODate(body.sessionDate)) {
      return { error: 'Session date must be in YYYY-MM-DD format.' };
    }
    out.sessionDate = body.sessionDate;
  }

  if (requireAll || body.startTime !== undefined) {
    if (!isValidTime24(body.startTime)) {
      return { error: 'Start time must be in HH:MM format.' };
    }
    out.startTime = body.startTime;
  }

  if (requireAll || body.endTime !== undefined) {
    if (!isValidTime24(body.endTime)) {
      return { error: 'End time must be in HH:MM format.' };
    }
    out.endTime = body.endTime;
  }

  if (out.startTime && out.endTime && out.endTime <= out.startTime) {
    return { error: 'End time must be later than start time.' };
  }

  if (body.priority !== undefined) {
    const priority = String(body.priority);
    if (!VALID_PRIORITIES.has(priority)) {
      return { error: 'Priority must be High, Medium, or Low.' };
    }
    out.priority = priority;
  } else if (requireAll) {
    out.priority = 'Medium';
  }

  if (body.status !== undefined) {
    const status = String(body.status);
    if (!VALID_REVISION_STATUSES.has(status)) {
      return { error: 'Invalid revision status.' };
    }
    out.status = status;
  } else if (requireAll) {
    out.status = 'Pending';
  }

  if (body.notes !== undefined) {
    out.notes = sanitizeText(body.notes, 1000);
  } else if (requireAll) {
    out.notes = '';
  }

  return { data: out };
}
