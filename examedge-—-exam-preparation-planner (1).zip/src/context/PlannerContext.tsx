import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import {
  calculateDurationMinutes,
  type PlannerState,
  type PriorityLevel,
  type RevisionSession,
  type RevisionStatus,
  type Subject,
  type SubjectColor,
  type SyllabusTopic,
  type ThemeMode,
  type TopicStatus,
  type UserProfile,
} from '../types/examedge.ts';
import {
  SAMPLE_REVISIONS_SEED,
  SAMPLE_STUDY_LOGS_SEED,
  SAMPLE_SUBJECTS_SEED,
  shiftDateISO,
} from '../data/demoSeed.ts';
import { ToastContainer, type ToastItem } from '../components/ui/ToastContainer.tsx';
import type {
  CsvRevisionImportRow,
  CsvTopicImportRow,
} from '../utils/csv.ts';

const DEMO_COLOR_CYCLE: SubjectColor[] = [
  'indigo',
  'blue',
  'purple',
  'cyan',
  'emerald',
  'amber',
  'rose',
];

function buildInitialDemoState(): PlannerState {
  const subjectsList: Subject[] = [];
  const topicsList: SyllabusTopic[] = [];
  const revisionsList: RevisionSession[] = [];
  const subjectIdByCode = new Map<string, number>();
  const topicIdByTitle = new Map<string, number>();

  let sId = 1;
  let tId = 1;
  for (const spec of SAMPLE_SUBJECTS_SEED) {
    const currSubjectId = sId++;
    subjectsList.push({
      id: currSubjectId,
      userId: 0,
      name: spec.name,
      code: spec.code,
      color: spec.color,
      icon: spec.icon,
      examDate: shiftDateISO(spec.examOffsetDays),
      priority: spec.priority,
    });
    subjectIdByCode.set(spec.code, currSubjectId);

    for (const t of spec.topics) {
      const currTopicId = tId++;
      topicsList.push({
        id: currTopicId,
        userId: 0,
        subjectId: currSubjectId,
        unitNumber: t.unitNumber,
        unitName: t.unitName,
        topicTitle: t.topicTitle,
        priority: t.priority,
        estimatedHours: t.estimatedHours,
        status: t.status,
        notes: t.notes,
        completedAt: t.status === 'Completed' ? new Date().toISOString() : null,
      });
      topicIdByTitle.set(t.topicTitle, currTopicId);
    }
  }

  let rId = 1;
  for (const rev of SAMPLE_REVISIONS_SEED) {
    const subjectId = subjectIdByCode.get(rev.subjectCode);
    if (!subjectId) continue;
    revisionsList.push({
      id: rId++,
      userId: 0,
      subjectId,
      topicId: topicIdByTitle.get(rev.topicTitle) ?? null,
      topicTitle: rev.topicTitle,
      sessionDate: shiftDateISO(rev.offsetDays),
      startTime: rev.startTime,
      endTime: rev.endTime,
      durationMinutes: rev.durationMinutes,
      priority: rev.priority,
      status: rev.status,
      notes: rev.notes,
    });
  }

  const savedTheme =
    (typeof window !== 'undefined' &&
      (localStorage.getItem('examedge_theme') as ThemeMode | null)) ||
    'light';

  return {
    profile: {
      id: 0,
      uid: 'demo-student',
      email: 'student@examedge.app',
      fullName: 'Aarav Sharma',
      studentId: 'EE-2026-1042',
      course: 'B.Tech Computer Science & Engineering',
      semester: 'Semester 1 · 2026',
      dailyTargetHours: 4,
      theme: savedTheme,
      notificationsEnabled: true,
      avatarUrl: '/src/assets/images/avatar_student_profile_1795155880836.jpg',
    },
    subjects: subjectsList,
    topics: topicsList,
    revisions: revisionsList,
    studyLogs: SAMPLE_STUDY_LOGS_SEED.map((l, idx) => ({
      id: idx + 1,
      userId: 0,
      logDate: shiftDateISO(l.offsetDays),
      minutes: l.minutes,
      actionType: l.actionType,
      description: l.description,
      createdAt: new Date().toISOString(),
    })).reverse(),
    favoriteTipIds: ['pomodoro-technique', 'active-recall'],
  };
}

interface PlannerContextValue {
  firebaseUser: User | null;
  authLoading: boolean;
  isDemoMode: boolean;
  planner: PlannerState;
  isLoadingData: boolean;
  dataError: string | null;
  signInWithGoogle: () => Promise<boolean>;
  logout: () => Promise<void>;
  refreshPlanner: () => Promise<void>;
  resetDemoData: () => Promise<void>;
  setTheme: (theme: ThemeMode) => Promise<void>;
  updateProfile: (
    patch: Partial<
      Pick<
        UserProfile,
        | 'fullName'
        | 'studentId'
        | 'course'
        | 'semester'
        | 'dailyTargetHours'
        | 'theme'
        | 'notificationsEnabled'
      >
    >
  ) => Promise<void>;
  createSubject: (input: {
    name: string;
    code: string;
    color: SubjectColor;
    icon: string;
    examDate: string;
    priority: PriorityLevel;
  }) => Promise<void>;
  updateSubject: (
    id: number,
    patch: Partial<
      Pick<Subject, 'name' | 'code' | 'color' | 'icon' | 'examDate' | 'priority'>
    >
  ) => Promise<void>;
  deleteSubject: (id: number) => Promise<void>;
  createTopic: (input: {
    subjectId: number;
    unitNumber: number;
    unitName: string;
    topicTitle: string;
    priority: PriorityLevel;
    estimatedHours: number;
    status: TopicStatus;
    notes: string;
  }) => Promise<void>;
  updateTopic: (
    id: number,
    patch: Partial<
      Pick<
        SyllabusTopic,
        | 'unitNumber'
        | 'unitName'
        | 'topicTitle'
        | 'priority'
        | 'estimatedHours'
        | 'status'
        | 'notes'
      >
    >
  ) => Promise<void>;
  deleteTopic: (id: number) => Promise<void>;
  createRevision: (input: {
    subjectId: number;
    topicId?: number | null;
    topicTitle: string;
    sessionDate: string;
    startTime: string;
    endTime: string;
    priority: PriorityLevel;
    status?: RevisionStatus;
    notes: string;
  }) => Promise<void>;
  updateRevision: (
    id: number,
    patch: Partial<
      Pick<
        RevisionSession,
        | 'subjectId'
        | 'topicId'
        | 'topicTitle'
        | 'sessionDate'
        | 'startTime'
        | 'endTime'
        | 'priority'
        | 'status'
        | 'notes'
      >
    >
  ) => Promise<void>;
  deleteRevision: (id: number) => Promise<void>;
  bulkImportTopics: (rows: CsvTopicImportRow[]) => Promise<number>;
  bulkActionTopics: (
    ids: number[],
    action: 'complete' | 'reopen' | 'delete'
  ) => Promise<void>;
  bulkImportRevisions: (rows: CsvRevisionImportRow[]) => Promise<number>;
  bulkActionRevisions: (
    ids: number[],
    action: 'complete' | 'pending' | 'delete'
  ) => Promise<void>;
  toggleFavoriteTip: (tipId: string) => Promise<void>;
  logStudyMinutes: (minutes: number, description: string) => Promise<void>;
  notify: (message: string, type?: ToastItem['type']) => void;
}

const PlannerContext = createContext<PlannerContextValue | null>(null);

export function PlannerProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [planner, setPlanner] = useState<PlannerState>(() =>
    buildInitialDemoState()
  );
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const notify = useCallback(
    (message: string, type: ToastItem['type'] = 'success') => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev, { id, type, message }]);
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3600);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (planner.profile.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem('examedge_theme', planner.profile.theme);
    } catch {
      // ignore storage quota errors
    }
  }, [planner.profile.theme]);

  const apiFetch = useCallback(
    async <T,>(path: string, options: RequestInit = {}): Promise<T> => {
      if (!auth.currentUser) {
        throw new Error('Authentication required');
      }
      const token = await auth.currentUser.getIdToken();
      const res = await fetch(path, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          ...(options.headers ?? {}),
        },
      });
      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error(errBody.error || `Request failed (${res.status})`);
      }
      return (await res.json()) as T;
    },
    []
  );

  const refreshPlanner = useCallback(async () => {
    if (!auth.currentUser) return;
    setIsLoadingData(true);
    setDataError(null);
    try {
      const data = await apiFetch<PlannerState>('/api/planner');
      setPlanner(data);
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : 'Unable to load your planner.';
      setDataError(msg);
      notify(msg, 'error');
    } finally {
      setIsLoadingData(false);
    }
  }, [apiFetch, notify]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthLoading(false);
      if (user) {
        await refreshPlanner();
      } else {
        setPlanner(buildInitialDemoState());
      }
    });
    return () => unsubscribe();
  }, [refreshPlanner]);

  const signInWithGoogle = useCallback(async (): Promise<boolean> => {
    try {
      await signInWithPopup(auth, googleAuthProvider);
      notify('Signed in! Your study plan is synced to PostgreSQL.', 'success');
      return true;
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : 'Google sign-in was cancelled.';
      notify(msg, 'error');
      return false;
    }
  }, [notify]);

  const logout = useCallback(async () => {
    await signOut(auth);
    setPlanner(buildInitialDemoState());
    notify('Signed out of ExamEdge.', 'info');
  }, [notify]);

  const isDemoMode = !firebaseUser;

  const updateProfile = useCallback(
    async (
      patch: Partial<
        Pick<
          UserProfile,
          | 'fullName'
          | 'studentId'
          | 'course'
          | 'semester'
          | 'dailyTargetHours'
          | 'theme'
          | 'notificationsEnabled'
        >
      >
    ) => {
      if (isDemoMode) {
        setPlanner((prev) => ({
          ...prev,
          profile: { ...prev.profile, ...patch },
        }));
        notify('Profile preferences updated in preview.', 'success');
        return;
      }
      const updated = await apiFetch<UserProfile>('/api/profile', {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      setPlanner((prev) => ({ ...prev, profile: updated }));
      notify('Profile settings saved.', 'success');
    },
    [apiFetch, isDemoMode, notify]
  );

  const setTheme = useCallback(
    async (theme: ThemeMode) => {
      setPlanner((prev) => ({
        ...prev,
        profile: { ...prev.profile, theme },
      }));
      if (!isDemoMode) {
        try {
          await apiFetch<UserProfile>('/api/profile', {
            method: 'PATCH',
            body: JSON.stringify({ theme }),
          });
        } catch {
          // theme already applied visually
        }
      }
    },
    [apiFetch, isDemoMode]
  );

  const createSubject = useCallback(
    async (input: {
      name: string;
      code: string;
      color: SubjectColor;
      icon: string;
      examDate: string;
      priority: PriorityLevel;
    }) => {
      if (isDemoMode) {
        const nextId =
          planner.subjects.reduce((max, s) => Math.max(max, s.id), 0) + 1;
        const created: Subject = { id: nextId, userId: 0, ...input };
        setPlanner((prev) => ({
          ...prev,
          subjects: [...prev.subjects, created],
          studyLogs: [
            {
              id: Date.now(),
              userId: 0,
              logDate: shiftDateISO(0),
              minutes: 0,
              actionType: 'subject_added',
              description: `Added subject ${input.name} (${input.code})`,
              createdAt: new Date().toISOString(),
            },
            ...prev.studyLogs,
          ],
        }));
        notify(`Subject "${input.name}" added.`, 'success');
        return;
      }
      await apiFetch<Subject>('/api/subjects', {
        method: 'POST',
        body: JSON.stringify(input),
      });
      await refreshPlanner();
      notify(`Subject "${input.name}" added.`, 'success');
    },
    [apiFetch, isDemoMode, notify, planner.subjects, refreshPlanner]
  );

  const updateSubject = useCallback(
    async (
      id: number,
      patch: Partial<
        Pick<Subject, 'name' | 'code' | 'color' | 'icon' | 'examDate' | 'priority'>
      >
    ) => {
      if (isDemoMode) {
        setPlanner((prev) => ({
          ...prev,
          subjects: prev.subjects.map((s) =>
            s.id === id ? { ...s, ...patch } : s
          ),
        }));
        notify('Subject updated.', 'success');
        return;
      }
      await apiFetch<Subject>(`/api/subjects/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      await refreshPlanner();
      notify('Subject updated.', 'success');
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const deleteSubject = useCallback(
    async (id: number) => {
      if (isDemoMode) {
        setPlanner((prev) => ({
          ...prev,
          subjects: prev.subjects.filter((s) => s.id !== id),
          topics: prev.topics.filter((t) => t.subjectId !== id),
          revisions: prev.revisions.filter((r) => r.subjectId !== id),
        }));
        notify('Subject removed.', 'info');
        return;
      }
      await apiFetch(`/api/subjects/${id}`, { method: 'DELETE' });
      await refreshPlanner();
      notify('Subject removed.', 'info');
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const createTopic = useCallback(
    async (input: {
      subjectId: number;
      unitNumber: number;
      unitName: string;
      topicTitle: string;
      priority: PriorityLevel;
      estimatedHours: number;
      status: TopicStatus;
      notes: string;
    }) => {
      if (isDemoMode) {
        const nextId =
          planner.topics.reduce((max, t) => Math.max(max, t.id), 0) + 1;
        const created: SyllabusTopic = {
          id: nextId,
          userId: 0,
          ...input,
          completedAt: input.status === 'Completed' ? new Date().toISOString() : null,
        };
        setPlanner((prev) => ({
          ...prev,
          topics: [...prev.topics, created],
        }));
        notify(`Topic "${input.topicTitle}" added.`, 'success');
        return;
      }
      await apiFetch<SyllabusTopic>('/api/topics', {
        method: 'POST',
        body: JSON.stringify(input),
      });
      await refreshPlanner();
      notify(`Topic "${input.topicTitle}" added.`, 'success');
    },
    [apiFetch, isDemoMode, notify, planner.topics, refreshPlanner]
  );

  const updateTopic = useCallback(
    async (
      id: number,
      patch: Partial<
        Pick<
          SyllabusTopic,
          | 'unitNumber'
          | 'unitName'
          | 'topicTitle'
          | 'priority'
          | 'estimatedHours'
          | 'status'
          | 'notes'
        >
      >
    ) => {
      if (isDemoMode) {
        setPlanner((prev) => {
          const target = prev.topics.find((t) => t.id === id);
          const becameDone =
            target && target.status !== 'Completed' && patch.status === 'Completed';
          const updatedTopics = prev.topics.map((t) =>
            t.id === id
              ? {
                  ...t,
                  ...patch,
                  completedAt:
                    (patch.status ?? t.status) === 'Completed'
                      ? t.completedAt ?? new Date().toISOString()
                      : null,
                }
              : t
          );
          const nextLogs = becameDone
            ? [
                {
                  id: Date.now(),
                  userId: 0,
                  logDate: shiftDateISO(0),
                  minutes: Math.min((target.estimatedHours || 2) * 30, 120),
                  actionType: 'topic_completed',
                  description: `Completed syllabus topic: ${patch.topicTitle ?? target.topicTitle}`,
                  createdAt: new Date().toISOString(),
                },
                ...prev.studyLogs,
              ]
            : prev.studyLogs;
          return { ...prev, topics: updatedTopics, studyLogs: nextLogs };
        });
        notify(
          patch.status === 'Completed'
            ? 'Topic marked completed!'
            : 'Topic updated.',
          'success'
        );
        return;
      }
      await apiFetch<SyllabusTopic>(`/api/topics/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      await refreshPlanner();
      notify(
        patch.status === 'Completed'
          ? 'Topic marked completed!'
          : 'Topic updated.',
        'success'
      );
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const deleteTopic = useCallback(
    async (id: number) => {
      if (isDemoMode) {
        setPlanner((prev) => ({
          ...prev,
          topics: prev.topics.filter((t) => t.id !== id),
        }));
        notify('Topic deleted.', 'info');
        return;
      }
      await apiFetch(`/api/topics/${id}`, { method: 'DELETE' });
      await refreshPlanner();
      notify('Topic deleted.', 'info');
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const createRevision = useCallback(
    async (input: {
      subjectId: number;
      topicId?: number | null;
      topicTitle: string;
      sessionDate: string;
      startTime: string;
      endTime: string;
      priority: PriorityLevel;
      status?: RevisionStatus;
      notes: string;
    }) => {
      if (isDemoMode) {
        const nextId =
          planner.revisions.reduce((max, r) => Math.max(max, r.id), 0) + 1;
        const created: RevisionSession = {
          id: nextId,
          userId: 0,
          subjectId: input.subjectId,
          topicId: input.topicId ?? null,
          topicTitle: input.topicTitle,
          sessionDate: input.sessionDate,
          startTime: input.startTime,
          endTime: input.endTime,
          durationMinutes: calculateDurationMinutes(
            input.startTime,
            input.endTime
          ),
          priority: input.priority,
          status: input.status ?? 'Pending',
          notes: input.notes,
        };
        setPlanner((prev) => ({
          ...prev,
          revisions: [...prev.revisions, created].sort((a, b) =>
            `${a.sessionDate}${a.startTime}`.localeCompare(
              `${b.sessionDate}${b.startTime}`
            )
          ),
        }));
        notify('Revision session scheduled.', 'success');
        return;
      }
      await apiFetch<RevisionSession>('/api/revisions', {
        method: 'POST',
        body: JSON.stringify(input),
      });
      await refreshPlanner();
      notify('Revision session scheduled.', 'success');
    },
    [apiFetch, isDemoMode, notify, planner.revisions, refreshPlanner]
  );

  const updateRevision = useCallback(
    async (
      id: number,
      patch: Partial<
        Pick<
          RevisionSession,
          | 'subjectId'
          | 'topicId'
          | 'topicTitle'
          | 'sessionDate'
          | 'startTime'
          | 'endTime'
          | 'priority'
          | 'status'
          | 'notes'
        >
      >
    ) => {
      if (isDemoMode) {
        setPlanner((prev) => {
          const target = prev.revisions.find((r) => r.id === id);
          const becameDone =
            target && target.status !== 'Completed' && patch.status === 'Completed';
          const updatedRevs = prev.revisions.map((r) => {
            if (r.id !== id) return r;
            const st = patch.startTime ?? r.startTime;
            const et = patch.endTime ?? r.endTime;
            return {
              ...r,
              ...patch,
              durationMinutes: calculateDurationMinutes(st, et),
            };
          });
          const nextLogs = becameDone
            ? [
                {
                  id: Date.now(),
                  userId: 0,
                  logDate: shiftDateISO(0),
                  minutes: target.durationMinutes,
                  actionType: 'revision_completed',
                  description: `Completed revision session: ${patch.topicTitle ?? target.topicTitle}`,
                  createdAt: new Date().toISOString(),
                },
                ...prev.studyLogs,
              ]
            : prev.studyLogs;
          return { ...prev, revisions: updatedRevs, studyLogs: nextLogs };
        });
        notify(
          patch.status === 'Completed'
            ? 'Revision marked completed!'
            : 'Revision session updated.',
          'success'
        );
        return;
      }
      await apiFetch<RevisionSession>(`/api/revisions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      await refreshPlanner();
      notify(
        patch.status === 'Completed'
          ? 'Revision marked completed!'
          : 'Revision session updated.',
        'success'
      );
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const deleteRevision = useCallback(
    async (id: number) => {
      if (isDemoMode) {
        setPlanner((prev) => ({
          ...prev,
          revisions: prev.revisions.filter((r) => r.id !== id),
        }));
        notify('Revision session deleted.', 'info');
        return;
      }
      await apiFetch(`/api/revisions/${id}`, { method: 'DELETE' });
      await refreshPlanner();
      notify('Revision session deleted.', 'info');
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const bulkImportTopics = useCallback(
    async (rows: CsvTopicImportRow[]): Promise<number> => {
      if (isDemoMode) {
        let importedCount = 0;
        setPlanner((prev) => {
          const nextSubjects = [...prev.subjects];
          const nextTopics = [...prev.topics];
          const codeToSubjectId = new Map<string, number>();
          for (const s of nextSubjects) {
            codeToSubjectId.set(s.code.toUpperCase(), s.id);
          }

          let nextSubId =
            nextSubjects.reduce((m, s) => Math.max(m, s.id), 0) + 1;
          let nextTopId =
            nextTopics.reduce((m, t) => Math.max(m, t.id), 0) + 1;

          for (const row of rows) {
            const normCode = row.subjectCode.trim().toUpperCase();
            let subId = codeToSubjectId.get(normCode);
            if (!subId) {
              subId = nextSubId++;
              nextSubjects.push({
                id: subId,
                userId: 0,
                name: (row.subjectName || normCode).trim(),
                code: normCode,
                color:
                  DEMO_COLOR_CYCLE[
                    nextSubjects.length % DEMO_COLOR_CYCLE.length
                  ],
                icon: 'book',
                examDate: shiftDateISO(21),
                priority: 'Medium',
              });
              codeToSubjectId.set(normCode, subId);
            }
            nextTopics.push({
              id: nextTopId++,
              userId: 0,
              subjectId: subId,
              unitNumber: row.unitNumber,
              unitName: row.unitName,
              topicTitle: row.topicTitle,
              priority: row.priority,
              estimatedHours: row.estimatedHours,
              status: row.status,
              notes: row.notes,
              completedAt:
                row.status === 'Completed' ? new Date().toISOString() : null,
            });
            importedCount++;
          }

          return {
            ...prev,
            subjects: nextSubjects,
            topics: nextTopics,
            studyLogs: [
              {
                id: Date.now(),
                userId: 0,
                logDate: shiftDateISO(0),
                minutes: 0,
                actionType: 'topic_completed',
                description: `Imported ${importedCount} syllabus topics from CSV`,
                createdAt: new Date().toISOString(),
              },
              ...prev.studyLogs,
            ],
          };
        });
        notify(`Imported ${rows.length} syllabus topics from CSV.`, 'success');
        return rows.length;
      }

      const res = await apiFetch<{ importedCount: number }>('/api/topics/bulk', {
        method: 'POST',
        body: JSON.stringify({ rows }),
      });
      await refreshPlanner();
      notify(
        `Imported ${res.importedCount} syllabus topics from CSV.`,
        'success'
      );
      return res.importedCount;
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const bulkActionTopics = useCallback(
    async (ids: number[], action: 'complete' | 'reopen' | 'delete') => {
      if (ids.length === 0) return;
      if (isDemoMode) {
        const idSet = new Set(ids);
        setPlanner((prev) => {
          if (action === 'delete') {
            return {
              ...prev,
              topics: prev.topics.filter((t) => !idSet.has(t.id)),
            };
          }
          const nextStatus: TopicStatus =
            action === 'complete' ? 'Completed' : 'In Progress';
          const updated = prev.topics.map((t) =>
            idSet.has(t.id)
              ? {
                  ...t,
                  status: nextStatus,
                  completedAt:
                    action === 'complete'
                      ? t.completedAt ?? new Date().toISOString()
                      : null,
                }
              : t
          );
          const nextLogs =
            action === 'complete'
              ? [
                  {
                    id: Date.now(),
                    userId: 0,
                    logDate: shiftDateISO(0),
                    minutes: Math.min(ids.length * 30, 180),
                    actionType: 'topic_completed',
                    description: `Marked ${ids.length} syllabus topics completed`,
                    createdAt: new Date().toISOString(),
                  },
                  ...prev.studyLogs,
                ]
              : prev.studyLogs;
          return { ...prev, topics: updated, studyLogs: nextLogs };
        });
        notify(
          action === 'delete'
            ? `Deleted ${ids.length} topics.`
            : action === 'complete'
              ? `Marked ${ids.length} topics completed!`
              : `Reopened ${ids.length} topics.`,
          action === 'delete' ? 'info' : 'success'
        );
        return;
      }

      const res = await apiFetch<{ count: number }>('/api/topics/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ ids, action }),
      });
      await refreshPlanner();
      notify(
        action === 'delete'
          ? `Deleted ${res.count} topics.`
          : action === 'complete'
            ? `Marked ${res.count} topics completed!`
            : `Reopened ${res.count} topics.`,
        action === 'delete' ? 'info' : 'success'
      );
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const bulkImportRevisions = useCallback(
    async (rows: CsvRevisionImportRow[]): Promise<number> => {
      if (isDemoMode) {
        setPlanner((prev) => {
          const nextSubjects = [...prev.subjects];
          const nextRevisions = [...prev.revisions];
          const codeToSubjectId = new Map<string, number>();
          for (const s of nextSubjects) {
            codeToSubjectId.set(s.code.toUpperCase(), s.id);
          }

          let nextSubId =
            nextSubjects.reduce((m, s) => Math.max(m, s.id), 0) + 1;
          let nextRevId =
            nextRevisions.reduce((m, r) => Math.max(m, r.id), 0) + 1;

          for (const row of rows) {
            const normCode = row.subjectCode.trim().toUpperCase();
            let subId = codeToSubjectId.get(normCode);
            if (!subId) {
              subId = nextSubId++;
              nextSubjects.push({
                id: subId,
                userId: 0,
                name: (row.subjectName || normCode).trim(),
                code: normCode,
                color:
                  DEMO_COLOR_CYCLE[
                    nextSubjects.length % DEMO_COLOR_CYCLE.length
                  ],
                icon: 'book',
                examDate: shiftDateISO(21),
                priority: 'Medium',
              });
              codeToSubjectId.set(normCode, subId);
            }
            nextRevisions.push({
              id: nextRevId++,
              userId: 0,
              subjectId: subId,
              topicId: null,
              topicTitle: row.topicTitle,
              sessionDate: row.sessionDate,
              startTime: row.startTime,
              endTime: row.endTime,
              durationMinutes: calculateDurationMinutes(
                row.startTime,
                row.endTime
              ),
              priority: row.priority,
              status: row.status,
              notes: row.notes,
            });
          }

          nextRevisions.sort((a, b) =>
            `${a.sessionDate}${a.startTime}`.localeCompare(
              `${b.sessionDate}${b.startTime}`
            )
          );

          return {
            ...prev,
            subjects: nextSubjects,
            revisions: nextRevisions,
            studyLogs: [
              {
                id: Date.now(),
                userId: 0,
                logDate: shiftDateISO(0),
                minutes: 0,
                actionType: 'revision_completed',
                description: `Imported ${rows.length} revision sessions from CSV`,
                createdAt: new Date().toISOString(),
              },
              ...prev.studyLogs,
            ],
          };
        });
        notify(`Imported ${rows.length} revision sessions from CSV.`, 'success');
        return rows.length;
      }

      const res = await apiFetch<{ importedCount: number }>(
        '/api/revisions/bulk',
        {
          method: 'POST',
          body: JSON.stringify({ rows }),
        }
      );
      await refreshPlanner();
      notify(
        `Imported ${res.importedCount} revision sessions from CSV.`,
        'success'
      );
      return res.importedCount;
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const bulkActionRevisions = useCallback(
    async (ids: number[], action: 'complete' | 'pending' | 'delete') => {
      if (ids.length === 0) return;
      if (isDemoMode) {
        const idSet = new Set(ids);
        setPlanner((prev) => {
          if (action === 'delete') {
            return {
              ...prev,
              revisions: prev.revisions.filter((r) => !idSet.has(r.id)),
            };
          }
          const nextStatus: RevisionStatus =
            action === 'complete' ? 'Completed' : 'Pending';
          const affected = prev.revisions.filter((r) => idSet.has(r.id));
          const updated = prev.revisions.map((r) =>
            idSet.has(r.id) ? { ...r, status: nextStatus } : r
          );
          const totalMins = affected.reduce(
            (sum, r) => sum + r.durationMinutes,
            0
          );
          const nextLogs =
            action === 'complete'
              ? [
                  {
                    id: Date.now(),
                    userId: 0,
                    logDate: shiftDateISO(0),
                    minutes: totalMins,
                    actionType: 'revision_completed',
                    description: `Completed ${affected.length} revision sessions`,
                    createdAt: new Date().toISOString(),
                  },
                  ...prev.studyLogs,
                ]
              : prev.studyLogs;
          return { ...prev, revisions: updated, studyLogs: nextLogs };
        });
        notify(
          action === 'delete'
            ? `Deleted ${ids.length} revision sessions.`
            : action === 'complete'
              ? `Marked ${ids.length} revisions completed!`
              : `Reopened ${ids.length} revision sessions.`,
          action === 'delete' ? 'info' : 'success'
        );
        return;
      }

      const res = await apiFetch<{ count: number }>(
        '/api/revisions/bulk-action',
        {
          method: 'POST',
          body: JSON.stringify({ ids, action }),
        }
      );
      await refreshPlanner();
      notify(
        action === 'delete'
          ? `Deleted ${res.count} revision sessions.`
          : action === 'complete'
            ? `Marked ${res.count} revisions completed!`
            : `Reopened ${res.count} revision sessions.`,
        action === 'delete' ? 'info' : 'success'
      );
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const toggleFavoriteTip = useCallback(
    async (tipId: string) => {
      if (isDemoMode) {
        setPlanner((prev) => {
          const exists = prev.favoriteTipIds.includes(tipId);
          return {
            ...prev,
            favoriteTipIds: exists
              ? prev.favoriteTipIds.filter((id) => id !== tipId)
              : [...prev.favoriteTipIds, tipId],
          };
        });
        return;
      }
      const res = await apiFetch<{ favorited: boolean }>(
        `/api/tips/${tipId}/toggle`,
        { method: 'POST' }
      );
      setPlanner((prev) => ({
        ...prev,
        favoriteTipIds: res.favorited
          ? [...prev.favoriteTipIds, tipId]
          : prev.favoriteTipIds.filter((id) => id !== tipId),
      }));
      notify(
        res.favorited ? 'Saved to favorite tips.' : 'Removed from favorites.',
        'info'
      );
    },
    [apiFetch, isDemoMode, notify]
  );

  const logStudyMinutes = useCallback(
    async (minutes: number, description: string) => {
      if (isDemoMode) {
        setPlanner((prev) => ({
          ...prev,
          studyLogs: [
            {
              id: Date.now(),
              userId: 0,
              logDate: shiftDateISO(0),
              minutes,
              actionType: 'study_logged',
              description,
              createdAt: new Date().toISOString(),
            },
            ...prev.studyLogs,
          ],
        }));
        notify(`Logged ${minutes} minutes of study.`, 'success');
        return;
      }
      await apiFetch('/api/study-logs', {
        method: 'POST',
        body: JSON.stringify({ minutes, description }),
      });
      await refreshPlanner();
      notify(`Logged ${minutes} minutes of study.`, 'success');
    },
    [apiFetch, isDemoMode, notify, refreshPlanner]
  );

  const resetDemoData = useCallback(async () => {
    if (isDemoMode) {
      setPlanner(buildInitialDemoState());
      notify('Sample demonstration data reset.', 'info');
      return;
    }
    const fresh = await apiFetch<PlannerState>('/api/planner/reset-demo', {
      method: 'POST',
    });
    setPlanner(fresh);
    notify('Starter sample data restored to your account.', 'info');
  }, [apiFetch, isDemoMode, notify]);

  return (
    <PlannerContext.Provider
      value={{
        firebaseUser,
        authLoading,
        isDemoMode,
        planner,
        isLoadingData,
        dataError,
        signInWithGoogle,
        logout,
        refreshPlanner,
        resetDemoData,
        setTheme,
        updateProfile,
        createSubject,
        updateSubject,
        deleteSubject,
        createTopic,
        updateTopic,
        deleteTopic,
        createRevision,
        updateRevision,
        deleteRevision,
        bulkImportTopics,
        bulkActionTopics,
        bulkImportRevisions,
        bulkActionRevisions,
        toggleFavoriteTip,
        logStudyMinutes,
        notify,
      }}
    >
      {children}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </PlannerContext.Provider>
  );
}

export function usePlanner() {
  const ctx = useContext(PlannerContext);
  if (!ctx) {
    throw new Error('usePlanner must be used within a PlannerProvider');
  }
  return ctx;
}
