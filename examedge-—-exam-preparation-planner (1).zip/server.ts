import express, {
  type NextFunction,
  type Request,
  type Response,
} from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';
import { requireAuth, type AuthRequest } from './src/middleware/auth.ts';
import { getOrCreateUser } from './src/db/users.ts';
import {
  bulkActionRevisionsForUser,
  bulkActionTopicsForUser,
  bulkImportRevisionsForUser,
  bulkImportTopicsForUser,
  createRevisionForUser,
  createStudyLogForUser,
  createSubjectForUser,
  createTopicForUser,
  deleteRevisionForUser,
  deleteSubjectForUser,
  deleteTopicForUser,
  getPlannerStateForUser,
  resetUserDemoData,
  toggleFavoriteTipForUser,
  updateRevisionForUser,
  updateSubjectForUser,
  updateTopicForUser,
  updateUserProfile,
} from './src/db/plannerRepo.ts';
import {
  isValidISODate,
  isValidTime24,
  sanitizeText,
  validateRevisionPatch,
  validateSubjectPatch,
  validateTopicPatch,
} from './src/validation/schemas.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

app.use(express.json({ limit: '2mb' }));

app.use(
  (
    err: unknown,
    _req: Request,
    res: Response,
    next: NextFunction
  ) => {
    if (err instanceof SyntaxError && 'body' in err) {
      return res.status(400).json({ error: 'Malformed JSON request body.' });
    }
    next(err);
  }
);

async function resolveDbUser(req: AuthRequest) {
  const uid = req.user?.uid;
  const email = req.user?.email || 'student@examedge.app';
  const name = typeof req.user?.name === 'string' ? req.user.name : undefined;
  if (!uid) {
    throw new Error('Missing authenticated user UID.');
  }
  return await getOrCreateUser(uid, email, name);
}

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' });
});

app.get('/api/planner', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const state = await getPlannerStateForUser(dbUser.id);
    res.json(state);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to load planner state';
    res.status(500).json({ error: message });
  }
});

app.post(
  '/api/planner/reset-demo',
  requireAuth,
  async (req: AuthRequest, res) => {
    try {
      const dbUser = await resolveDbUser(req);
      const state = await resetUserDemoData(dbUser.id);
      res.json(state);
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : 'Failed to reset demo data';
      res.status(500).json({ error: message });
    }
  }
);

app.patch('/api/profile', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const {
      fullName,
      studentId,
      course,
      semester,
      dailyTargetHours,
      theme,
      notificationsEnabled,
    } = req.body ?? {};
    const patch: Record<string, unknown> = {};
    if (fullName !== undefined) {
      const clean = sanitizeText(fullName, 120);
      if (!clean) {
        return res.status(400).json({ error: 'Full name cannot be empty.' });
      }
      patch.fullName = clean;
    }
    if (studentId !== undefined) {
      const clean = sanitizeText(studentId, 40);
      if (!clean) {
        return res.status(400).json({ error: 'Student ID cannot be empty.' });
      }
      patch.studentId = clean;
    }
    if (course !== undefined) {
      const clean = sanitizeText(course, 160);
      if (!clean) {
        return res.status(400).json({ error: 'Course cannot be empty.' });
      }
      patch.course = clean;
    }
    if (semester !== undefined) {
      const clean = sanitizeText(semester, 80);
      if (!clean) {
        return res.status(400).json({ error: 'Semester cannot be empty.' });
      }
      patch.semester = clean;
    }
    if (dailyTargetHours !== undefined) {
      const hrs = Number(dailyTargetHours);
      if (!Number.isFinite(hrs) || hrs < 1 || hrs > 16) {
        return res
          .status(400)
          .json({ error: 'Daily study target must be between 1 and 16 hours.' });
      }
      patch.dailyTargetHours = Math.round(hrs);
    }
    if (theme === 'light' || theme === 'dark') {
      patch.theme = theme;
    }
    if (typeof notificationsEnabled === 'boolean') {
      patch.notificationsEnabled = notificationsEnabled;
    }

    if (Object.keys(patch).length === 0) {
      return res.status(400).json({ error: 'No valid profile fields provided.' });
    }

    const updated = await updateUserProfile(dbUser.id, patch);
    res.json(updated);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to update profile';
    res.status(500).json({ error: message });
  }
});

app.post('/api/subjects', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const parsed = validateSubjectPatch(req.body ?? {}, true);
    if ('error' in parsed) {
      return res.status(400).json({ error: parsed.error });
    }
    const created = await createSubjectForUser(dbUser.id, {
      name: parsed.data.name!,
      code: parsed.data.code!,
      color: parsed.data.color!,
      icon: parsed.data.icon!,
      examDate: parsed.data.examDate!,
      priority: parsed.data.priority!,
    });
    res.status(201).json(created);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to create subject';
    res.status(500).json({ error: message });
  }
});

app.patch('/api/subjects/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const subjectId = Number(req.params.id);
    if (!Number.isInteger(subjectId) || subjectId <= 0) {
      return res.status(400).json({ error: 'Invalid subject ID.' });
    }
    const parsed = validateSubjectPatch(req.body ?? {}, false);
    if ('error' in parsed) {
      return res.status(400).json({ error: parsed.error });
    }
    if (Object.keys(parsed.data).length === 0) {
      return res.status(400).json({ error: 'No valid subject fields provided.' });
    }
    const updated = await updateSubjectForUser(dbUser.id, subjectId, parsed.data);
    if (!updated) {
      return res.status(404).json({ error: 'Subject not found.' });
    }
    res.json(updated);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to update subject';
    res.status(500).json({ error: message });
  }
});

app.delete('/api/subjects/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const subjectId = Number(req.params.id);
    if (!Number.isInteger(subjectId) || subjectId <= 0) {
      return res.status(400).json({ error: 'Invalid subject ID.' });
    }
    const deleted = await deleteSubjectForUser(dbUser.id, subjectId);
    if (!deleted) {
      return res.status(404).json({ error: 'Subject not found.' });
    }
    res.json({ deleted: true });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to delete subject';
    res.status(500).json({ error: message });
  }
});

app.post('/api/topics', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const parsed = validateTopicPatch(req.body ?? {}, true);
    if ('error' in parsed) {
      return res.status(400).json({ error: parsed.error });
    }
    const created = await createTopicForUser(dbUser.id, {
      subjectId: parsed.data.subjectId!,
      unitNumber: parsed.data.unitNumber!,
      unitName: parsed.data.unitName!,
      topicTitle: parsed.data.topicTitle!,
      priority: parsed.data.priority!,
      estimatedHours: parsed.data.estimatedHours!,
      status: parsed.data.status!,
      notes: parsed.data.notes!,
    });
    res.status(201).json(created);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to create topic';
    const status = message.includes('not found') ? 404 : 500;
    res.status(status).json({ error: message });
  }
});

app.post('/api/topics/bulk', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : null;
    if (!rows || rows.length === 0) {
      return res.status(400).json({ error: 'No topic rows provided for import.' });
    }
    if (rows.length > 500) {
      return res.status(400).json({ error: 'Maximum 500 rows per CSV import.' });
    }

    const sanitizedRows = [];
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i] ?? {};
      const subjectCode = sanitizeText(r.subjectCode, 20).toUpperCase();
      const unitName = sanitizeText(r.unitName, 120);
      const topicTitle = sanitizeText(r.topicTitle, 240);
      const unitNumber = Number(r.unitNumber || 1);
      const estimatedHours = Number(r.estimatedHours || 2);
      const priority = ['High', 'Medium', 'Low'].includes(String(r.priority))
        ? String(r.priority)
        : 'Medium';
      const status = ['Not Started', 'In Progress', 'Completed'].includes(
        String(r.status)
      )
        ? String(r.status)
        : 'Not Started';

      if (!subjectCode || !unitName || !topicTitle) {
        return res.status(400).json({
          error: `Row ${i + 1}: Subject Code, Unit Name, and Topic Title are required.`,
        });
      }
      sanitizedRows.push({
        subjectCode,
        subjectName: sanitizeText(r.subjectName, 120) || undefined,
        unitNumber:
          Number.isInteger(unitNumber) && unitNumber >= 1 && unitNumber <= 50
            ? unitNumber
            : 1,
        unitName,
        topicTitle,
        priority,
        estimatedHours:
          Number.isFinite(estimatedHours) &&
          estimatedHours >= 1 &&
          estimatedHours <= 60
            ? Math.round(estimatedHours)
            : 2,
        status,
        notes: sanitizeText(r.notes, 1000),
      });
    }

    const inserted = await bulkImportTopicsForUser(dbUser.id, sanitizedRows);
    res.status(201).json({ importedCount: inserted.length });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to import syllabus CSV';
    res.status(500).json({ error: message });
  }
});

app.post(
  '/api/topics/bulk-action',
  requireAuth,
  async (req: AuthRequest, res) => {
    try {
      const dbUser = await resolveDbUser(req);
      const ids = Array.isArray(req.body?.ids)
        ? req.body.ids
            .map((id: unknown) => Number(id))
            .filter((n: number) => Number.isInteger(n) && n > 0)
        : [];
      const action = req.body?.action;
      if (
        ids.length === 0 ||
        (action !== 'complete' && action !== 'reopen' && action !== 'delete')
      ) {
        return res
          .status(400)
          .json({ error: 'Valid topic IDs and bulk action are required.' });
      }
      const result = await bulkActionTopicsForUser(dbUser.id, ids, action);
      res.json(result);
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : 'Bulk topic update failed';
      res.status(500).json({ error: message });
    }
  }
);

app.patch('/api/topics/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const topicId = Number(req.params.id);
    if (!Number.isInteger(topicId) || topicId <= 0) {
      return res.status(400).json({ error: 'Invalid topic ID.' });
    }
    const parsed = validateTopicPatch(req.body ?? {}, false);
    if ('error' in parsed) {
      return res.status(400).json({ error: parsed.error });
    }
    if (Object.keys(parsed.data).length === 0) {
      return res.status(400).json({ error: 'No valid topic fields provided.' });
    }
    const updated = await updateTopicForUser(dbUser.id, topicId, parsed.data);
    if (!updated) {
      return res.status(404).json({ error: 'Topic not found.' });
    }
    res.json(updated);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to update topic';
    res.status(500).json({ error: message });
  }
});

app.delete('/api/topics/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const topicId = Number(req.params.id);
    if (!Number.isInteger(topicId) || topicId <= 0) {
      return res.status(400).json({ error: 'Invalid topic ID.' });
    }
    const deleted = await deleteTopicForUser(dbUser.id, topicId);
    if (!deleted) {
      return res.status(404).json({ error: 'Topic not found.' });
    }
    res.json({ deleted: true });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to delete topic';
    res.status(500).json({ error: message });
  }
});

app.post('/api/revisions', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const parsed = validateRevisionPatch(req.body ?? {}, true);
    if ('error' in parsed) {
      return res.status(400).json({ error: parsed.error });
    }
    const created = await createRevisionForUser(dbUser.id, {
      subjectId: parsed.data.subjectId!,
      topicId: parsed.data.topicId ?? null,
      topicTitle: parsed.data.topicTitle!,
      sessionDate: parsed.data.sessionDate!,
      startTime: parsed.data.startTime!,
      endTime: parsed.data.endTime!,
      priority: parsed.data.priority!,
      status: parsed.data.status!,
      notes: parsed.data.notes!,
    });
    res.status(201).json(created);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to schedule revision';
    const status = message.includes('not found') ? 404 : 500;
    res.status(status).json({ error: message });
  }
});

app.post('/api/revisions/bulk', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : null;
    if (!rows || rows.length === 0) {
      return res
        .status(400)
        .json({ error: 'No revision rows provided for import.' });
    }
    if (rows.length > 500) {
      return res.status(400).json({ error: 'Maximum 500 rows per CSV import.' });
    }

    const sanitizedRows = [];
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i] ?? {};
      const subjectCode = sanitizeText(r.subjectCode, 20).toUpperCase();
      const topicTitle = sanitizeText(r.topicTitle, 240);
      const sessionDate = String(r.sessionDate || '').trim();
      const startTime = String(r.startTime || '').trim();
      const endTime = String(r.endTime || '').trim();
      const priority = ['High', 'Medium', 'Low'].includes(String(r.priority))
        ? String(r.priority)
        : 'Medium';
      const status = ['Pending', 'Completed', 'Missed'].includes(
        String(r.status)
      )
        ? String(r.status)
        : 'Pending';

      if (
        !subjectCode ||
        !topicTitle ||
        !isValidISODate(sessionDate) ||
        !isValidTime24(startTime) ||
        !isValidTime24(endTime) ||
        endTime <= startTime
      ) {
        return res.status(400).json({
          error: `Row ${i + 1}: Valid Subject Code, Topic, Date (YYYY-MM-DD), and Start/End Time (HH:MM) are required.`,
        });
      }

      sanitizedRows.push({
        subjectCode,
        subjectName: sanitizeText(r.subjectName, 120) || undefined,
        topicTitle,
        sessionDate,
        startTime,
        endTime,
        priority,
        status,
        notes: sanitizeText(r.notes, 1000),
      });
    }

    const inserted = await bulkImportRevisionsForUser(dbUser.id, sanitizedRows);
    res.status(201).json({ importedCount: inserted.length });
  } catch (error: unknown) {
    const message =
      error instanceof Error
        ? error.message
        : 'Failed to import revisions CSV';
    res.status(500).json({ error: message });
  }
});

app.post(
  '/api/revisions/bulk-action',
  requireAuth,
  async (req: AuthRequest, res) => {
    try {
      const dbUser = await resolveDbUser(req);
      const ids = Array.isArray(req.body?.ids)
        ? req.body.ids
            .map((id: unknown) => Number(id))
            .filter((n: number) => Number.isInteger(n) && n > 0)
        : [];
      const action = req.body?.action;
      if (
        ids.length === 0 ||
        (action !== 'complete' && action !== 'pending' && action !== 'delete')
      ) {
        return res
          .status(400)
          .json({ error: 'Valid revision IDs and bulk action are required.' });
      }
      const result = await bulkActionRevisionsForUser(dbUser.id, ids, action);
      res.json(result);
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : 'Bulk revision update failed';
      res.status(500).json({ error: message });
    }
  }
);

app.patch('/api/revisions/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const revisionId = Number(req.params.id);
    if (!Number.isInteger(revisionId) || revisionId <= 0) {
      return res.status(400).json({ error: 'Invalid revision ID.' });
    }
    const parsed = validateRevisionPatch(req.body ?? {}, false);
    if ('error' in parsed) {
      return res.status(400).json({ error: parsed.error });
    }
    if (Object.keys(parsed.data).length === 0) {
      return res
        .status(400)
        .json({ error: 'No valid revision fields provided.' });
    }
    const updated = await updateRevisionForUser(
      dbUser.id,
      revisionId,
      parsed.data
    );
    if (!updated) {
      return res.status(404).json({ error: 'Revision session not found.' });
    }
    res.json(updated);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to update revision';
    const status = message.includes('End time')
      ? 400
      : message.includes('not found')
        ? 404
        : 500;
    res.status(status).json({ error: message });
  }
});

app.delete('/api/revisions/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const revisionId = Number(req.params.id);
    if (!Number.isInteger(revisionId) || revisionId <= 0) {
      return res.status(400).json({ error: 'Invalid revision ID.' });
    }
    const deleted = await deleteRevisionForUser(dbUser.id, revisionId);
    if (!deleted) {
      return res.status(404).json({ error: 'Revision session not found.' });
    }
    res.json({ deleted: true });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to delete revision';
    res.status(500).json({ error: message });
  }
});

app.post(
  '/api/tips/:tipId/toggle',
  requireAuth,
  async (req: AuthRequest, res) => {
    try {
      const dbUser = await resolveDbUser(req);
      const tipId = sanitizeText(req.params.tipId, 80);
      if (!tipId) {
        return res.status(400).json({ error: 'Invalid tip ID.' });
      }
      const result = await toggleFavoriteTipForUser(dbUser.id, tipId);
      res.json(result);
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : 'Failed to toggle favorite tip';
      res.status(500).json({ error: message });
    }
  }
);

app.post('/api/study-logs', requireAuth, async (req: AuthRequest, res) => {
  try {
    const dbUser = await resolveDbUser(req);
    const mins = Number(req.body?.minutes);
    if (!Number.isFinite(mins) || mins < 1 || mins > 720) {
      return res
        .status(400)
        .json({ error: 'Study minutes must be between 1 and 720.' });
    }
    const description =
      sanitizeText(req.body?.description, 240) || 'Logged study session';
    const created = await createStudyLogForUser(
      dbUser.id,
      Math.round(mins),
      description
    );
    res.status(201).json(created);
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to log study session';
    res.status(500).json({ error: message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ExamEdge server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
